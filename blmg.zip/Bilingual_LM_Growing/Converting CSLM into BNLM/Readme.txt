This is to convert a CSLM into A BNLM.
The procedure is as follows:

(1) Build a BNLM:
The SRILM should be installed at first.

/panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram-count -order 5 -interpolate -kndiscount -gt1min 0 -gt2min 0 -gt3min 0 -gt4min 0 -gt5min 0 -unk -text train -lm /panfs/panmt/users/rwang/lm/bnlm

(2) Build a CSLM:
The modified SRILM should be installed at first. Please refer to the cslm_modified.tar.gz.

The training manual is the cslm/com.csh, train.df, and dev.df.

(3) Converting CSLM into BNLM:
(3.1) src/arpa_splt.java: This is to split the ARPA file into unigram,bigram,...

for (n=2;n<=5;n++)
{
(3.2) src/extract_s_unk.java: This is to split n-gram into the one containing <s> and the one without <s>.
(3.3) src/extract_ngrams_from_arpa: This is to extract n-grams from arpa-file.
(3.4) Take the output n-grams of (3.3) as the input of CSLM:
(3.4.1) Text to Binary:  /panfs/panmt/users/rwang/cslm-original/src/text2bin ./lm/all.vocab ./data.cslm/output n-grams of (3.3).btxt ./data.cslm/output n-grams of (3.3).wlist ./data.cslm/output n-grams of (3.3).oov < ./data/output n-grams of (3.3)
(3.4.2) Calculate the probabilities: /panfs/panmt/users/rwang/tools/cslm/cslm_eval -m tutorial-c1-p256-h384-s8192-lr1.best.mach -w ./data.cslm/train.tok.wlall.wlist -l ./lm/bnlm -O 5 -t ./data.cslm/output n-grams of (3.3).wlist -p the probabilities file -R > log-file
(3.5) src/extract_truefile_from_cslm.java: This is to extract the true n-gram with probabilities from the CSLM file
(3.6) src/combine_nnlm_bnlm.java: This is to combine cslm and bnlm, the fake backoff-weights are added to the end of the file
 }
 
(3.7) Combine the new n-grams (n=2,3,4,5) with the original unigram from (3.1) together into the new Converted CSLM (CONV)

(4) Re-normalize the CONV:
/panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram -lm CONV -order 5 -renorm -write-lm CONV.re

(5) Interpolate with the BNLM (optional):
/panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram -lm CONV.re -order 5 -mix-lm BNLM -lambda 0.5 -write-lm CONV.inter
