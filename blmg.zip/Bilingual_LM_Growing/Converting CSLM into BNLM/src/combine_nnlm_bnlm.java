import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
public class combine_nnlm_bnlm {
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("This is to combine cslm and bnlm, the fake backoff-weights are added to the end of the file");
		System.out.println("0: nnlm; 1 :bnlm; 2 : output");
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		File file_i1 = new File(args[0]);
		File file_i2 = new File(args[1]);
		File file_o = new File(args[2]);
		String tempString1 = null;
		String tempString2 = null;
		String tb = "	";
		BufferedReader reader1 = null;
		BufferedReader reader2 = null;
		BufferedWriter writer = null;
		reader1 = new BufferedReader(new FileReader(file_i1));
		reader2 = new BufferedReader(new FileReader(file_i2));
		try {
			writer = new BufferedWriter(new FileWriter(file_o));
			while ((tempString1 = reader1.readLine()) != null && (tempString2 = reader2.readLine()) != null) {
				int start1 = tempString1.indexOf(tb);
				if(start1 != -1){
					String words1 = tempString1.substring(0, start1);
					writer.write(words1 + tb + tempString2 + tb + "-0.0001");
					writer.write("\n");
				}
			}
			writer.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null || reader2 != null) {
				try {
					reader1.close();
					reader2.close();
				} catch (IOException e1) {
				}
			}
		}
	}
}
