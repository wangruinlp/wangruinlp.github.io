import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class extract_truefile_from_cslm {

	public static void main(String[] args) throws IOException {
		System.out.println("This is to extract the true n-gram with probabilities from the CSLM file");
		System.out.println("0: CSLM file; 1: output-file; 2: number (for <s> file, type 2; for without<s>, type 3)");
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		File file_i = new File(args[0]);
		File file_o = new File(args[1]);
		int n = Integer.parseInt(args[2]);
		BufferedReader reader = null;
		BufferedWriter writer = null;
		String tempString = null;
		try {
			reader = new BufferedReader(new FileReader(file_i));
			writer = new BufferedWriter(new FileWriter(file_o));
			int i = 1, j = 0;
			while ((tempString = reader.readLine()) != null) {
				j = i % n;
				if(j == n-1){
				writer.write(tempString);
				writer.write("\n");
				}
				i++;
			}
			writer.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}
}