import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;


public class extract_ngrams_from_arpa {
	public static void main(String[] args) throws IOException {
		System.out.println("This is to extract n-grams from arpa-file");
		System.out.println("0-arpa-file; 1-extract-ngrams");
		System.out.println(args[0]);  
		System.out.println(args[1]);
		File file_i1 = new File(args[0]);
		File file_o1 = new File(args[1]);
		BufferedReader reader1 = null;
		BufferedWriter writer1 = null;
		String tempString1 = null;
		String ngram1 = null;
		String tab = "\t";
		try {

			reader1 = new BufferedReader(new FileReader(file_i1));
			writer1 = new BufferedWriter(new FileWriter(file_o1));


			while ((tempString1 = reader1.readLine()) != null) {
				int cut_s = tempString1.indexOf(tab);
				int cut_end = tempString1.lastIndexOf(tab);
				if (cut_s != -1) {
					if (cut_s != cut_end) {
						ngram1 = tempString1.substring(cut_s + 1, cut_end);
					} else {
						ngram1 = tempString1.substring(cut_s + 1);
					}
					writer1.write(ngram1);
					writer1.write("\n");
				} else {
				}
			}
			writer1.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null) {
				try {
					reader1.close();
				} catch (IOException e1) {
				}
			}
		}
	}
}
