import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class prob_filter {
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("this is to cutoff the ngram below a certain thresdhold");
		System.out.println("0-inputfile; 1-outputfile; 2-thresdhold");
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		File file_i1 = new File(args[0]);
		File file_o = new File(args[1]);
		String tempString = null;
		String tb = "	";
		BufferedReader reader1 = null;
		BufferedWriter writer = null;
		float thresdhold = Float.parseFloat(args[2]);
		reader1 = new BufferedReader(new FileReader(file_i1));
		try {
			writer = new BufferedWriter(new FileWriter(file_o));
			while ((tempString = reader1.readLine()) != null) {
				int start = tempString.indexOf(tb);
				if(start != -1){
					String words = tempString.substring(0, start);
					float num=Float.parseFloat(tempString.substring(start+1));
					if (num > thresdhold){
					writer.write(tempString);
					writer.write("\n");	
					}else{
					}
				}else{
				}
			}
			writer.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null) {
				try {
					reader1.close();
				} catch (IOException e1) {
				}
			}
		}



		//System.out.println(mp);
	}
}
