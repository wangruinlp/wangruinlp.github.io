

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class extract_phrases {

	public static void main(String[] args) throws IOException {
		System.out.println("This is to extract the words with translation probabilities from the phrase-table:");
		System.out.println("0: phrase-table; 1-output");
		System.out.println(args[0]);
		System.out.println(args[1]);
		File file_i = new File(args[0]);
		File file_o = new File(args[1]);
		BufferedReader reader = null;
		BufferedWriter writer = null;
		String tempString = null;
		try {
			reader = new BufferedReader(new FileReader(file_i));
			writer = new BufferedWriter(new FileWriter(file_o));
			while ((tempString = reader.readLine()) != null) {
				String tmp = "|||";
				String end = "2.718 |||";
				int s = tempString.indexOf(tmp);
				if (s != -1) {
					String chi = tempString.substring(0,s);
					String words_backoff = tempString.substring(s + 4);
					int l = words_backoff.indexOf(tmp);
					if(l !=-1){
						String words = words_backoff.substring(0, l-1);
						int e = tempString.lastIndexOf(end);
						if (e != -1) {
							String pro = tempString.substring(s+4,e-1);

							int last = pro.indexOf(tmp);
							//int l = words_backoff.indexOf(tmp);
							if(last !=-1){
								String four = pro.substring(last+4);
								int firstblank = four.indexOf(" ");
								if(firstblank !=-1){
									String three = four.substring(firstblank+1);
									//System.out.println(three);
									int secondblank = three.indexOf(" ");
									if(secondblank !=-1){
										String two = three.substring(secondblank+1);
										//System.out.println(two);
										//int firstblank = four.indexOf(" ");
										//if(firstblank !=-1){
										//String three = four.substring(firstblank+1);
										//System.out.println(three);
										//}else{
										int thirdblank = two.indexOf(" ");
										if(thirdblank !=-1){
											String fe = two.substring(0,thirdblank);
											String result = chi + "	" + words + "	" + fe;
											writer.write(result);
											writer.write("\n");
											//System.out.println(chi + "	" + words + "	" + fe);
											//int firstblank = four.indexOf(" ");
											//if(firstblank !=-1){
											//String three = four.substring(firstblank+1);
											//System.out.println(three);
											//}else{
										}else{
										}
									}else{

									}
								}else{

								}
								//System.out.println(four);
								//writer.write(words);
								//writer.write("\n");
								///}else{
								//writer.write(words_backoff);
								//writer.newLine();
							}else{

							}
						}else{

						}
						//writer.write(words);
						//writer.write("\n");
					}else{
						//writer.write(words_backoff);
						//writer.newLine();
					}
				}else{

				}

			}
			writer.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}
}