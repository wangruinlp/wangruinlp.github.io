import java.io.IOException;

public class extract_first_last {
	public static void main(String args[]) throws IOException {
		try {
			phrase_table pt = new phrase_table();
			pt.store_name("happy");
			System.out.println(pt.show_name());
			pt.read_file("test-target-phrase");
			pt.print_first_last();
			System.out.println("Extracting tails finished!");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {

		}
	}

}
