import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class fe {

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("this is to calculate p(e) = p(f)*p(e|f)");
		System.out.println("0-fcount; 1-phrase-table.words with probabilities; 2-target words with appearing probabilities; 3-total number of 0-fcount");
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		System.out.println(args[3]);
		File file_i1 = new File(args[0]);
		File file_i2 = new File(args[1]);
		File file_o = new File(args[2]);
		int total = Integer.parseInt(args[3]);
		Map<Object, Integer> mp=new HashMap<Object, Integer>();
		String tempString = null;
		String tb = "	";
		BufferedReader reader1 = null;
		BufferedReader reader2 = null;
		BufferedWriter writer = null;
		reader1 = new BufferedReader(new FileReader(file_i1));
		reader2 = new BufferedReader(new FileReader(file_i2));
		Map<Object, Float> writemp =new HashMap<Object, Float>();
		try {
			writer = new BufferedWriter(new FileWriter(file_o));
			while ((tempString = reader1.readLine()) != null) {
				int start = tempString.indexOf(tb);
				if(start != -1){
					String words = tempString.substring(0, start);
					int num=Integer.parseInt(tempString.substring(start+1));
					//writer = new BufferedWriter(new FileWriter(file_o));
					mp.put(words, num);

					//writer.close();
					//System.out.println(words + "	" +num);
					
				}
			}
			
			while ((tempString = reader2.readLine()) != null) {
				int start = tempString.indexOf(tb);
				int end = tempString.lastIndexOf(tb);
				String target = tempString.substring(start+1, end);
				//System.out.println(target);
				if(start != -1){
					String words = tempString.substring(0, start-1);
					//System.out.println(tempString.substring(end+1));
					Float num = Float.valueOf(tempString.substring(end+1));
					//int num=Integer.parseInt(tempString.substring(end+1));
					//System.out.println(words);
					//System.out.println(words + "	" +num);
					if(mp.containsKey(words)){
						int n = mp.get(words);
						float real = n * num / total;
						//System.out.println(target + "	" +real);
						if(writemp.containsKey(target)){
							float n2 = writemp.get(target);
							num = n2 + num;
							writemp.put(target, real);
						}else{
							writemp.put(target, real);
						}
						writer.write(target + "	" +real);
						writer.write("\n");
					}
					//writer = new BufferedWriter(new FileWriter(file_o));
					//mp.put(words, num);

					
					//System.out.println(words + "	" +num);
					
				}else{
					
				}
			}
			//Get Map in Set interface to get key and value
			Set s=writemp.entrySet();

			//Move next key and value of Map by iterator
			Iterator it=s.iterator();

			while(it.hasNext())
			{
				// key=value separator this by Map.Entry to get key and value
				Map.Entry m =(Map.Entry)it.next();

				// getKey is used to get key of Map
				String key=(String)m.getKey();

				// getValue is used to get value of key in Map
				float value=(Float) m.getValue();

				writer.write(key + "	" +value);
				writer.write("\n");
			}
			writer.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null || reader2 != null) {
				try {
					reader1.close();
					reader2.close();
				} catch (IOException e1) {
				}
			}
		}
		/*
		// adding or set elements in Map by put method key and value pair
		
		//Get Map in Set interface to get key and value
		Set s=mp.entrySet();

		//Move next key and value of Map by iterator
		Iterator it=s.iterator();

		while(it.hasNext())
		{
			// key=value separator this by Map.Entry to get key and value
			Map.Entry m =(Map.Entry)it.next();

			// getKey is used to get key of Map
			String key=(String)m.getKey();

			// getValue is used to get value of key in Map
			Integer value=(Integer)m.getValue();

			System.out.println("Key :"+key+"  Value :"+value);
		}
		*/
		System.out.print(mp);
	}
}