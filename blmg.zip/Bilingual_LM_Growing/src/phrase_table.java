import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

class phrase_table {
	private String name;
	private String tb = "	";
	private String words;
	private float pro;
	private static String space = " ";
	private String[] word_tmp;

	private HashMap<String, Float> mp_first_0 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_first_1 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_first_2 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_first_3 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_first_4 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_first_5 = new HashMap<String, Float>();

	private HashMap<String, Float> mp_last_0 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_last_1 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_last_2 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_last_3 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_last_4 = new HashMap<String, Float>();
	private HashMap<String, Float> mp_last_5 = new HashMap<String, Float>();

	private File pt_file;

	private File pt_out_first_0;
	private File pt_out_first_1;
	private File pt_out_first_2;
	private File pt_out_first_3;
	private File pt_out_first_4;
	private File pt_out_first_5;

	private File pt_out_last_0;
	private File pt_out_last_1;
	private File pt_out_last_2;
	private File pt_out_last_3;
	private File pt_out_last_4;
	private File pt_out_last_5;

	private BufferedReader reader1;

	phrase_table() {
		System.out.println("This is a phrase table.");
	}

	public void store_name(String input_name) {
		name = input_name;
	}

	public String show_name() {
		return name;
	}

	public int insert(HashMap<String, Float> mp, String words_tobe_inserted,
			float pro_tobe_inserted) {
		if (mp.containsKey(words_tobe_inserted)) {

			float n = mp.get(words_tobe_inserted);
			float tmp = n + pro_tobe_inserted;
			mp.put(words_tobe_inserted, tmp);
		} else {
			mp.put(words_tobe_inserted, pro_tobe_inserted);
		}
		return 0;
	}

	public void read_file(String file_name) throws IOException {
		try {
			String w_first_0, w_first_1, w_first_2, w_first_3, w_first_4, w_first_5; // first
																						// words
			String w_last_0, w_last_1, w_last_2, w_last_3, w_last_4, w_last_5; // last
																				// words
			pt_file = new File(file_name);
			reader1 = new BufferedReader(new FileReader(pt_file));
			String tempString;

			while ((tempString = reader1.readLine()) != null) {
				int start = tempString.indexOf(tb);
				if (start != -1) {

					words = tempString.substring(0, start);
					pro = Float.parseFloat(tempString.substring(start + 1));

				} else {

				}
				// For only one word in phrase
				if (words.indexOf(space) == -1) {
					w_first_0 = words;
					w_last_0 = words;

					insert(mp_first_0, w_first_0, pro);
					insert(mp_last_0, w_last_0, pro);

				} else {
					word_tmp = words.split(space);
					w_first_0 = word_tmp[0];
					w_last_0 = word_tmp[word_tmp.length - 1];

					// first word
					insert(mp_first_0, w_first_0, pro);
					// last word
					insert(mp_last_0, w_last_0, pro);

					// more than two words
					if (word_tmp.length >= 2) {
						w_first_1 = word_tmp[0] + " " + word_tmp[1];
						w_last_1 = word_tmp[word_tmp.length - 2] + " "
								+ word_tmp[word_tmp.length - 1];
						// first two words
						insert(mp_first_1, w_first_1, pro);
						// last two word
						insert(mp_last_1, w_last_1, pro);
					}

					// more than three words
					if (word_tmp.length >= 3) {
						w_first_2 = word_tmp[0] + " " + word_tmp[1] + " "
								+ word_tmp[2];
						w_last_2 = word_tmp[word_tmp.length - 3] + " "
								+ word_tmp[word_tmp.length - 2] + " "
								+ word_tmp[word_tmp.length - 1];

						// first three words
						insert(mp_first_2, w_first_2, pro);
						// last three word
						insert(mp_last_2, w_last_2, pro);
					}

					// more than four words
					if (word_tmp.length >= 4) {
						w_first_3 = word_tmp[0] + " " + word_tmp[1] + " "
								+ word_tmp[2] + " " + word_tmp[3];
						w_last_3 = word_tmp[word_tmp.length - 4] + " "
								+ word_tmp[word_tmp.length - 3] + " "
								+ word_tmp[word_tmp.length - 2] + " "
								+ word_tmp[word_tmp.length - 1];
						// first four words
						insert(mp_first_3, w_first_3, pro);
						// last four word
						insert(mp_last_3, w_last_3, pro);
					}

					// more than five words
					if (word_tmp.length >= 5) {
						w_first_4 = word_tmp[0] + " " + word_tmp[1] + " "
								+ word_tmp[2] + " " + word_tmp[3] + " "
								+ word_tmp[4];
						w_last_4 = word_tmp[word_tmp.length - 5] + " "
								+ word_tmp[word_tmp.length - 4] + " "
								+ word_tmp[word_tmp.length - 3] + " "
								+ word_tmp[word_tmp.length - 2] + " "
								+ word_tmp[word_tmp.length - 1];
						// first five words
						insert(mp_first_4, w_first_4, pro);
						// last five word
						insert(mp_last_4, w_last_4, pro);

					}

					// more than six words
					if (word_tmp.length >= 6) {
						w_first_5 = word_tmp[0] + " " + word_tmp[1] + " "
								+ word_tmp[2] + " " + word_tmp[3] + " "
								+ word_tmp[4] + " " + word_tmp[5];
						w_last_5 = word_tmp[word_tmp.length - 6] + " "
								+ word_tmp[word_tmp.length - 5] + " "
								+ word_tmp[word_tmp.length - 4] + " "
								+ word_tmp[word_tmp.length - 3] + " "
								+ word_tmp[word_tmp.length - 2] + " "
								+ word_tmp[word_tmp.length - 1];
						// first five words
						insert(mp_first_5, w_first_5, pro);
						// last five word
						insert(mp_last_5, w_last_5, pro);
					}

				}

			}
			System.out.println("Reading files finished!");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null) {
				try {
					reader1.close();
				} catch (IOException e1) {
				}
			}
		}
	}
	
	public void sort_and_write(BufferedWriter writer, List<Entry<String, Float>> list) throws IOException {
		Collections.sort(list, new Comparator<Map.Entry<String, Float>>() {
			public int compare(Map.Entry<String, Float> o1,
					Map.Entry<String, Float> o2) {
				float v1 = o1.getValue();
				float v2 = o2.getValue();
				if ((v1 - v2) > 0)
					return -1;
				if ((v1 - v2) < 0)
					return 1;
				return 0;
			}
		});

		for (int i = 0; i < list.size(); i++) {
			writer.write(list.get(i).getKey() + "	"
					+ list.get(i).getValue());
			writer.write("\n");
		}

		writer.close();
	}
	
	public void print_first_last() throws IOException {
		try {
			pt_out_first_0 = new File(pt_file + "_first_0");
			pt_out_first_1 = new File(pt_file + "_first_1");
			pt_out_first_2 = new File(pt_file + "_first_2");
			pt_out_first_3 = new File(pt_file + "_first_3");
			pt_out_first_4 = new File(pt_file + "_first_4");
			pt_out_first_5 = new File(pt_file + "_first_5");

			pt_out_last_0 = new File(pt_file + "_last_0");
			pt_out_last_1 = new File(pt_file + "_last_1");
			pt_out_last_2 = new File(pt_file + "_last_2");
			pt_out_last_3 = new File(pt_file + "_last_3");
			pt_out_last_4 = new File(pt_file + "_last_4");
			pt_out_last_5 = new File(pt_file + "_last_5");

			BufferedWriter writer_f_0 = new BufferedWriter(new FileWriter(
					pt_out_first_0));
			BufferedWriter writer_f_1 = new BufferedWriter(new FileWriter(
					pt_out_first_1));
			BufferedWriter writer_f_2 = new BufferedWriter(new FileWriter(
					pt_out_first_2));
			BufferedWriter writer_f_3 = new BufferedWriter(new FileWriter(
					pt_out_first_3));
			BufferedWriter writer_f_4 = new BufferedWriter(new FileWriter(
					pt_out_first_4));
			BufferedWriter writer_f_5 = new BufferedWriter(new FileWriter(
					pt_out_first_5));

			BufferedWriter writer_l_0 = new BufferedWriter(new FileWriter(
					pt_out_last_0));
			BufferedWriter writer_l_1 = new BufferedWriter(new FileWriter(
					pt_out_last_1));
			BufferedWriter writer_l_2 = new BufferedWriter(new FileWriter(
					pt_out_last_2));
			BufferedWriter writer_l_3 = new BufferedWriter(new FileWriter(
					pt_out_last_3));
			BufferedWriter writer_l_4 = new BufferedWriter(new FileWriter(
					pt_out_last_4));
			BufferedWriter writer_l_5 = new BufferedWriter(new FileWriter(
					pt_out_last_5));

			List<Entry<String, Float>> list_f_0 = new ArrayList<Entry<String, Float>>(
					mp_first_0.entrySet());
			sort_and_write(writer_f_0, list_f_0);
			
			List<Entry<String, Float>> list_f_1 = new ArrayList<Entry<String, Float>>(
					mp_first_1.entrySet());
			sort_and_write(writer_f_1, list_f_1);
			
			List<Entry<String, Float>> list_f_2 = new ArrayList<Entry<String, Float>>(
					mp_first_2.entrySet());
			sort_and_write(writer_f_2, list_f_2);
			
			List<Entry<String, Float>> list_f_3 = new ArrayList<Entry<String, Float>>(
					mp_first_3.entrySet());
			sort_and_write(writer_f_3, list_f_3);
			
			List<Entry<String, Float>> list_f_4 = new ArrayList<Entry<String, Float>>(
					mp_first_4.entrySet());
			sort_and_write(writer_f_4, list_f_4);
			
			List<Entry<String, Float>> list_f_5 = new ArrayList<Entry<String, Float>>(
					mp_first_5.entrySet());
			sort_and_write(writer_f_5, list_f_5);
			
			List<Entry<String, Float>> list_l_0 = new ArrayList<Entry<String, Float>>(
					mp_last_0.entrySet());
			sort_and_write(writer_l_0, list_l_0);
			
			List<Entry<String, Float>> list_l_1 = new ArrayList<Entry<String, Float>>(
					mp_last_1.entrySet());
			sort_and_write(writer_l_1, list_l_1);
			
			List<Entry<String, Float>> list_l_2 = new ArrayList<Entry<String, Float>>(
					mp_last_2.entrySet());
			sort_and_write(writer_l_2, list_l_2);
			
			List<Entry<String, Float>> list_l_3 = new ArrayList<Entry<String, Float>>(
					mp_last_3.entrySet());
			sort_and_write(writer_l_3, list_l_3);
			
			List<Entry<String, Float>> list_l_4 = new ArrayList<Entry<String, Float>>(
					mp_last_4.entrySet());
			sort_and_write(writer_l_4, list_l_4);
			
			List<Entry<String, Float>> list_l_5 = new ArrayList<Entry<String, Float>>(
					mp_last_5.entrySet());
			sort_and_write(writer_l_5, list_l_5);

			
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null) {
				try {
					reader1.close();
				} catch (IOException e1) {
				}
			}
		}
	}

}
