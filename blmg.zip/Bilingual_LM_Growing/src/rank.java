import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;


public class rank {
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("This is to rank the phrases.");
		System.out.println("0: phrases with probabilities; 1-ranked files");
		System.out.println(args[0]);  
		System.out.println(args[1]);  
		File file_i1 = new File(args[0]);
		File file_o = new File(args[1]); 
		String tempString = null;
		String tb = "	";
		BufferedReader reader1 = null;
		BufferedWriter writer = null;
		reader1 = new BufferedReader(new FileReader(file_i1));
		Map<Object, Float> mp = new HashMap<Object, Float>();
		try {
			writer = new BufferedWriter(new FileWriter(file_o));
			while ((tempString = reader1.readLine()) != null) {
				int start = tempString.indexOf(tb);
				if(start != -1){
					String words = tempString.substring(0, start);
					float num=Float.parseFloat(tempString.substring(start+1));
					if (mp.containsKey(words)){
						num = mp.get(words) + num;
					}else{
					mp.put(words, num);
					}
				}else{
				}
			}
			List<Entry<Object,Float>> list1 = new ArrayList<Entry<Object,Float>>(mp.entrySet());

			Collections.sort(list1, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list1.size(); i++) {   
				writer.write(list1.get(i).getKey() + "	" + list1.get(i).getValue());  
				writer.write("\n");  
			}  

			writer.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null) {
				try {
					reader1.close();
				} catch (IOException e1) {
				}
			}
		}



		//System.out.println(mp);
	}
}
