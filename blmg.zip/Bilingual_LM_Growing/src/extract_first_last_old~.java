import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


public class extract_first_last {
	public static void main(String[] args) throws FileNotFoundException {
		System.out.println("This is to extract the first/last words with translation probabilities from the target words with appearing probabilities:");
		System.out.println("0: target words with appearing probabilities;");
		System.out.println(args[0]);
		File file_i1 = new File(args[0]);
		File file_o = new File(args[0] + ".first");
		File file_o2 = new File(args[0] + ".first-two");
		File file_o3 = new File(args[0] + ".first-three");
		File file_o4 = new File(args[0] + ".first-four");
		File file_o5 = new File(args[0] + ".last");
		File file_o6 = new File(args[0] + ".last-two");
		File file_o7 = new File(args[0] + ".last-three");
		File file_o8 = new File(args[0] + ".last-four");
		File file_o9 = new File(args[0] + ".first-five");
		File file_o10 = new File(args[0] + ".last-five");

		Map<Object, Float> mp1=new HashMap<Object, Float>();
		Map<Object, Float> mp2=new HashMap<Object, Float>();
		Map<Object, Float> mp3=new HashMap<Object, Float>();
		Map<Object, Float> mp4=new HashMap<Object, Float>();
		Map<Object, Float> mp5=new HashMap<Object, Float>();
		Map<Object, Float> mp6=new HashMap<Object, Float>();
		Map<Object, Float> mp7=new HashMap<Object, Float>();
		Map<Object, Float> mp8=new HashMap<Object, Float>();
		Map<Object, Float> mp9=new HashMap<Object, Float>();
		Map<Object, Float> mp10=new HashMap<Object, Float>();

		String tempString = null;
		String tb = "	";
		String space = " ";


		String first_word;
		String except_first_word;
		String second_word;
		String except_second_word;
		String third_word;
		String except_third_word;
		String fourth_word;
		String except_fourth_word;
		String fifth_word;


		String last_word;
		String except_last_word;
		String last_second_word;
		String except_last_second_word;
		String last_third_word;
		String except_last_third_word;
		String last_fourth_word;
		String except_last_fourth_word;
		String last_fifth_word;


		BufferedReader reader1 = null;
		BufferedWriter writer = null;
		BufferedWriter writer2 = null;
		BufferedWriter writer3 = null;
		BufferedWriter writer4 = null;
		BufferedWriter writer5 = null;
		BufferedWriter writer6 = null;
		BufferedWriter writer7 = null;
		BufferedWriter writer8 = null;
		BufferedWriter writer9 = null;
		BufferedWriter writer10 = null;


		reader1 = new BufferedReader(new FileReader(file_i1));


		try {
			writer = new BufferedWriter(new FileWriter(file_o));
			writer2 = new BufferedWriter(new FileWriter(file_o2));
			writer3 = new BufferedWriter(new FileWriter(file_o3));
			writer4 = new BufferedWriter(new FileWriter(file_o4));
			writer5 = new BufferedWriter(new FileWriter(file_o5));
			writer6 = new BufferedWriter(new FileWriter(file_o6));
			writer7 = new BufferedWriter(new FileWriter(file_o7));
			writer8 = new BufferedWriter(new FileWriter(file_o8));
			writer7 = new BufferedWriter(new FileWriter(file_o9));
			writer8 = new BufferedWriter(new FileWriter(file_o10));


			while ((tempString = reader1.readLine()) != null) {
				int start = tempString.indexOf(tb);
				if(start != -1){


					String words = tempString.substring(0, start);
					float num=Float.parseFloat(tempString.substring(start+1));


					//extract the last words
					int last_space = words.lastIndexOf(space);
					if(last_space != -1){
						last_word = words.substring(last_space+1);
						if(mp5.containsKey(last_word)){
							float n = mp5.get(last_word);
							float tmp = n + num;
							mp5.put(last_word, tmp);
						}else{
							mp5.put(last_word, num);
						}
						//writer5.write(last_word + "	" + num);
						//writer5.write("\n");
						except_last_word = words.substring(0, last_space);
						int last_second_space = except_last_word.lastIndexOf(space);
						if (last_second_space != -1){
							last_second_word = except_last_word.substring(last_second_space + 1);
							if(mp6.containsKey(last_second_word + " " + last_word)){
								float n = mp6.get(last_second_word + " " + last_word);
								float tmp = n + num;
								mp6.put(last_second_word + " " + last_word, tmp);
							}else{
								mp6.put(last_second_word + " " + last_word, num);
							}
							//writer6.write(last_second_word + " " + last_word + "	" + num);
							//writer6.write("\n");
							except_last_second_word = except_last_word.substring(0, last_second_space);
							int last_third_space = except_last_second_word.lastIndexOf(space);
							if (last_third_space != -1){
								last_third_word = except_last_second_word.substring(last_third_space + 1);
								if(mp7.containsKey(last_third_word + " " + last_second_word + " " + last_word)){
									float n = mp7.get(last_third_word + " " + last_second_word + " " + last_word);
									float tmp = n + num;
									mp7.put(last_third_word + " " + last_second_word + " " + last_word, tmp);
								}else{
									mp7.put(last_third_word + " " + last_second_word + " " + last_word, num);
								}
								//writer7.write(last_third_word + " " + last_second_word + " " + last_word + "	" + num);
								//writer7.write("\n");
								except_last_third_word = except_last_second_word.substring(0, last_third_space);
								int last_fourth_space = except_last_third_word.lastIndexOf(space);
								if (last_fourth_space != -1){
									last_fourth_word = except_last_third_word.substring(last_fourth_space + 1);
									if(mp8.containsKey(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word)){
										float n = mp8.get(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word);
										float tmp = n + num;
										mp8.put(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word, tmp);
									}else{
										mp8.put(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word, num);
									}
									//writer8.write(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word + "	" + num);
									//writer8.write("\n");
								}else{
									last_fourth_word = except_last_third_word;
									if(mp8.containsKey(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word)){
										float n = mp8.get(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word);
										float tmp = n + num;
										mp8.put(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word, tmp);
									}else{
										mp8.put(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word, num);
									}
									//writer8.write(last_fourth_word + " " + last_third_word + " " + last_second_word + " " + last_word + "	" + num);
									//writer8.write("\n");
								}
							}else{
								last_third_word = except_last_second_word;
								if(mp7.containsKey(last_third_word + " " + last_second_word + " " + last_word)){
									float n = mp7.get(last_third_word + " " + last_second_word + " " + last_word);
									float tmp = n + num;
									mp7.put(last_third_word + " " + last_second_word + " " + last_word, tmp);
								}else{
									mp7.put(last_third_word + " " + last_second_word + " " + last_word, num);
								}
								//writer7.write(last_third_word + " " + last_second_word + " " + last_word + "	" + num);
								//writer7.write("\n");
							}
						}else{

							last_second_word = except_last_word;
							if(mp6.containsKey(last_second_word + " " + last_word)){
								float n = mp6.get(last_second_word + " " + last_word);
								float tmp = n + num;
								mp6.put(last_second_word + " " + last_word, tmp);
							}else{
								mp6.put(last_second_word + " " + last_word, num);
							}

							//writer6.write(last_second_word + " " + last_word + "	" + num);
							//writer6.write("\n");	
						}
					}else{


						last_word = words;
						if(mp5.containsKey(last_word)){
							float n = mp5.get(last_word);
							float tmp = n + num;
							mp5.put(last_word, tmp);
						}else{
							mp5.put(last_word, num);
						}


						//writer5.write(last_word + "	" + num);
						//writer5.write("\n");	
					}


					//extract the first words
					int first_space = words.indexOf(space);
					if(first_space != -1){
						first_word = words.substring(0, first_space);
						if(mp1.containsKey(first_word)){
							float n = mp1.get(first_word);
							float tmp = n + num;
							mp1.put(first_word, tmp);
							if(first_word.equals("anti-alcam"))
								System.out.println(num);
						}else{
							mp1.put(first_word, num);
						}
						//writer.write(first_word + "	" + num);
						//writer.write("\n");	
						except_first_word = words.substring(first_space+1);
						int second_space = except_first_word.indexOf(space);
						if(second_space != -1){
							second_word = except_first_word.substring(0, second_space);
							if(mp2.containsKey(first_word + " " + second_word)){
								float n = mp2.get(first_word + " " + second_word);
								float tmp = n + num;
								mp2.put(first_word + " " + second_word, tmp);
							}else{
								mp2.put(first_word + " " + second_word, num);
							}
							//writer2.write(first_word + " " + second_word + "	" + num);
							//writer2.write("\n");
							except_second_word = except_first_word.substring(second_space + 1);
							int third_space = except_second_word.indexOf(space);
							if(third_space != -1){
								third_word = except_second_word.substring(0, third_space);
								if(mp3.containsKey(first_word)){
									float n = mp3.get(first_word + " " + second_word + " " + third_word);
									float tmp = n + num;
									mp3.put(first_word + " " + second_word + " " + third_word, tmp);
								}else{
									mp3.put(first_word + " " + second_word + " " + third_word, num);
								}
								//writer3.write(first_word + " " + second_word + " " + third_word + "	" + num);
								//writer3.write("\n");
								except_third_word = except_second_word.substring(third_space + 1);
								int fourth_space = except_third_word.indexOf(space);
								if(fourth_space != -1){
									fourth_word = except_third_word.substring(0, fourth_space);
									if(mp4.containsKey(first_word + " " + second_word + " " + third_word + " " + fourth_word)){
										float n = mp4.get(first_word + " " + second_word + " " + third_word + " " + fourth_word);
										float tmp = n + num;
										mp4.put(first_word + " " + second_word + " " + third_word + " " + fourth_word, tmp);
									}else{
										mp4.put(first_word + " " + second_word + " " + third_word + " " + fourth_word, num);
									}
									//writer4.write(first_word + " " + second_word + " " + third_word + " " + fourth_word  +"	" + num);
									//writer4.write("\n");
								}else{
									fourth_word = except_third_word;
									if(mp4.containsKey(first_word + " " + second_word + " " + third_word + " " + fourth_word)){
										float n = mp4.get(first_word + " " + second_word + " " + third_word + " " + fourth_word);
										float tmp = n + num;
										mp4.put(first_word + " " + second_word + " " + third_word + " " + fourth_word, tmp);
									}else{
										mp4.put(first_word + " " + second_word + " " + third_word + " " + fourth_word, num);
									}
									//writer4.write(first_word + " " + second_word + " " + third_word + " " + fourth_word  +"	" + num);
									//writer4.write("\n");
								}
							}else{
								third_word = except_second_word;
								if(mp3.containsKey(first_word)){
									float n = mp3.get(first_word + " " + second_word + " " + third_word);
									float tmp = n + num;
									mp3.put(first_word + " " + second_word + " " + third_word, tmp);
								}else{
									mp3.put(first_word + " " + second_word + " " + third_word, num);
								}
								//writer3.write(first_word + " " + second_word + " " + third_word + "	" + num);
								//writer3.write("\n");
							}
						}else{
							second_word = except_first_word;
							if(mp2.containsKey(first_word + " " + second_word)){
								float n = mp2.get(first_word + " " + second_word);
								float tmp = n + num;
								mp2.put(first_word + " " + second_word, tmp);
							}else{
								mp2.put(first_word + " " + second_word, num);
							}
							//writer2.write(first_word + " " + second_word + "	" + num);
							//writer2.write("\n");	
						}

					}else{
						first_word = words;
						if(mp1.containsKey(first_word)){
							float n = mp1.get(first_word);
							float tmp = n + num;
							mp1.put(first_word, tmp);
							if(first_word.equals("anti-alcam"))
								System.out.println(num);
						}else{
							mp1.put(first_word, num);
						}
						//writer.write(first_word + "	" + num);
						//writer.write("\n");	
					}
				}else{
				}


			}


			List<Entry<Object,Float>> list1 = new ArrayList<Entry<Object,Float>>(mp1.entrySet());

			Collections.sort(list1, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list1.size(); i++) {   
	            writer.write(list1.get(i).getKey() + "	" + list1.get(i).getValue());  
	            writer.write("\n");  
	        }  
			
			writer.close();

			List<Entry<Object,Float>> list2 = new ArrayList<Entry<Object,Float>>(mp2.entrySet());

			Collections.sort(list2, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list2.size(); i++) {  
	            writer2.write(list2.get(i).getKey() + "	" + list2.get(i).getValue());  
	            writer2.write("\n");
	        }  
			writer2.close();

			List<Entry<Object,Float>> list3 = new ArrayList<Entry<Object,Float>>(mp3.entrySet());

			Collections.sort(list3, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list3.size(); i++) {  
	            writer3.write(list3.get(i).getKey() + "	" + list3.get(i).getValue());  
	            writer3.write("\n");
	        }  
			writer3.close();

			List<Entry<Object,Float>> list4 = new ArrayList<Entry<Object,Float>>(mp4.entrySet());

			Collections.sort(list4, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list4.size(); i++) {  
	            writer4.write(list4.get(i).getKey() + "	" + list4.get(i).getValue());  
	            writer4.write("\n"); 
	        }  
			writer4.close();

			List<Entry<Object,Float>> list5 = new ArrayList<Entry<Object,Float>>(mp5.entrySet());

			Collections.sort(list5, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list5.size(); i++) {  
	            writer5.write(list5.get(i).getKey() + "	" + list5.get(i).getValue());  
	            writer5.write("\n");
	        }  
			
			writer5.close();

			List<Entry<Object,Float>> list6 = new ArrayList<Entry<Object,Float>>(mp6.entrySet());

			Collections.sort(list6, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list6.size(); i++) {  
	            writer6.write(list6.get(i).getKey() + "	" + list6.get(i).getValue());  
	            writer6.write("\n");
	        }  
			
			writer6.close();

			List<Entry<Object,Float>> list7 = new ArrayList<Entry<Object,Float>>(mp7.entrySet());

			Collections.sort(list7, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list7.size(); i++) {  
	            writer7.write(list7.get(i).getKey() + "	" + list7.get(i).getValue());  
	            writer7.write("\n");
	        }  
			
			writer7.close();

			List<Entry<Object,Float>> list8 = new ArrayList<Entry<Object,Float>>(mp8.entrySet());

			Collections.sort(list8, new Comparator<Map.Entry<Object, Float>>() {
				public int compare(Map.Entry<Object, Float> o1,
						Map.Entry<Object, Float> o2) { 
					float v1 = o1.getValue();  
					float v2 = o2.getValue();  
					if ((v1 - v2) > 0)  
						return -1;  
					if ((v1 - v2) < 0)  
						return 1;  
					return 0;  
				}
			});

			for (int i = 0; i < list8.size(); i++) {  
	            writer8.write(list8.get(i).getKey() + "	" + list8.get(i).getValue());  
	            writer8.write("\n");
	        }  
			
			writer8.close();

			System.out.println("All  finished-Version6");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader1 != null) {
				try {
					reader1.close();
				} catch (IOException e1) {
				}
			}
		}



		//System.out.println(mp);
	}
}
