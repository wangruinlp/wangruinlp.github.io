This is a instruction to bilingual LM growing.
The procedure is as follows:

(1) Build a BNLM:
The SRILM should be installed at first.
(1.1)target LM: /panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram-count -order 5 -interpolate -kndiscount -gt1min 0 -gt2min 0 -gt3min 0 -gt4min 0 -gt5min 0 -unk -text train.target -lm /panfs/panmt/users/rwang/lm/bnlm
(1.2)Souce counts: /panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram-count -order 5 -text train.source -write fcount


(2) Construct the phrase-table:
The GIZA++ should be installed at first.
nohup nice /panfs/panltg2/users/rwang/smt/mosesdecoder/scripts/training/train-model.perl -external-bin-dir /panfs/panltg2/users/rwang/smt/external-bin-dir -mgiza -mgiza-cpus 30 -root-dir train -corpus train.tok -f zh -e en --parallel -alignment grow-diag-final-and -reordering msd-bidirectional-fe -lm 0:5:BNLM  >& training.out &

(3) Construct the "connecting phrases":
(3.1) src/extract_phrases.java: This is to extract the words with translation probabilities from the phrase-table.
(3.2) src/fe.java: this is to calculate p(e) = p(f)*p(e|f).
(3.3) src/extract_first_last.java: This is to extract the first/last words with translation probabilities from the target words with appearing probabilities.
For the 4-grams, there are 1-3, 2-2, and 3-1 three types of connnecting phrases.
(3.4) src/rank.java: This is to rank the phrases.
(3.5) src/prob_filter.java: This is to select the top phrases.
(3.6) src/combine_last_first.java: This is to construct the connecting phrases using the first and last words.
(3.7) src/rank.java: This is to rank the connecting phrases.

(4) Build a CSLM:
The modified SRILM should be installed at first. Please refer to the cslm_modified.tar.gz.

The training manual is the cslm/com.csh, train.df, and dev.df.

(5) Calculate the probabilities using CSLM; This step is split into two steps:  

(5.1) Calculate the probabilities of BNLM using CSLM
(5.1.1) src/arpa_splt.java: This is to split the ARPA file into unigram,bigram,...

for (n=2;n<=5;n++)
{
(5.1.2) Converting CSLM into BNLM/src/extract_s_unk.java: This is to split n-gram into the one containing <s> and the one without <s>.
(5.1.3) Converting CSLM into BNLM/src/extract_ngrams_from_arpa: This is to extract n-grams from arpa-file.
(5.1.4) Take the output n-grams of (3.3) as the input of CSLM:
(5.1.4.1) Text to Binary:  /panfs/panmt/users/rwang/cslm-original/src/text2bin ./lm/all.vocab ./data.cslm/output n-grams of (5.1.3).btxt ./data.cslm/output n-grams of (5.1.3).wlist ./data.cslm/output n-grams of (5.1.3).oov < ./data/output n-grams of (5.1.3)
(5.1.4.2) Calculate the probabilities: /panfs/panmt/users/rwang/tools/cslm/cslm_eval -m tutorial-c1-p256-h384-s8192-lr1.best.mach -w ./data.cslm/train.tok.wlall.wlist -l ./lm/bnlm -O 5 -t ./data.cslm/output n-grams of (5.1.3).wlist -p the probabilities file -R > log-file
(5.1.5) Converting CSLM into BNLM/src/extract_truefile_from_cslm.java: This is to extract the true n-gram with probabilities from the CSLM file
(5.1.6) Converting CSLM into BNLM/src/combine_nnlm_bnlm.java: This is to combine cslm and bnlm, the fake backoff-weights are added to the end of the file
 }
 

(5.2) Calculate the probabilities of connecting phrases using CSLM
for (n=2;n<=5;n++)
{
(5.2.1) Take the output n-gram connecting phrases as the input of CSLM:
(5.2.1.1) Text to Binary:  /panfs/panmt/users/rwang/cslm-original/src/text2bin ./lm/all.vocab ./data.cslm/output n-grams of (3.3).btxt ./data.cslm/output n-grams of (3.3).wlist ./data.cslm/output n-grams of (3.3).oov < ./data/output n-grams of (3.3)
(5.2.1.2) Calculate the probabilities: /panfs/panmt/users/rwang/tools/cslm/cslm_eval -m tutorial-c1-p256-h384-s8192-lr1.best.mach -w ./data.cslm/train.tok.wlall.wlist -l ./lm/bnlm -O 5 -t ./data.cslm/output n-grams of (3.3).wlist -p the probabilities file -R > log-file
(5.2.2) src/extract_truefile_from_cslm.java: This is to extract the true n-gram with probabilities from the CSLM file
(5.2.3) src/combine_nnlm_bnlm.java: This is to combine cslm and n-gram connecting phrases, the fake backoff-weights are added to the end of the file
 }
 
(5.3) Combine the new n-grams (n=2,3,4,5) with the original unigram from (5.1) and (5.2) together into the new Grown CSLM (GROWN)

(6) Re-normalize the CONV:
/panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram -lm GROWN -order 5 -renorm -write-lm GROWN.re

(6) Interpolate with the BNLM (optional):
/panfs/panltg2/users/rwang/srilm/bin/i686-m64/ngram -lm GROWN.re -order 5 -mix-lm BNLM -lambda 0.5 -write-lm GROWN.inter
