/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachMulti.cpp,v 1.20 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"
#include "MachMulti.h"

MachMulti::MachMulti()
 : Mach(0,0,0)
{
  machs.clear();
}

MachMulti::~MachMulti()
{
  MachMulti::Delete();
  machs.clear();
}

void MachMulti::Delete()
{
  for (unsigned int m=0; m<machs.size(); m++) delete machs[m];
}

void MachMulti::MachAdd(Mach *new_mach)
{
  Error("MachAdd not defined for abstract multiple machine");
}

Mach *MachMulti::MachDel()
{
  Error("MachDel not defined for abstract multiple machine");
  return NULL;
}

int MachMulti::GetNbParams() {
  int sum=0;

  for (vector<Mach*>::iterator it = machs.begin(); it!=machs.end(); ++it) {
    sum += (*it)->GetNbParams();
  }
  return sum;
}

//-----------------------------------------------
// File output
//-----------------------------------------------


void MachMulti::WriteParams(ofstream &of) {
  Mach::WriteParams(of);
  int nbm=machs.size();
  of.write((char*) &nbm, sizeof(int));
}

void MachMulti::WriteData(ofstream &outf) {
  int nbm=machs.size(), s=sizeof(REAL);
  outf.write((char*) &nbm, sizeof(int));
  outf.write((char*) &s, sizeof(int));
  for (vector<Mach*>::iterator it = machs.begin(); it!=machs.end(); ++it) {
    (*it)->Write(outf);
  }
}

//-----------------------------------------------
// File input
//-----------------------------------------------

void MachMulti::ReadParams(ifstream &inpf, bool with_alloc)
{
  if (machs.size() > 0)
    Error("Trying to read multiple machine into non empty data structures\n");

  Mach::ReadParams(inpf, false);
  int nbm;
  inpf.read((char*) &nbm, sizeof(int));
  if (nbm<1) Error("illegal number of machines");
  machs.clear();
  for (int i=0; i<nbm; i++) machs.push_back(NULL);
}

void MachMulti::ReadData(ifstream &inpf, size_t s)
{
  if (s!=machs.size()) {
    cerr << "ERROR: data block of multiple machine has " << s << " machines (" << machs.size() << " were expected)" << endl;    Error();
  } 
  
  for (vector<Mach*>::iterator it = machs.begin(); it!=machs.end(); ++it) {
    (*it) = Mach::Read(inpf);
  }
}

//
// Tools
//

void MachMulti::SetBsize(int bs)
{
  if (bs<1) Error("wrong value in SetBsize()");
  for (uint i=0; i<machs.size(); i++) machs[i]->SetBsize(bs);
}

void MachMulti::Info(bool detailed, char *txt)
{
  if (detailed) {
    if (machs.size()) {
      Mach::Info();
      for (unsigned int i=0; i<machs.size(); i++) {
        cout << "MACHINE " << i << ": " << endl;
        machs[i]->Info();
      }
    }
    else
      cout << " *** empty ***" << endl;
  }
  else {
    printf("%sMultiple machine %d- .. -%d, bs=%d, passes=%d/%d", txt, idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");
    char ntxt[256];
    sprintf(ntxt,"%s  ", txt);
    for (unsigned int i=0; i<machs.size(); i++) machs[i]->Info(detailed, ntxt);
  }
  printf("%stotal number of parameters: %d (%d MBytes)\n", txt, GetNbParams(), (int) (GetNbParams()*sizeof(REAL)/1048576));
}

void MachMulti::Forw(int eff_bszie)
{
  if (machs.empty())
    Error("called Forw() for an empty multiple machine");
  else
    Error("call to Forw() not defined for an abstract multiple machine");
}

void MachMulti::Backw(const float lrate, const float wdecay, int eff_bsize)
{
  Error("call to Backw() not defined for an abstract multiple machine");
}

