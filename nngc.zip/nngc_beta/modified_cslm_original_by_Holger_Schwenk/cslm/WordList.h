/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2010, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: $
 */

#ifndef _WordList_h
#define _WordList_h

#include "DataNgramBin.h" // for type WordID

struct WList {
  char *word;   // UTF8 word
  WordID id;    // sequential number
  int  n;       // count
};

/*
class WordList {
 private:
   vector<WList> wlist;
 public:
  WordList(char *fname);
  ~WordList();
    // access functions to wordlist, needed to set up interface with back-off LM
  int GetSize() {return wlist.size();}
  int GetWlist() {retunr wlist.size();}
    //
};
*/

#endif
