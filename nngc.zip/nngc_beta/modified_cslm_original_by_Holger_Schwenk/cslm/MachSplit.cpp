/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachSplit.cpp,v 1.16 2012/06/02 17:19:10 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"
#include "MachSplit.h"

MachSplit::MachSplit()
 : MachMulti()
{
}

MachSplit::~MachSplit()
{
  // data_out and grad_in will be freed by Mach::~Mach()
}
 
void MachSplit::MachAdd(Mach *new_mach)
{
  if (machs.empty()) {
    machs.push_back(new_mach);
	// think about freeing memory
    idim=new_mach->GetIdim();
    odim=new_mach->GetOdim();
    bsize=new_mach->GetBsize();
    data_in=NULL; // will be set by MachSplit::SetDataIn()
    data_out = (odim*bsize>0) ? new REAL[odim*bsize] : NULL;
    grad_in = (idim*bsize>0) ? new REAL[idim*bsize] : NULL;
    grad_out = NULL;
    new_mach->SetGradOut(grad_out);
  }
  else {
    if (bsize!=new_mach->GetBsize())
      Error("bunch size of new split machine does not match");
    if (idim!=new_mach->GetIdim())
      Error("input dimension of new split machine does not match");
    machs.push_back(new_mach);
 
      // resize output
    odim += new_mach->GetOdim();
#ifdef BLAS_CUDA
    if (data_out) cublasFree(data_out);
    data_out = cuda_alloc(odim*bsize, "resized output data in split machine");
#else
    if (data_out) delete [] data_out;
    data_out = (odim*bsize>0) ? new REAL[odim*bsize] : NULL;
#endif
    new_mach->SetDataIn(data_in);
  }
}

Mach *MachSplit::MachDel()
{
  if (machs.empty()) {
    Error("impossible to delete element from split machine: is already empty");
  }
  
  Mach *del_mach=machs.back();
  machs.pop_back();

  if (machs.empty()) {
    idim=odim=bsize=0;
#ifdef BLAS_CUDA
    if (data_out) cublasFree(data_out);
    if (grad_in) cublasFree(grad_in);
#else
    if (data_out) delete [] data_out;
    if (grad_in) delete [] grad_in;
#endif
    data_in=data_out=grad_in=grad_out=NULL;
  }
  else {
      // resize output
    odim -= del_mach->GetOdim();
#ifdef BLAS_CUDA
    if (data_out) cublasFree(data_out);
    data_out = cuda_alloc(odim*bsize, "resized output data in split machine");
#else
    if (data_out) delete [] data_out;
    data_out = (odim*bsize>0) ? new REAL[odim*bsize] : NULL;
#endif
  }

  return del_mach;
}

// set pointer of input data
void MachSplit::SetDataIn(REAL *data)
{
  data_in=data;
    // all machines point on the same input
  for (unsigned int m=0; m<machs.size(); m++) machs[m]->SetDataIn(data_in);
}

// set pointer of output gradient
void MachSplit::SetGradOut(REAL *data)
{
  grad_out=data;

    // set output gradients of inidv machines one after each other
  for (unsigned int m=0; m<machs.size(); m++) {
    machs[m]->SetGradOut(data);
    data += machs[m]->GetOdim();
  }
}


//-----------------------------------------------
// File input
//-----------------------------------------------


void MachSplit::ReadData(ifstream &inpf, size_t s)
{
  MachMulti::ReadData(inpf,s);

     // calculate idim and odim and and allocate data_out and grad_in
  idim=odim=0;
  for (uint m=0; m<machs.size(); m++) {
    idim += machs[m]->GetIdim();
    odim += machs[m]->GetOdim();
  }
  bsize = machs[0]->GetBsize();
  // TODO: do_alloc();

}

//
// Tools
//

void MachSplit::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << "Information on split machine" << endl;
    MachMulti::Info(detailed);
  }
  else {
    printf(" - Split machine %d-%d, bs=%d, passes=%d/%d", idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");
    char ntxt[512];
    sprintf(ntxt,"%s  ", txt);
    for (unsigned int i=0; i<machs.size(); i++) machs[i]->Info(detailed, ntxt);
  }
  printf("%stotal number of parameters: %d (%d MBytes)\n", txt, GetNbParams(), GetNbParams()*(int) sizeof(REAL)/1048576);
}


// forward pass for all machines and copy output into cumulated output
void MachSplit::Forw(int eff_bsize)
{
  if (machs.empty())
    Error("called Forw() for an empty split machine");

#ifdef PROFILE
  tm.start();
#endif

  if (eff_bsize<=0) eff_bsize=bsize;

  REAL *optr=data_out;
  for (unsigned int m=0; m<machs.size(); m++) {
    machs[m]->Forw(eff_bsize);
    memcpy(optr, machs[m]->GetDataOut(), eff_bsize*machs[m]->GetOdim()*sizeof(REAL));
    optr += eff_bsize*machs[m]->GetOdim();
  }
  nb_forw += eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}

// backward pass for all machines and cumulate gradient at input
void MachSplit::Backw(const float lrate, const float wdecay, int eff_bsize)
{
  if (machs.empty())
    Error("called Backw() for an empty split machine");

  if (eff_bsize<=0) eff_bsize=bsize;
 
      // we need to set the pointers to output gradients of indiv machines
      // one after each other since this depends on the effective bsize !

#ifdef PROFILE
  tm.start();
#endif

   // backward 1st machine
  machs[0]->SetGradOut(grad_out); // actually already done
  machs[0]->Backw(lrate,wdecay,eff_bsize);
  memcpy(grad_in, machs[0]->GetGradIn(), idim*sizeof(REAL));

   // backward following machines, add gradient on existing ones
  REAL *optr=grad_out + eff_bsize*machs[0]->GetOdim();
  for (unsigned int m=1; m<machs.size(); m++) {
    machs[m]->SetGradOut(optr);
    machs[m]->Backw(lrate,wdecay,eff_bsize);
    for (int i=0; i<idim; i++) grad_in[i] += machs[m]->GetGradIn()[i];
    optr += eff_bsize*machs[m]->GetOdim();
  }
  nb_backw += eff_bsize; 

#ifdef PROFILE
  tm.stop();
#endif
}

