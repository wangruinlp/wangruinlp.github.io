/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: BackoffLmSri.cpp,v 1.6 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include "BackoffLmSri.h"

//
//
//

void BackoffLmSri::BackoffLmSri_init(char *p_fname, int p_max_order)
{
  if (p_max_order < 2)
    Error ("unsupported order of the SRI LM"); // TODO: give the acutal order

  sri_vocab = new Vocab();
 
  if (strstr(p_fname,".vocab")) {
    cout << " - vocabulary " << p_fname << "was specified instead of an LM" << endl;

    sri_vocab->unkIsWord() = true;
    sri_vocab->toLower() = false;
    {
      File file(p_fname, "r");
      sri_vocab->read(file);
      //voc->remove("-pau-");
    }
    cout << "  found "<< sri_vocab->numWords() << ", returning lnProp=" << NULL_LN_PROB << "in all calls" << endl;
    
    sri_order=p_max_order; // TODO: is this correct
    sri_ngram = NULL;
  }
  else {
    cout << " - reading back-off SRILM from file '" << p_fname << "'" << endl;
    sri_ngram = new Ngram(*sri_vocab, p_max_order);

      // reading SRI LM
    sri_ngram->setorder(p_max_order);
    sri_ngram->skipOOVs() = false;
    File ngram_file(p_fname, "r");
    sri_ngram->read(ngram_file, 0);

      // get number of n-grams
      // TODO: can we get the order of the model read from file ?
    vector<uint> nb_ngrams;
    nb_ngrams.push_back(sri_vocab->numWords());
    cout << "   vocabulary: " << nb_ngrams[0] << " words; ngrams:";
    sri_order=0;
    for (int o=1; o<=p_max_order; o++) {
      nb_ngrams.push_back(sri_ngram->numNgrams(o));
      cout << " " << nb_ngrams.back();
      if (nb_ngrams.back()>0) sri_order++;
    }
  }

  cout << " (order=" << sri_order << ")" << endl;
  if (sri_order > p_max_order) {
    cout << " - limiting order of the back-off LM to the order of the CSLM (" << p_max_order << ")" << endl;
     sri_order = p_max_order;
  }

#ifdef LM_SRI0
  for (i=wlist.begin(); i!=wlist.end(); i++) {
    int sri_idx = sri_vocab->getIndex((*i).word);
printf("word=%s, sri=%d, wlist=%d\n", (*i).word, sri_idx, (*i).id);
  }
#endif

    // reserve memory for the context in SRI format
  sri_context_idxs = new VocabIndex[sri_order+1];
  sri_context_idxs[sri_order-1]=Vocab_None; // terminate, this is needed to specify the length of the context

  map_cslm2sri.clear();
}

//
//
//

BackoffLmSri::BackoffLmSri(char *p_fname, int p_max_order, vector<WList> &wlist)
{
  BackoffLmSri::BackoffLmSri_init(p_fname, p_max_order);

    // set up mapping from CSLM indices to SRI LM indices
  cout << " - setting up mapping from CSLM to SRI word list" << endl;
  map_cslm2sri.reserve(wlist.size());
  for (vector<WList>::iterator i=wlist.begin(); i!=wlist.end(); i++) {
    VocabIndex vi = sri_vocab->getIndex((*i).word);
    if (vi == Vocab_None) {
      fprintf(stderr,"word %s not found at pos %d\n", (*i).word, (uint) (i-wlist.begin()) );
    }
    else
      map_cslm2sri[i-wlist.begin()] = vi;
  }
}

BackoffLmSri::~BackoffLmSri() {
  if (sri_vocab) delete sri_vocab;
  if (sri_ngram) delete sri_ngram;     
  map_cslm2sri.clear();
 if (sri_context_idxs)  delete [] sri_context_idxs;
}
