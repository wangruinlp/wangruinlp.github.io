/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: cslm_eval.cpp,v 1.15 2012/06/03 20:51:35 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <getopt.h>

#include "Mach.h"
#include "DataNgramBin.h"
#include "TrainerNgramSlist.h"
#include "ErrFctSoftmCrossEntNgram.h"


static struct option long_options[] =
  {
    {"mach",1,0,'m'},
    {"word-list",1,0,'w'},
    {"train-data",1,0,'t'},
    {"dev-data",1,0,'d'},
    {"lm",1,0,'l'},
    {"lrate-beg",1,0,'L'},
    {"lrate-mult",1,0,'M'},
    {"weight-decay",1,0,'W'},
    {"last-iteration",1,0,'I'},
    {"block-size",1,0,'B'},
#ifdef BLAS_CUDA
    {"cuda-device",1,0,'D'},
#endif
    {0, 0, 0, 0}
  };
int option_index;

void usage (bool do_exit=true)
{
   cout <<  endl
        << "cslm_eval " << cslm_version << " - a tool to train continuous space language models" << endl
	<< "Copyright (C) 2012 Holger Schwenk, University of Le Mans, France" << endl << endl;

#if 0
	<< "This library is free software; you can redistribute it and/or" << endl
	<< "modify it under the terms of the GNU General Public" << endl
	<< "License as published by the Free Software Foundation; either" << endl
	<< "version 2.1 of the License, or (at your option) any later version." << endl << endl

	<< "This library is distributed in the hope that it will be useful," << endl
	<< "but WITHOUT ANY WARRANTY; without even the implied warranty of" << endl
	<< "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU" << endl
	<< "Lesser General Public License for more details." << endl << endl

	<< "You should have received a copy of the GNU General Public" << endl
	<< "License along with this library; if not, write to the Free Software" << endl
	<< "Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA" << endl << endl
	<< "***********************************************************************" << endl << endl
	<< "Built on " << __DATE__ << endl << endl;
#endif

  cout << "Usage:" << endl;
  cout << "--mach          -m  file name of the machine" << endl;
  cout << "--word-list     -w  word list of the vocabulary and counts (used to select the most frequent words)" << endl;
  cout << "--lm            -l  file name of the LM (only necessary when using short lists)" << endl;
  cout << "--test-data     -t  test data" << endl;
  cout << "--output-probas -p  write sequence of log-probas to file (optional)" << endl;
  cout << "--order         -O  order of the LM to apply on the test data (must match CSLM, but not necessarily back-off LM)" << endl;
  cout << "--mode          -M  mode of the data (1=IGN_BOS 2=IGN_UNK 4=IGN_UNK_ALL, 8=IGN_EOS, default 3)" << endl;
  cout << "--renormal      -R  renormalize all probabilities, slow for large short-lists (default no)" << endl;
  cout << "--block-size    -B  block size for faster training (default 128)" << endl;
#ifdef BLAS_CUDA
  cout << "--cuda-device   -D  select CUDA device (default 0)" << endl;
#endif

  if (do_exit) exit(1);
}


int main (int argc, char *argv[])
{
    // parse parameters
  char *mach_fname=NULL, *test_fname=NULL, *lm_fname=NULL, *wl_fname=NULL, *prob_fname=NULL;
  int bsize=128, order=4, mode=3;
  bool do_renorm=false;

  char c;

  while ((c=getopt_long (argc, argv, "m:w:l:t:O:M:B:p:RD:",
	   long_options, &option_index)) != -1) {
    switch (c) {
    case 'm':
      mach_fname = strdup(optarg);
      break;
    case 'w':
      wl_fname = strdup(optarg);
      break;
    case 'l':
      lm_fname = strdup(optarg);
      break;
    case 't':
      test_fname = strdup(optarg);
      break;
    case 'p':
      prob_fname = strdup(optarg);
      break;
    case 'O':
      order = strtol(optarg, NULL, 10);
      break;
    case 'M':
      mode = strtol(optarg, NULL, 10);
      break;
    case 'B':
      bsize = strtol(optarg, NULL, 10);
      break;
    case 'R':
      do_renorm=true;
      break;
#ifdef BLAS_CUDA
    case 'D':
      cuda_dev = strtol(optarg, NULL, 10);
      break;
#endif
    default:
      usage();
    }
  }

    // verify mandatory arguments
  if (!mach_fname) {
    usage(false);
    Error("you need to specify a machine file");
  }
  if (!test_fname) {
    usage(false);
    Error("you need to specify test data");
  }
  if (!wl_fname) {
    usage(false);
    Error("you need to specify a word list");
  }
  if (order<2) Error("order must be greater than 1");
  if (mode<0 || mode>15) Error("mode must be in 1..15");


  cout << "Evaluating CSLM: " << mach_fname << endl;

    // read network
  ifstream ifs;
  ifs.open(mach_fname,ios::binary);
  CHECK_FILE(ifs,mach_fname);
  Mach *m = Mach::Read(ifs);
  ifs.close();
  m->Info();
#if 0
  m->SetBsize(1);
  REAL idata[]={1,2,3,4};
  m->SetDataIn(idata);
  m->Forw();
  return 0;
#endif

    // creating dummy DataFile
  cout << "Using data:\n";
  DataNgramBin df(test_fname, 1.0, order, mode);
  Data data(df);
    
    // create a trainer for testing only
  ErrFctSoftmCrossEntNgram errfct(*m);
  if (!lm_fname) {
    TrainerNgram trainer(m,&errfct, data);
    cout << "Evaluating:" << endl;
    trainer.TestDev(prob_fname);
    exit(1); // brute force exit since we have trouble with memory deallocation
  }
  else {
    TrainerNgramSlist trainer(m, &errfct, data, wl_fname, lm_fname);
    if (do_renorm) {
      cout << "Evaluating (renormalized with back-off LM proba-mass):" << endl;
      trainer.TestDevRenorm(prob_fname);
    }
    else {
      cout << "Evaluating:" << endl;
      trainer.TestDev(prob_fname);
    }
#ifdef PROFILE
    cout << "Profiling information:" << endl;
    m->Info();
#endif
    exit(1); // brute force exit since we have trouble with memory deallocation
  }

  
  delete m;
  return 0;
}
