/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: BackoffLm.h,v 1.6 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _BackoffLm_h
#define _BackoffLm_h

#include "Tools.h"
#include "DataNgramBin.h" // for type WordID

// We must be very careful with the indices
//  - most LM toolkits have their own internal word list
//  - binary ngram data files us indices with respect to their word list
//    (ideally, this word list should be identical to the one of the LM !)
//  - the CSLM code with short list performs a mapping  of the binary indices
//    of the datafiles according to the 1-gram frequency
//
//

#define NULL_LN_PROB (1.0)   // this value must not be possible as a normal retrun value of ln Prob

class BackoffLm {
 private:
 public:
  BackoffLm() {};
  virtual ~BackoffLm() {};
  virtual int GetOrder() {return 0; };	// return order of the loaded LM
  virtual REAL BoffPw(char **ctxt, char *w, int req_order) {return 0;}		// get backoff LM P(w|ctxt) from seqeuence of words
  virtual REAL BoffLnPw(char **ctxt, char *w, int req_order) {return -99;}	// idem but ln of P(w|ctxt)
  virtual REAL BoffPid(REAL *ctxt, WordID predw, int req_order) {return 0;} 	// similar for sequences of CSLM indices
  virtual REAL BoffLnPid(REAL *ctxt, WordID predw, int req_order) {return -99;} 
  virtual REAL BoffLnStd(WordID *ctxt, WordID predw, int req_order) {return -99; } // simple wrapper w/o mapping
										   // req-order can be any value
  virtual void *GetVocab() {return NULL; }
};

#endif
