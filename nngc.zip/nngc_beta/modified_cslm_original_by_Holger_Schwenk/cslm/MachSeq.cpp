/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachSeq.cpp,v 1.23 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"
#include "MachSeq.h"

MachSeq::MachSeq()
 : MachMulti()
{
}

MachSeq::~MachSeq()
{
  data_out=grad_in=NULL;  // prevent delete[] by ~Mach()
}

// set pointer of input data
void MachSeq::SetDataIn(REAL *data)
{
  data_in=data;
  if (machs.size() > 0) machs[0]->SetDataIn(data);
}
 
// set pointer of output gradient
void MachSeq::SetGradOut(REAL *data)
{
  grad_out=data;
  if (machs.size() > 0) machs.back()->SetGradOut(data);
}

void MachSeq::MachAdd(Mach *new_mach)
{
  if (machs.empty()) {
    machs.push_back(new_mach);
	// think about freeing memory
    idim=new_mach->GetIdim();
    bsize=new_mach->GetBsize();
    data_in=new_mach->GetDataIn();
    grad_in=new_mach->GetGradIn();
  }
  else {
    Mach *last_mach=machs.back();
    if (last_mach->GetOdim()!=new_mach->GetIdim()) {
      cout << "Current sequential machine:" << endl; Info(false);
      cout << "Newly added machine:" << endl; new_mach->Info(false);
      Error("input dimension of new sequential machine does not match");
    }
    if (bsize!=new_mach->GetBsize()) {
      cout << "Current sequential machine:" << endl; Info(false);
      cout << "Newly added machine:" << endl; new_mach->Info(false);
      Error("bunch size of new sequential machine does not match");
    }
    machs.push_back(new_mach);
 
      // connect new last machine to the previous one
    new_mach->SetDataIn(last_mach->GetDataOut());
    last_mach->SetGradOut(new_mach->GetGradIn());
  }

    // connect last machine to the outside world
  odim=new_mach->GetOdim();
  data_out=new_mach->GetDataOut();
  grad_out=new_mach->GetGradOut();
}

Mach *MachSeq::MachDel()
{
  if (machs.empty()) {
    Error("impossible to delete element from sequential machine: is already empty");
  }
  
  Mach *del_mach=machs.back();
  machs.pop_back();

  if (machs.empty()) {
    idim=odim=bsize=0;
    data_in=data_out=grad_in=grad_out=NULL;
  }
  else {
    Mach *last_mach=machs.back();

      // connect new last machine to the outside world
    odim=last_mach->GetOdim();
    data_out=last_mach->GetDataOut();
    grad_out=last_mach->GetGradOut();
  }

  return del_mach;
}

//-----------------------------------------------
// File input
//-----------------------------------------------

void MachSeq::ReadData(ifstream &inpf, size_t s)
{
  MachMulti::ReadData(inpf,s);

  
  int nbm=machs.size();
  idim = machs[0]->GetIdim();
  bsize = machs[0]->GetBsize();
  odim = machs[nbm-1]->GetOdim();

    // connect first to the outside world
  data_in=machs[0]->GetDataIn();
  grad_in=machs[0]->GetGradIn();
 
    // forward chain the data
  for (int m=1; m<nbm; m++) machs[m]->SetDataIn(machs[m-1]->GetDataOut());
    // backward chain the gradients
  for (int m=nbm-1; m>0; m--) machs[m-1]->SetGradOut(machs[m]->GetGradIn());

    // connect last machine to the outside world
  data_out=machs[nbm-1]->GetDataOut();
  grad_out=machs[nbm-1]->GetGradOut();
}

//
// Tools
//

void MachSeq::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << "Information on sequential machine" << endl;
    MachMulti::Info(detailed,txt);
  }
  else {
    printf("%sSequential machine [%u] %d- .. -%d, bs=%d, passes=%d/%d", txt, (uint) machs.size(), idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");
    char ntxt[512];
    sprintf(ntxt,"%s  ", txt);
    for (unsigned int i=0; i<machs.size(); i++) machs[i]->Info(detailed, ntxt);
  }
  printf("%stotal number of parameters: %d (%d MBytes)\n", txt, GetNbParams(), (int) (GetNbParams()*sizeof(REAL)/1048576));
}

void MachSeq::Forw(int eff_bsize)
{
  if (machs.empty())
    Error("called Forw() for an empty sequential machine");

#ifdef PROFILE
  tm.start();
#endif

  for (unsigned int i=0; i<machs.size(); i++) machs[i]->Forw(eff_bsize);
  nb_forw += (eff_bsize<=0) ? bsize : eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}

void MachSeq::Backw(const float lrate, const float wdecay, int eff_bsize)
{
  if (machs.empty())
    Error("called Backw() for an empty sequential machine");

#ifdef PROFILE
  tm.start();
#endif

  for (int i=machs.size()-1; i>=0; i--) {
	 machs[i]->Backw(lrate,wdecay,eff_bsize);
  }
  nb_backw += (eff_bsize<=0) ? bsize : eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}

