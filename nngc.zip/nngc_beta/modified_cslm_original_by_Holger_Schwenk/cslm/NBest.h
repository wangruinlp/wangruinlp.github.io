/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: NBest.h,v 1.7 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _NBEST_H_
#define _NBEST_H_

using namespace std;

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

#include "Toolsgz.h"
#include "Hypo.h"
#include "NbestLM.h"

class NBest {
  int 		   id;
  string           src;
  vector<Hypo> nbest;
  bool ParseLine(inputfilestream &inpf, const int n);
 public:
  NBest(inputfilestream&, const int=0);
  ~NBest();
  int NbNBest() {return nbest.size(); };
  void CalcGlobal(Weights&);
  void Sort(); // largest values first
  void Write(outputfilestream&, int=0);
  void AddID(const int offs);
  void RescoreLM(NbestLM&, const int);
};


#endif
