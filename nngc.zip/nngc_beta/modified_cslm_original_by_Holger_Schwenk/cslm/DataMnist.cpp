/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2010, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataMnist.cpp,v $
 */

using namespace std;
#include <iostream>

// system headers
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "Tools.h"
#include "Data.h"
#include "DataMnist.h"

const char* DATA_FILE_MNIST="DataMnist";
const uint magic_mnist_data=0x00000803;
const uint magic_mnist_labels=0x00000801;

/*
 * 
 */

uint DataMnist::read_iswap(int fd) {
  uint i, s;
  unsigned char *pi=(unsigned char*) &i, *ps=(unsigned char*) &s;

  read(fd, &i, sizeof(i));
  
  // swap integer Big Endian -> little Endian
  ps[0]=pi[3]; ps[1]=pi[2]; ps[2]=pi[1]; ps[3]=pi[0];
   
  return s;
}

/*
 * 
 */

DataMnist::DataMnist(ifstream &ifs) : DataFile::DataFile(ifs)
{

  printf(" - %s: MNIST data ", fname); fflush(stdout);

   // open data file (fname is parsed by DataFile::DataFile()
  dfd=open(fname, O_RDONLY);
  if (dfd<0) perror("");
  if (read_iswap(dfd) != magic_mnist_data) Error("magic number of data file is wrong");
  nbex = read_iswap(dfd);
  idim = read_iswap(dfd) * read_iswap(dfd);
  printf("with %d examples of dimension %d\n", nbex, idim);

   // open corresponding label file
  char p_clfname[DATA_LINE_LEN];
  ifs >> p_clfname >> odim >> tgt0 >> tgt1;
  cl_fname=strdup(p_clfname);
  printf("   %s with labels in %d classes, targets %5.2f %5.2f\n", cl_fname, odim, tgt0, tgt1); fflush(stdout);

  lfd=open(cl_fname, O_RDONLY);
  if (lfd<0) perror(""); 
  int val;
  if (read_iswap(lfd) != magic_mnist_labels) Error("magic number of label file is wrong");
  if ((val=read_iswap(lfd)) != nbex) {
    fprintf(stderr,"found %d examples in label file", val);
    Error();
  };
  
  if (idim>0) {
    input = new REAL[idim];
    ubuf = new unsigned char[idim];
  }
  if (odim>0) target_vect = new REAL[odim];
}


/**************************
 *  
 **************************/

DataMnist::~DataMnist()
{
  close(dfd);
  close(lfd);
  if (idim>0) { delete [] input; delete [] ubuf; }
  if (odim>0) delete [] target_vect;
  if (cl_fname) free(cl_fname);
}


/**************************
 *  
 **************************/

void DataMnist::Rewind()
{
  lseek(dfd, 16, SEEK_SET);
  lseek(lfd, 8, SEEK_SET);
}

/**************************
 *  
 **************************/

bool DataMnist::Next()
{
 
    // read next image 
  int t=idim*sizeof(unsigned char);
  if (read(dfd, ubuf, t) != t) return false;

  for (t=0; t<idim; t++) input[t]= (REAL) ubuf[t];
#ifdef DEBUG
  int x,y;
  printf("\nEX %d\n", idx);
  for (y=0; y<28; y++) {
    for (x=0; x<28; x++) printf("%d", ubuf[y*28+x] > 16 ? 1 : 0);
    printf("\n");
  }
#endif

    // read next class label
  if (odim<=0) return true;
  if (read(lfd, ubuf, 1) != 1) {
    char msg[16384];  // TODO
    sprintf(msg, "no examples left in class file %s", cl_fname);
    Error(msg);
  }
  target_id = (int) ubuf[0];
  if (target_id>=odim) {
    fprintf(stderr,"example %d has a target of %d, but we have onlt %d classes\n", idx+1, target_id, odim);
    Error("");
  }
  for (t=0; t<odim; t++) target_vect[t]=tgt0;
  target_vect[target_id]=tgt1;

  idx++;
  return true;
}

