/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: ErrFct.h,v 1.11 2012/06/02 13:24:16 schwenk Exp $
 *
 * Class definiton of a general error funtion
 */

#ifndef _ErrFct_h
#define _ErrFct_h

#include <iostream>
#include "Tools.h"
#include "Mach.h"
#include "Data.h"


class ErrFct
{
private:
protected:
  int	dim;			// output dimension of machine
  int	bsize;	
  REAL  *output;		// pointer to output data (stored in machine)
  REAL  *target;		// pointer to target data (stored in trainer)
  REAL  *grad;			// calculated gradient (stored in this class)
public:
  ErrFct(Mach&);
#ifdef BLAS_CUDA
  virtual ~ErrFct() { cublasFree(grad); }
#else
  virtual ~ErrFct() { delete [] grad; }
#endif
  void SetOutput(REAL *p_output) {output=p_output; }
  void SetTarget(REAL *p_target) {target=p_target; }
  REAL *GetGrad() {return grad; };
  virtual REAL CalcValue(int=0);		// Calculate value of error function
  virtual REAL CalcValueNth(int);		// Calculate value of error function for a particular example in bunch
  virtual REAL CalcGrad(int=0);			// calculate NEGATIF gradient of error function
#ifdef BLAS_CUDA
  virtual void CalcGradCumul(int eff_bsize) { Error("override ErrFct::CalcGradCumul()\n"); }
  virtual void InitGradCumul() { Error("override ErrFct::SetGradCumul()\n"); }
  virtual REAL GetGradCumul() { Error("override ErrFct::GetGradCumul()\n"); return 0; }
#endif
};

#endif
