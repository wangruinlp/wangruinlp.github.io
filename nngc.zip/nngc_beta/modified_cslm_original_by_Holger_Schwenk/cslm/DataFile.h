/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataFile.h,v 1.7 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _DataFile_h
#define _DataFile_h

#include <iostream>
#include <fstream>
#include <vector>
#include "Tools.h"

class DataFile {
protected:
  int	idim, odim, nbex;
  float resampl_coeff;
    // internal handling of data
  char *fname;
public:
    // current data
  int  idx;
  REAL *input;		// current input data (needs to be allocated in subclass, we don't know the dimension yet)
  REAL *target_vect;	//         output data
  int  target_id;	//         index of output [0..odim)
   // functions
  DataFile(ifstream &ifs);
  DataFile(char *, float =1.0);
  virtual ~DataFile();
   // access function
  int GetIdim() { return idim; }
  int GetOdim() { return odim; }
  int GetNbex() { return nbex; }
  int GetNbresampl() { return (int) (nbex*resampl_coeff); }
  float GetResampl() { return resampl_coeff; }
   // main interface
  virtual int Info();		// display line with info after loading the data
  virtual void Rewind();	// rewind to first element
  virtual bool Next();		// advance to next data
  virtual int Resampl();	// resample another data (this may skip some elements in the file)
};

#endif
