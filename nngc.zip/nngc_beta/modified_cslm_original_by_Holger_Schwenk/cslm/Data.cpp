/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Data.cpp,v 1.20 2012/06/02 17:19:34 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <stdlib.h>

#include "Tools.h"
#include "Data.h"
#include "DataAscii.h"
#include "DataAsciiClass.h"
#include "DataMnist.h"
#include "DataNgramBin.h"

const int   DATA_LINE_LEN=16384;
const char* DATA_HEADER_TXT="DataDescr";
const int   DATA_HEADER_ID=2;
const char* DATA_PRELOAD="Preload";
const int   DATA_PRELOAD_ACT=8;		// preloading is activated, additional flags:
const int   DATA_PRELOAD_TODO=1;	//    mark that preloading was not yet done, we use this to evitate multiple (costly) preloading
					//    this flag is set by by Next() -> new Rewind() triggers resampling
const int   DATA_PRELOAD_ONCE=4;	//    we resample only once, even if rewind is called many times
const char* DATA_RESAMPL_MODE="ResamplMode";
const char* DATA_RESAMPL_SEED="ResamplSeed";
const char* DATA_SHUFFLE_MODE="ShuffleMode";
const char* DATA_NORMALIZE_MODE="Normalize";
const char* DATA_PATH_PREFIX="PathPrefix";

/**************************
 *
 **************************/

Data::Data(char *p_fname)
 : fname(p_fname), path_prefix("."), idim(0), odim(0), nb_totl(0),
   preload(0), resampl_mode(0), resampl_seed(1234567890), shuffle_mode(0),
   norm_mode(0),
   idx(-1), mem_inp(NULL), mem_trg(NULL), input(NULL), target(NULL)
{

  cout << "Opening data description '" << fname << "'" << endl;
  ifstream ifs;
  ifs.open(fname,ios::in);
  CHECK_FILE(ifs,fname);

    // parsing data description
  int i=ReadInt(ifs,DATA_HEADER_TXT);
  if (i>DATA_HEADER_ID) Error("unknown data description header\n");

  while (!ifs.eof()) {
    bool ok=false;
    string buf; char line[DATA_LINE_LEN];
    ifs >> buf;
    if (buf[0]=='#') {ifs.getline(line, DATA_LINE_LEN); continue;} // skip comments
    if (buf=="") break; // HACK
    if (buf==DATA_PRELOAD) { preload=DATA_PRELOAD_ACT | DATA_PRELOAD_TODO; ok=true; }
    if (buf==DATA_RESAMPL_MODE) { ifs >> resampl_mode; ok=true; }
    if (buf==DATA_RESAMPL_SEED) { ifs >> resampl_seed; ok=true; }
    if (buf==DATA_SHUFFLE_MODE) { ifs >> shuffle_mode; ok=true; }
    if (buf==DATA_NORMALIZE_MODE) { ifs >> norm_mode; ok=true; }
    if (buf==DATA_PATH_PREFIX) { ifs >> path_prefix; ok=true; }
    if (buf==DATA_FILE_ASCII) {
      datafile.push_back(new DataAscii(ifs)); ok=true;
    }
    if (buf==DATA_FILE_ASCIICLASS) {
      datafile.push_back(new DataAsciiClass(ifs)); ok=true;
    }
    if (buf==DATA_FILE_MNIST) {
      datafile.push_back(new DataMnist(ifs)); ok=true;
    }
    if (buf==DATA_FILE_NGRAMBIN) {
      datafile.push_back(new DataNgramBin(ifs)); ok=true;
    }
    if (datafile.size()==1) {idim=datafile[0]->GetIdim(); odim=datafile[0]->GetOdim(); }
    if (datafile.size()>=1) {
      if (idim != datafile.back()->GetIdim()) Error("mismatch in input dimension\n");
      if (odim != datafile.back()->GetOdim()) Error("mismatch in output dimension\n");
    }

    if (!ok) {
      ifs.getline(line, DATA_LINE_LEN);
      cerr << buf << "" << line << endl;
      Error("parse error in above line of the datafile\n");
    }
  }
  ifs.close();

  nb_totl=0;
  cout << "Summary of used data:" << endl;
  for (i=0; i<(int) datafile.size(); i++) nb_totl+=datafile[i]->Info();

  cout << " - total number of examples: " << nb_totl << endl;
  if (resampl_mode) {
    cout << " - resampling with seed " << resampl_seed << endl;
    srand48(resampl_seed);
  }
  if (preload > 0) {
    mem_inp = new REAL[nb_totl*idim];
    if (odim>0) mem_trg = new REAL[nb_totl*odim];

      // check whether there is a resmpling coeff != 0
      // i.e. we need to resample at each rewind
    float s=0;
    for (vector<DataFile*>::iterator it = datafile.begin(); it!=datafile.end(); ++it)
      s+=(*it)->GetResampl();
    if (s>=datafile.size()) {
      preload|=DATA_PRELOAD_ONCE;
      cout << " - all resampling coefficients are set to one, loading data once\n";
    }
    
  }
  else {
    if (norm_mode>0)
      Error("Normalization of the data is only implemented with preloading\n");
  }
  Preload();
  Shuffle();
}

/**************************
 *
 **************************/

Data::Data(DataFile &df)
 : fname(NULL), idim(df.GetIdim()), odim(df.GetOdim()), nb_totl(df.GetNbex()),
   preload(0), resampl_mode(0), resampl_seed(1234567890), shuffle_mode(0),
   norm_mode(0),
   idx(-1), mem_inp(NULL), mem_trg(NULL), input(NULL), target(NULL)
{

  datafile.push_back(&df);
}

Data::~Data()
{
  if (preload) {
    delete [] mem_inp;
    if (odim>0) delete [] mem_trg;
  }
  for (vector<DataFile*>::iterator it = datafile.begin(); it!=datafile.end(); ++it)
      delete (*it);
  datafile.clear();
}

/**************************
 *
 **************************/

void Data::Shuffle()
{
  if (shuffle_mode < 1 || !preload) return;

  time_t t_beg, t_end;
  time(&t_beg);

  REAL	*inp = new REAL[idim];
  REAL	*trg = new REAL[odim];

  cout << " - shuffling data " << shuffle_mode << " times ...";
  cout.flush();
  for (int i=0; i<shuffle_mode*nb_totl; i++) {
    int i1 = (int) (nb_totl * drand48());
    int i2 = (int) (nb_totl * drand48());
     
    memcpy(inp, mem_inp + i1*idim, idim*sizeof(REAL));
    memcpy(mem_inp + i1*idim, mem_inp + i2*idim, idim*sizeof(REAL));
    memcpy(mem_inp + i2*idim, inp, idim*sizeof(REAL));

    if (odim>0) {
      memcpy(trg, mem_trg + i1*odim, odim*sizeof(REAL));
      memcpy(mem_trg + i1*odim, mem_trg + i2*odim, odim*sizeof(REAL));
      memcpy(mem_trg + i2*odim, trg, odim*sizeof(REAL));
    }
    
  }

  delete [] inp; delete [] trg;

  time(&t_end);
  time_t dur=t_end-t_beg;

  cout << " done (" << dur / 60 << "m" << dur % 60 << "s)" << endl;
}

//**************************
//
//

void Data::Preload()
{
  if (!preload) return;
  if (! (preload&DATA_PRELOAD_TODO)) {
    cout << " - all data is already loaded into memory" << endl;
    return;
  }
  preload &= ~DATA_PRELOAD_TODO; // clear flag

  cout << " - loading all data into memory ...";
  cout.flush();
  time_t t_beg, t_end;
  time(&t_beg);

  int idx=0;
  for (vector<DataFile*>::iterator it = datafile.begin(); it!=datafile.end(); ++it) {
    (*it)->Rewind();
    int n = -1, maxn = (*it)->GetNbresampl();
//cout << "Resampl " << maxn << " examples from file into " <<  (*it)->input << endl;
    while (++n < maxn) {
      (*it)->Resampl();
//cout << "n: " << n << ", idx: " << (*it)->idx << endl;
      memcpy(mem_inp+idx*idim, (*it)->input, idim*sizeof(REAL));
      if (odim > 0) memcpy(mem_trg+idx*odim, (*it)->target_vect, odim*sizeof(REAL));
      idx++;
    }
  }

  if (norm_mode & 1) {
    cout << " subtract mean" << endl;
    for (int i=0; i<idim; i++) {
      int e;
      REAL m=0, *mptr;
      for (e=0, mptr=mem_inp+i; e<idx; e++, mptr+=idim) m+=*mptr;
      m = m/idx; // mean
      for (e=0, mptr=mem_inp+i; e<idx; e++, mptr+=idim) *mptr -= m;
    }
  }

  if (norm_mode & 2) {
    cout << " divide by variance" << endl;
    for (int i=0; i<idim; i++) {
      int e;
      REAL m=0, m2=0, *mptr;
      for (e=0, mptr=mem_inp+i; e<idx; e++, mptr+=idim) { m+=*mptr; m2+=*mptr * *mptr; }
      m = m/idx;  // mean
      m2 = m2/idx - m; // var = 1/n sum_i x_i^2  -  mu^2
      if (m2>0)
        for (e=0, mptr=mem_inp+i; e<idx; e++, mptr+=idim)
          *mptr = (*mptr - m) / m2;
    }
  }
#ifdef DEBUG
    for (int e=0; e<idx; e++) {
      for (int i=0; i<idim; i++) printf(" %5.2f",mem_inp[e*idim+i]); printf("\n");
    }
#endif

  time(&t_end);
  time_t dur=t_end-t_beg;
  cout << " done (" << dur / 60 << "m" << dur % 60 << "s)" << endl;
}


/**************************
 *
 **************************/

void Data::Rewind()
{
  if (preload) {
       // clear all data, resample and shuffle again
    Preload();
    Shuffle();
  }
  else {
    for (vector<DataFile*>::iterator it = datafile.begin(); it!=datafile.end(); ++it) (*it)->Rewind();
  }
  idx = -1;
}

/**************************
 * Advance to next data
 **************************/

bool Data::Next()
{
  if (idx >= nb_totl-1) return false;
  idx++;

  if (preload) {
      // just advance to next data in memory
    input = &mem_inp[idx*idim];
    if (odim>0) target = &mem_trg[idx*odim];
//printf("DATA:"); for (int i =0; i<idim; i++) printf(" %5.2f", input[i]); printf("\n");
    if (!(preload&DATA_PRELOAD_ONCE)) preload |= DATA_PRELOAD_TODO; // remember that next Rewind() should preload again
    return true;
  }

  if (shuffle_mode > 0) {
      // resample in RANDOMLY SELECTED datafile until data was found
      // we are sure to find something since idx was checked before
    int df = (int) (drand48() * datafile.size());
//cout << " df=" << df << endl;
    datafile[df]->Resampl();
    input = datafile[df]->input;
    if (odim>0) target = datafile[df]->target_vect;
  }
  else {
      // resample SEQUENTIALLY all the data files
    static int df=0, i=-1, nbdf=datafile[df]->GetNbex();
    if (idx==0) {df = 0, i=-1, nbdf=datafile[df]->GetNbex(); }	// (luint) this) is a hack to know when there was a global rewind
    if (++i >= nbdf) { df++; nbdf=datafile[df]->GetNbex(); i=-1; }
    if (df >= (int) datafile.size()) Error("internal error: no examples left\n");
//printf("seq file: df=%d, i=%d\n", df,i);
    datafile[df]->Resampl();	//TODO: idx= ??
//cout << " got df=" << df << " idx="<<idx<<endl;
    input = datafile[df]->input;
    if (odim>0) target = datafile[df]->target_vect;
  }

  return true;
}
