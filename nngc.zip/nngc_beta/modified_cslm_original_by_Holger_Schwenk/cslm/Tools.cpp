/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Tools.cpp,v 1.4 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"

void Error(void)
{
  exit(1);
}

void Error(const char *txt)
{
  cerr << "ERROR: " << txt << endl;
  exit(1);
}

int ReadInt(ifstream &inpf, const string &name, int minval,int maxval)
{
  string buf;
  inpf >> buf;
  if (buf!=name) {
    cerr << "FileRead: found field '" << buf << "' while looking for '" << name << "'";
    Error("");
  }
    
  int val;
  inpf >> val;
  if (val<minval || val>maxval) {
    cerr << "FileRead: values for " << name << "must be in ["<<minval<<","<<maxval<<"]";
    Error("");
  }

  return val;
}

