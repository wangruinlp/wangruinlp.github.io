/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachLin.cpp,v 1.37 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <stdlib.h>
extern double drand48();

#include "Tools.h"
#include "MachLin.h"
#include "Blas.h"

MachLin::MachLin(const int p_idim, const int p_odim, const int p_bsize, const int p_nbfw, const int p_nbbw)
 : Mach(p_idim, p_odim, p_bsize, p_nbfw, p_nbbw)
{
#ifdef BLAS_CUDA
  b = cuda_alloc(odim, "bias of linear machine");
  w = cuda_alloc(idim*odim, "weights of linear machine");
#else
  if (odim>0) {
    b = new REAL[odim];
    if (!b) Error ("can't allocate memory for bias of linear machine");
  }
  else b=NULL;
  if (idim*odim>0) {
    w = new REAL[idim*odim];
    if (!w) Error ("can't allocate memory for weights of linear machine");
  }
  else w=NULL;
#endif
}

MachLin::~MachLin()
{

#ifdef BLAS_CUDA
  if (b) cublasFree(b);
  if (w) cublasFree(w);
#else
#if 0
  printf("W:\n");
  for (int od=0;od<odim;od++) {
    for (int id=0;id<idim;id++) printf(" %9.7f",w[id*odim+od]);
    printf("\n");
  }
  printf("b: ");
  for (int od=0;od<odim;od++) printf(" %9.7f",b[od]);
  printf("\n");
#endif
  if (b) delete [] b;
  if (w) delete [] w;
#endif
}

void MachLin::BiasConst(const REAL val)
{
#ifdef BLAS_CUDA
  Error("MachLin::BiasConst(): not implmented for CUDA\n");
#else
  for (int i=0; i<odim; i++) b[i]=val;
#endif
}

void MachLin::BiasRandom(const REAL range)
{
  REAL c=range*2.0;
#ifdef BLAS_CUDA
  curandGenerateUniform(cuda_gen, (float*) b, odim);		// in (0,1]
  cuda_check_error("generating random values for biases");
  nppsSubC_32f_I(0.5,b,odim);
  nppsMulC_32f_I(c,b,odim);
#else
  for (int i=0; i<odim; i++) b[i]=c*(drand48()-0.5);
#endif
}

void MachLin::WeightsConst(const REAL val)
{
#ifdef BLAS_CUDA
  Error("MachLin::WeightsConst(): not implmented for CUDA\n");
#else
  for (int i=0; i<idim*odim; i++) w[i]=val;
#endif
}

void MachLin::WeightsRandom(const REAL range)
{
  REAL c=range*2.0;
#ifdef BLAS_CUDA
  curandGenerateUniform(cuda_gen, (float*) w, idim*odim);
  cuda_check_error("generating random values for biases");
  nppsSubC_32f_I(0.5,w,idim*odim);
  nppsMulC_32f_I(c,w,idim*odim);
#else
  for (int i=0; i<idim*odim; i++) w[i]=c*(drand48()-0.5);
#endif
}

void MachLin::WeightsRandomFanI(const REAL range)
{
  REAL c=2.0*range/sqrt((REAL) idim);
#ifdef BLAS_CUDA
  curandGenerateUniform(cuda_gen, (float*) w, idim*odim);
  cuda_check_error("generating FanI random values for biases");
  nppsSubC_32f_I(0.5,w,idim*odim);
  nppsMulC_32f_I(c,w,idim*odim);
#else
  printf("weight init FanI=%d, range =%5.3e\n",idim, c/2.0);
  for (int i=0; i<idim*odim; i++) w[i]=c*(drand48()-0.5);
#endif
}

void MachLin::WeightsRandomFanIO(const REAL range)
{
  REAL c=2.0*range/sqrt((REAL) (idim+odim));
#ifdef BLAS_CUDA
  curandGenerateUniform(cuda_gen, (float*) w, idim*odim);
  cuda_check_error("generating FanIO random values for biases");
  nppsSubC_32f_I(0.5,w,idim*odim);
  nppsMulC_32f_I(c,w,idim*odim);
#else
  printf("weight init FanIO=%d-%d, range =%5.3e\n",idim,odim,c/2.0);
  for (int i=0; i<idim*odim; i++) w[i]=c*(drand48()-0.5);
#endif
}

void MachLin::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << "Information on linear machine" << endl;
    Mach::Info(detailed,txt);
  }
  else {
    printf("%sMachLin %d-%d, bs=%d, passes=%d/%d", txt, idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");

#ifdef BLAS_CUDA
#else
#endif
  }
}

//-----------------------------------------------
// File output
//-----------------------------------------------

void MachLin::WriteData(ofstream &outf) {
  int s=odim*idim + odim;
  outf.write((char*) &s,sizeof(int));
  s=sizeof(REAL);
  outf.write((char*) &s,sizeof(int));

#ifdef BLAS_CUDA
  REAL *local_mem=new REAL[odim*idim];
  cublasGetVector(odim*idim,CUDA_SIZE,w,1,local_mem,1);
  cuda_check_error("transfer of weight matrix from GPU memory");
  outf.write((char*)local_mem,odim*idim*sizeof(REAL));
  delete(local_mem);

  local_mem=new REAL[odim];
  cublasGetVector(odim,CUDA_SIZE,b,1,local_mem,1);
  cuda_check_error("transfer of bias vector from GPU memory");
  outf.write((char*)local_mem,odim*sizeof(REAL));
  delete(local_mem);
#else
  outf.write((char*) w,odim*idim*sizeof(REAL));
  outf.write((char*) b,odim*sizeof(REAL));
#endif
}

//-----------------------------------------------
// File input
//-----------------------------------------------


void MachLin::ReadData(ifstream &inpf, size_t s)
{
  size_t se=odim*idim + odim;
  if (s!=se) {
    cerr << "ERROR: data block of linear machine has " << s << " elements (" << se << " were expected)" << endl;    Error();
  } 
  Mach::ReadData(inpf, 0);

    // read parameters
    // TODO: error checks
#ifdef BLAS_CUDA
  REAL *local_mem=new REAL[odim*idim];
  inpf.read((char*)local_mem,odim*idim*sizeof(REAL));
  cublasSetVector(odim*idim,CUDA_SIZE,local_mem,1,w,1);
  cuda_check_error("transfer of weight matrix to GPU memory");
  delete(local_mem);

  local_mem=new REAL[odim];
  inpf.read((char*)local_mem,odim*sizeof(REAL));
  cublasSetVector(odim,CUDA_SIZE,local_mem,1,b,1);
  cuda_check_error("transfer of bias vector to GPU memory");
  delete(local_mem);
#else
  inpf.read((char*) w,odim*idim*sizeof(REAL));
  inpf.read((char*) b,odim*sizeof(REAL));
#if 0
cout << "\nRead from file:" << endl;
  printf("W: %dx%d\n",odim,idim);
  for (int od=0;od<odim;od++) {
    for (int id=0;id<idim;id++) printf(" %9.7f",w[id*odim+od]);
    printf("\n");
  }
  printf("b:\n");
  for (int od=0;od<odim;od++) printf(" %9.7f",b[od]);
  printf("\n");
#endif
#endif
}


//-----------------------------------------------
// Training
//-----------------------------------------------

void MachLin::Forw(int eff_bsize)
{

#ifdef PROFILE
  tm.start();
#endif

  if (!data_in)
    Error("MachLin::Forw(): input data is not set");
  if (eff_bsize<=0) eff_bsize=bsize;

#ifdef BLAS_CUDA
    // copy bias <eff_bsize> times into result matrix 
  for (int e=0; e<eff_bsize; e++)
    nppsCopy_32f(b,data_out+e*odim,odim);
  call_gemm(data_out, w, data_in, 1.0, odim, eff_bsize, idim);
#else
  for (int e=0; e<eff_bsize; e++)
    memcpy(data_out+e*odim,b,odim*sizeof(float));
  call_gemm(data_out, w, data_in, 1.0, odim, eff_bsize, idim);
#endif
  nb_forw += eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}


void MachLin::Backw(const float lrate, const float wdecay, int eff_bsize)
{
  static REAL real1=1.0, real0=0.0;
  static char transN='N', transT='T';
  REAL epsilon = 1.0 + lrate * wdecay;

  if (eff_bsize<=0) eff_bsize=bsize;
  if (!grad_out)
    Error("MachLin::Backw(): output gradient is not set");

#ifdef PROFILE
  tm.start();
#endif

#if defined(BLAS_ATLAS) || defined(BLAS_INTEL_MKL)
    // update bias vector:   b = b + lrate * grad_out
    // NO weight decay
  REAL *gptr = grad_out;
  for (int e=0; e<eff_bsize; e++, gptr+=odim) {
    AXPY(&odim,&lrate,gptr,&inc1,b,&inc1);
  }

    // backprop gradient:   grad_in   =        w'        *   grad_out
    //                    idim x bsize = (odim x idim)'  *  odim x bsize
  GEMM (&transT, &transN, &idim, &eff_bsize, &odim,
        &real1, w, &odim, grad_out, &odim,
        &real0, grad_in, &idim);

    // update weights including weight decay
    // w = lrate  *grad_out * data_in^T + epsilon * w
    // gemm (transa, transb, m, n, k, alpha, a, lda, b, ldb, beta, c, ldc )
    //                                      Go      Din            W
    //        C = alpha*A * B + beta * b
    //

  GEMM (&transN, &transT, &odim, &idim, &eff_bsize,
        &lrate, grad_out, &odim, data_in, &idim,
        &epsilon, w, &odim);
#else
# ifdef BLAS_CUDA
  CUDA *gptr = grad_out;
  for (int e=0; e<eff_bsize; e++, gptr+=odim) {
    AXPY(odim,lrate,gptr,1,b,1);
  }
    // backprop gradient:   grad_in   =        w'        *   grad_out
    //                    idim x bsize = (odim x idim)'  *  odim x bsize
  GEMM (transT, transN, idim, eff_bsize, odim,
        real1, w, odim, grad_out, odim,
        real0, grad_in, idim);
    // update weights including weight decay
    // w = lrate  *grad_out * data_in^T + epsilon * w
  GEMM (transN, transT, odim, idim, eff_bsize,
        lrate, grad_out, odim, data_in, idim,
        epsilon, w, odim);
# else
  Error("you must compile with BLAS_ATLAS, BLAS_INTEL_MKL or BLAS_CUDA");
# endif
#endif
  nb_backw += eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}

void MachLin::Debug()
{
#ifdef BLAS_CUDA
  Error("MachLin::Debug(): not implmented for CUDA\n");
#else
  for (int o=0; o<odim; o++) {
    for (int i=0; i<idim; i++) {
      w[i*odim+o] = i + 1000*o;
    }
    b[o] = -o;
  }
#endif
}
