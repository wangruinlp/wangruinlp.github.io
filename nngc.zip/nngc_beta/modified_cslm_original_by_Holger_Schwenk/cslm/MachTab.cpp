/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachTab.cpp,v 1.32 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <stdlib.h>
extern double drand48();

#include "Tools.h"
#include "MachTab.h"
#include "Blas.h"

#ifdef BLAS_CUDA
# include "Gpu.cuh"
#endif

void MachTab::do_alloc()
{
  if (!ext_alloc) {
#ifdef BLAS_CUDA
    t = cuda_alloc(idim*odim, "memory for table look-up machine");
#else
    t = new REAL[idim*odim];
    if (!t) Error ("can't allocate memory for table look-up machine");
#endif
  }
  else
    ;
#ifdef BLAS_CUDA
    tmp_inp = new REAL[idim*bsize];
#endif
}


MachTab::MachTab(const int p_idim, const int p_odim, const int p_bsize, const int p_nbfw, const int p_nbbw)
 : Mach(1, p_odim, p_bsize, p_nbfw, p_nbbw), ext_alloc(false)
{
  if (p_idim<=0) Error("Table machine: illegal value of input dimension");
  if (p_odim<=0) Error("Table machine: illegal value of output dimension");
  idim = p_idim; // override 1 in call to Mach()

  do_alloc();
}

MachTab::MachTab(REAL *ext_table,
	const int p_idim, const int p_odim, const int p_bsize,
	const int p_nbfw, const int p_nbbw)
 : Mach(1, p_odim, p_bsize, p_nbfw, p_nbbw), ext_alloc(true)
{
  if (p_idim<0) Error("Table machine: illegal value of input dimension");
  if (p_odim<0) Error("Table machine: illegal value of output dimension");
  idim = p_idim; // override 1 in call to Mach()

  //if (!ext_table) Error ("Table look-up machine: provided address is NULL");
  t=ext_table;
  do_alloc();
}

MachTab::~MachTab()
{

#ifdef BLAS_CUDA
  if (!ext_alloc & (t!=NULL)) cublasFree(t);
  if (tmp_inp) delete tmp_inp;
#else
  if (!ext_alloc & (t!=NULL)) delete [] t;
#endif
}

void MachTab::TableConst(const REAL val)
{
#ifdef BLAS_CUDA
  nppsSet_32f(val,t,idim*odim);
#else
  for (int i=0; i<idim*odim; i++) t[i]=val;
#endif
}

void MachTab::TableRandom(const REAL range)
{
  REAL c=range*2.0;
#ifdef BLAS_CUDA
  curandGenerateUniform(cuda_gen, (float*) t, idim*odim);
  cuda_check_error("generating random values for table look-up machine");
  nppsSubC_32f_I(0.5,t,idim*odim);
  nppsMulC_32f_I(c,t,idim*odim);
#else
  for (int i=0; i<idim*odim; i++) t[i]=c*(drand48()-0.5);
#endif
}

void MachTab::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << "Information on table look-up machine" << endl;
    Mach::Info(detailed,txt);
  }
  else {
    printf("%sMachTab %c[%d]-%d, bs=%d, passes=%d/%d", txt, ext_alloc ? 's' : '1', idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");
  }
}

//-----------------------------------------------
// File output
//-----------------------------------------------

void MachTab::WriteParams(ofstream &of)
{

  Mach::WriteParams(of);
  of.write((char*) &ext_alloc, sizeof(int));
}


void MachTab::WriteData(ofstream &outf) {
  int i=0, s=sizeof(REAL);
  if (ext_alloc) {
    outf.write((char*) &i, sizeof(int));
    outf.write((char*) &s, sizeof(int));
  }
  else {
    i=idim*odim;
    outf.write((char*) &i, sizeof(int));
    outf.write((char*) &s, sizeof(int));
#ifdef BLAS_CUDA
    REAL *local_mem=new REAL[i];
    cublasGetVector(i,CUDA_SIZE,t,1,local_mem,1);
    cuda_check_error("transfer of table look-up machine from GPU memory");
    outf.write((char*)local_mem,i*sizeof(REAL));
    delete(local_mem);
#else
    outf.write((char*) t,odim*idim*sizeof(REAL));
#endif

  }
}

//-----------------------------------------------
// File input
//-----------------------------------------------

void MachTab::ReadParams(ifstream &inpf, bool with_alloc)
{

  Mach::ReadParams(inpf, false);
  inpf.read((char*) &ext_alloc, sizeof(int));
  do_alloc();
}

void MachTab::ReadData(ifstream &inpf, size_t s)
{
  size_t se=odim*idim;

  if (ext_alloc) {
    if (s>0) {
      fprintf(stderr,"internal error in file, table look-up machine has external allocation, but %u elements of data are provided\n",(uint)s);
      Error();
    }
    return;	// address will be filled in by MachPar
  }
  else if (s!=se) {
    fprintf(stderr,"data block of table look-up machine has %u elements - %u were expected)",(uint) s, (uint) se);
    Error();
  } 
  Mach::ReadData(inpf, 0);
#ifdef BLAS_CUDA
  REAL *local_mem=new REAL[odim*idim];
  inpf.read((char*)local_mem,odim*idim*sizeof(REAL));
  cublasSetVector(odim*idim,CUDA_SIZE,local_mem,1,t,1);
  cuda_check_error("transfer of table look-up machine to GPU memory");
  delete(local_mem);
#else
  inpf.read((char*) t,odim*idim*sizeof(REAL));
#endif
}


//-----------------------------------------------
// Training
//-----------------------------------------------

void MachTab::Forw(int eff_bsize)
{
  if (!data_in)
    Error("MachTab::Forw(): input data is not set");

#ifdef PROFILE
  tm.start();
#endif

  if (eff_bsize<=0) eff_bsize=bsize;

#ifdef BLAS_CUDA
  GpuMachTabForw(eff_bsize, odim, data_in, t, data_out);
#else
  REAL *optr=data_out;
  for (int b=0; b<eff_bsize; b++) {
    int idx= (int) data_in[b];
    if (idx==NULL_WORD) {
        // simulate empty word: set everything to 0
      for (int i=0; i<odim; i++) *optr++=0.0;
    }
    else {
      memcpy(optr,t+idx*odim,odim*sizeof(REAL));
      optr+=odim;
    }
  }
#endif

  nb_forw+=eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}


void MachTab::Backw(const float lrate, const float wdecay, int eff_bsize)
{
  // table[wid] = table[wid] + lrate * grad_out[wid] * data_in[wid]

#ifdef PROFILE
  tm.start();
#endif

#ifdef BLAS_CUDA
  GpuMachTabBackw(lrate,eff_bsize, odim, data_in, t, grad_out);
    // we don't backprop to the input of a table look-up machine
  nppsSet_32f(0.0,grad_in,eff_bsize);
#else
  REAL *gptr = grad_out;
  for (int b=0; b<eff_bsize; b++,gptr+=odim) {
    int idx= (int) data_in[b];
    if (idx==NULL_WORD) { // empty word: no weight update
    }
    else {
      REAL *tptr=t+idx*odim;
      AXPY(&odim,&lrate,gptr,&inc1,tptr,&inc1);
    }
  }
 
    // we don't backprop to the input of a table look-up machine
  for (int b=0; b<eff_bsize; b++) grad_in[b]=0.0;
#endif


#ifdef PROFILE
  tm.stop();
#endif
}

