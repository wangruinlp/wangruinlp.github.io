/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachTanh.h,v 1.11 2012/06/02 13:24:16 schwenk Exp $
 *
 * sigmoidal machine:  output = tanh(weights * input + biases)
 */

#ifndef _MachTanh_h
#define _MachTanh_h

#include "MachLin.h"

class MachTanh : public MachLin
{
private:
#ifdef PROFILE
  Timer tms;			// cumulated time used for softmax normalization
#endif 
#ifdef BLAS_CUDA
  REAL *tmp_tanh;		// temporay storage need to calculate tanh=(exp 2x - 1) / (exp 2x + 1)
#endif
public:
  MachTanh(const int=0, const int=0, const int=1, const int=0, const int=0);	
  virtual ~MachTanh();
  virtual int GetMType() {return file_header_mtype_tanh;};	// get type of machine
  virtual void Info(bool=false, char *txt=(char*)"");	// display (detailed) information on machine
  virtual void Forw(int=0);	// calculate outputs for current inputs
    // backprop gradients from output to input and update all weights
  virtual void Backw (const float lrate, const float wdecay, int=0);
};

#endif
