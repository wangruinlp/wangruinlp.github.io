/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachMulti.h,v 1.13 2012/06/02 13:24:16 schwenk Exp $
 *
 * virtual class to support various combinations of multiple machines
 *
 * IMPORTANT:
 *   MultMach will call the destructor of the individual machines !
 *   Therefore the individual machines should be created by "new Mach()" and not
 *   as the adress of a machine allocated as (local) variable which would be freed
 */

#ifndef _MachMulti_h
#define _MachMulti_h

using namespace std;
#include <vector>

#include "Mach.h"

class MachMulti : public Mach
{
protected:
  vector<Mach*> machs;
  virtual void ReadParams(ifstream&, bool =true);
  virtual void ReadData(ifstream&, size_t); // read binary data
  virtual void WriteParams(ofstream&); // write all params
  virtual void WriteData(ofstream&); // write binary data
public:
  MachMulti();	// create initial sequence with no machine
  virtual ~MachMulti();
  virtual int GetMType() {return file_header_mtype_multi;};	// get type of machine
  virtual int GetNbParams();					// return the nbr of allocated parameters 
  void SetBsize(int bs);
    // add and remove machines
  virtual void Delete();	// call destructor for all the machines
  virtual void MachAdd(Mach*);	// add new machine after the existing ones
  virtual Mach *MachDel();	// delete the last machine
    // standard functions
  virtual void Info(bool=false, char *txt=(char*)"");	// display (detailed) information on machine
  virtual void Forw(int=0);  // calculate outputs for current inputs
  virtual void Backw(const float lrate, const float wdecay, int=0); // calculate gradients at input for current gradients at output
};

#endif
