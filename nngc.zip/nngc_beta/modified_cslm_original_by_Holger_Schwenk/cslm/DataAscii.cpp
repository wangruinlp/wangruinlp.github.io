/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataAscii.cpp,v 1.11 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"
#include "Data.h"
#include "DataAscii.h"

const char* DATA_FILE_ASCII="DataAscii";

DataAscii::DataAscii(ifstream &ifs) : DataFile::DataFile(ifs)
{

  dfs.open(fname,ios::in);
  CHECK_FILE(dfs,fname);
  char buf[DATA_LINE_LEN];
  dfs.getline(buf,DATA_LINE_LEN);
  sscanf(buf, "%d %d %d", &nbex, &idim, &odim);
  printf(" - %s: ASCII data with %d examples of dimension %d -> %d\n", fname, nbex, idim, odim);


  if (idim>0) input = new REAL[idim];
  if (odim>0) target_vect = new REAL[odim];
}


/**************************
 *  
 **************************/

DataAscii::~DataAscii()
{
  dfs.close();
  if (idim>0) delete [] input;
  if (odim>0) delete [] target_vect;
}


/**************************
 *  
 **************************/

void DataAscii::Rewind()
{
  // dfs.seekg(0,ios::beg); HACK: does not work
  dfs.close();
  dfs.open(fname,ios::in);
  CHECK_FILE(dfs,fname);
  char buf[DATA_LINE_LEN];
  dfs.getline(buf,DATA_LINE_LEN);
}

/**************************
 *  
 **************************/

bool DataAscii::Next()
{
  char line[DATA_LINE_LEN];
  dfs.getline(line, DATA_LINE_LEN);
  if (dfs.eof()) return false;
          else idx++;

    // parse input data
  char *lptr=line;
//cout << "\nLINE: " << line << endl;
  for (int i=0; i<idim; i++) {
//cout << "parse:" <<lptr<<"; ";
    while (*lptr==' ' || *lptr=='\t') lptr++;
    if (!*lptr) {
      sprintf(line, "incomplete input in ASCII datafile, field %d", i);
      Error(line);
    }
    if (sscanf(lptr, "%f", input+i)!=1) Error("parsing source in ASCII datafile");
//cout << "got i[" <<i << "] " << input[i] << endl;
    while (*lptr!=' ' && *lptr!='\t' && *lptr!=0) lptr++;
  }

  if (odim<=0) return true;

    // parse target data
  for (int i=0; i<odim; i++) {
//cout << "parse:" <<lptr<<"; ";
    while (*lptr==' ' || *lptr=='\t') lptr++;
    if (!*lptr) {
      sprintf(line, "incomplete target in ASCII datafile, field %d", i);
      Error(line);
    }
    if (sscanf(lptr, "%f", target_vect+i)!=1) Error("parsing target in ASCII datafile");
//cout << "got t[" <<i << "] " << target_vect[i] << endl;
    while (*lptr!=' ' && *lptr!='\t' && *lptr!=0) lptr++;
  }

  return true;
}

