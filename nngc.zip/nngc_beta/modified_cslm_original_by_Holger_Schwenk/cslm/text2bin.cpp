/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: text2bin.cpp,v 1.15 2012/06/02 17:35:01 schwenk Exp $
 *
 * text2bin.cpp: tool to convert UTF8 texts to binary representation for the
 * CSLM toolkit (index in word list according to SRILM representation of the
 * vocabulary)
 *
 * The previous program convertToInt sorts the word list using native byte
 * values for the order. This can be reproduced by UNIX sort by setting
 * LC_ALL=C
 */

using namespace std;
#include <vector>

#include "File.h"	// tool from SRILM for file IO
#include "Vocab.h"	// SRILM vocabulary representation

#define LINE_LEN 1048576
#define WordID	int

#undef COUNT_OOV		// this needs to be debugged first

int main (int argc, char *argv[]) {
  Vocab *voc = new Vocab;
  Vocab *oov_w = new Vocab;
  int i, nvoc;
  vector<int> oov_cnt;
  WordID idx;
  char	line[LINE_LEN];
  bool do_lc=false;  // convert all input text to lowercase (we don not modify the vocabulary !)

  cout << "Text to binary converter V2.1, H. Schwenk, Copyright 2012, LIUM, University of Le Mans, France" << endl;
    // parse args
  if (argc<5 || argc>6) {
    cerr << " usage: " << argv[0] << " input-vocab output-binary-file output-word-freq output-list-of-oov [--lc]< file" << endl;
    cerr << "        --lc     convert all input text to lowercase (the vocabulary is not modified !)" << endl;
    return 1;
  }
  char *voc_fname=argv[1];
  char *bin_fname=argv[2];
  char *wfreq_fname=argv[3];
  char *oov_fname=argv[4];
  if (argc==6) {
    if (strcmp(argv[5], "--lc")==0) {
      do_lc=true;
      cout << " - all input text is converted to lower case" << endl;
    }
    else {
     fprintf(stderr,"unknown argument %s\n", argv[5]);
     return 1;
    }
  }

  voc->unkIsWord() = true;
  voc->toLower() = false;

    // read vocabulary
  {
    File file(voc_fname, "r");
    voc->read(file);
    //voc->remove("-pau-");
  }
  nvoc=voc->numWords();	// SRILM may add <unk>, <s> or </s> to the provided word list !!
  WordID idx_unk=voc->getIndex(Vocab_Unknown);
  WordID idx_bos=voc->getIndex(Vocab_SentStart);
  WordID idx_eos=voc->getIndex(Vocab_SentEnd);
  printf(" - using word list %s (%d words, unk=%d, bos=%d, eos=%d)\n", voc_fname, nvoc, idx_unk, idx_bos, idx_eos);

  int *wordfreq = new int[nvoc+1];	// SRILM returns values 1..nvoc !!
  for (i=0; i<=nvoc; i++) wordfreq[i]=0;
#ifdef COUNT_OOV
  oov_cnt.resize(nvoc);
  for (i=0; i<nvoc; i++) { oov_cnt[i]=wordfreq[i]=0; }
#endif

    // write empty header (actual counts will be written at the end)
  cout << " - writing binary representation to file " << bin_fname << endl;
  File binf(bin_fname, "wb");
  i=0;
  fwrite(&i, sizeof(int), 1, binf);
  fwrite(&i, sizeof(int), 1, binf);
  fwrite(&i, sizeof(int), 1, binf);
  i=sizeof(WordID);
  fwrite(&i, sizeof(int), 1, binf);
  fwrite(&idx_bos, sizeof(WordID), 1, binf);
  fwrite(&idx_eos, sizeof(WordID), 1, binf);
  fwrite(&idx_unk, sizeof(WordID), 1, binf);
  

    // read file, convert to binary, count word frequencies and #unk
  int nl=0, nw=0, nunk=0;
  while (cin.getline(line, LINE_LEN)) {
    line[strlen(line)]=0;
    line[strlen(line)+1]=0;
    nl++;
    fwrite(&idx_bos, sizeof(idx_bos), 1, binf);
    
    char *bptr, *eptr;

    if (do_lc) {  // convert line to lower case
      for (bptr=line; *bptr; bptr++) *bptr=tolower(*bptr);
    }

    bptr=line;
    while ((*bptr != 0) && (*bptr != '\n') && (*bptr == ' ')) bptr++; /* skip blank */
    if (*bptr == '\n') continue;    /* skip empty lines */

      // loop on all words in line
    //cerr << "Line: " << line << endl;
    while ((*bptr != 0) && (*bptr != '\n')) {
      //cin >> w;

      eptr = bptr + 1;
      while ((*eptr != 0) && (*eptr != '\n') && (*eptr != ' ')) eptr++;
      *eptr = 0;

      idx = voc->getIndex(bptr);
      //cerr << bptr << "[" << idx <<"]"<< endl;
      nw++;
      if (nw%1000000 == 0) cout << "\r - processing " << nw/1000000 << "M words";
      if (idx==(WordID) Vocab_None) {
        fwrite(&idx_unk, sizeof(idx_unk), 1, binf);
        nunk++;
        idx=oov_w->addWord(bptr);
#ifdef COUNT_OOV
        if (idx<0) {
          fprintf(stderr,"illegal OOV idx (%d) for word %s\n",idx, bptr);
          exit(1);
        }
        if (idx>oov_cnt.capacity()) oov_cnt.reserve(2*oov_cnt.capacity());
        oov_cnt[idx]++;  // TODO: resize vector ??
#endif
      }
      else {
        fwrite(&idx, sizeof(idx), 1, binf);
        if (idx<1 || idx>nvoc) {
          fprintf(stderr,"illegal word index (%d) for word %s\n",idx, bptr);
          exit(1);
        }
        wordfreq[idx]++;
      }

      bptr = eptr + 1;
      while ((*bptr != 0) && (*bptr != '\n') && (*bptr == ' ')) bptr++;

    }
    fwrite(&idx_eos, sizeof(idx_eos), 1, binf);
    for (i=0; i<3; i++) line[i]=0; // clear beginning of the buffer 
  }
  cout << "\r";

    // dump vocabulary with word frequencies to file
  int ndiff=0;
  {
    cout << " - dumping word frequencies to file " << wfreq_fname << endl;
    File file(wfreq_fname, "w");
    for (i=0; i<nvoc; i++) {
      if (wordfreq[i]) ndiff++;
      fprintf(file, "%s %d\n", voc->getWord(i), wordfreq[i]);
    }
  }

    // dump list of OOVs to file
  {
    cout << " - dumping list of OOV to file " << oov_fname << endl;
    File file(oov_fname, "w");
    oov_w->remove("-pau-");
    oov_w->remove("<unk>");
    oov_w->remove("<s>");
    oov_w->remove("</s>");
    for (i=0; i<(WordID) oov_w->numWords(); i++) {
      if (oov_w->getWord(i))
#ifdef COUNT_OOV
        fprintf(file, "%s %d\n", oov_w->getWord(i), oov_cnt[i]);
#else
        fprintf(file, "%s\n", oov_w->getWord(i));
#endif
    }
  }

    // write header with actual values: nb_lines, nb_words, nbvoc, bos, eos, unk
  rewind(binf);
  fwrite(&nl, sizeof(int), 1, binf);
  fwrite(&nw, sizeof(int), 1, binf);
  fwrite(&nvoc, sizeof(int), 1, binf);
  i=sizeof(WordID);
  fwrite(&i, sizeof(int), 1, binf);
  fwrite(&idx_bos, sizeof(WordID), 1, binf);
  fwrite(&idx_eos, sizeof(WordID), 1, binf);
  fwrite(&idx_unk, sizeof(WordID), 1, binf);
    
    // print final stats
  printf(" - %d lines with %d words processed, %d uniq words (%5.2f%% of the vocabulary)\n",
	nl, nw, ndiff, 100.0*ndiff/nvoc);
  printf(" - %d words were unknown (%5.2f%% of the text), %d new words\n", nunk, 100.0*nunk/nw, oov_w->numWords()-4);
    // we remove the 4 spezial words from the UNK vocab, but the size of the vocabulary
    // is not corrected by the SRI toolkit

  delete [] wordfreq;
  delete voc;
  delete oov_w;
#ifdef COUNT_OOV
  oov_cnt.clear();
#endif

  return 0;
}
