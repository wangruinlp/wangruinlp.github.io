/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Timer.h,v 1.2 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
using namespace std;

class Timer {
private:
  clock_t c_cumul;	// cumuated CPU clocks
  double r_cumul;	// cumulated real time
  clock_t c_beg;
  timeval t_beg;
public:
  Timer() : c_cumul(0), r_cumul(0) {};
  void start() {
    c_beg=clock();
    gettimeofday(&t_beg, NULL);
  }
  void stop() {
    c_cumul += clock()-c_beg;

    timeval t_end;
    gettimeofday(&t_end, NULL);
    r_cumul += (double) (t_end.tv_sec + t_end.tv_usec/1000000.0)
             - (double) (t_beg.tv_sec + t_beg.tv_usec/1000000.0);
  }

  void disp(const char *txt) {
    if (r_cumul>0) printf("%sreal=%.2fs, cpu=%.2fs", txt, r_cumul, (float) c_cumul/CLOCKS_PER_SEC);
  }
};
 
