/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: NbestLM.h,v 1.8 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _NBESTLM_H_
#define _NBESTLM_H_

using namespace std;

#include <string>
#include <vector>
#include "Hypo.h"

#define RESCORE_MODE_BOS 1
#define RESCORE_MODE_EOS 2

class NbestLM {
protected:
  string fname;  // translation
  int lm_order;  // order of NbestLM
  int mode;
  vector<int> nb_ngrams;  // nb of ngrams per order, nb_ngrams[0] is voc. size
public:
  NbestLM() : mode(RESCORE_MODE_BOS | RESCORE_MODE_EOS) {};
  virtual ~NbestLM() {};
  virtual float GetValue() {return 0; };
  virtual bool Read (const string &, int const order = 4);
  virtual void RescoreHyp (Hypo &hyp, const int lm_pos) {};   // recalc LM score on hypothesis
  virtual void FinishPending() {};	// finish pending requests, only used for CSLM
  virtual void Stats() {};		// display stats
};

#endif
