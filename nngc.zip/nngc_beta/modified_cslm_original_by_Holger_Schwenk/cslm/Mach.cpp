/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Mach.cpp,v 1.29 2012/06/03 11:19:28 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <signal.h>

#include "Tools.h"
#include "Mach.h"
#include "MachTab.h"
#include "MachLin.h"
#include "MachSig.h"
#include "MachTanh.h"
#include "MachSoftmax.h"
#include "MachSeq.h"
#include "MachPar.h"

vector<Mach*> signal_mach;

#ifdef BLAS_CUDA
# include "Blas.h"
  // global variables
cublasStatus cuda_stat;
curandGenerator_t cuda_gen;
int cuda_dev=0;

void cuda_init()
{
  static int cuda_init_status=-1;
  struct cudaDeviceProp props;

  if (cuda_init_status>=0) return;

  cout << "Initializing Nvidia GPU card" << endl;
  cublasInit();
  cuda_check_error("initialization of card\n");
  curandCreateGenerator(&cuda_gen, CURAND_RNG_PSEUDO_DEFAULT);
  cuda_check_error("initialization of random generator\n");
  cuda_init_status=0;

  int n, d;
  cudaGetDeviceCount(&n);
  if (n>1) {
    cout << " - found " << n << " cards:" << endl;
    for (d=0; d<n; d++) {
      cudaGetDeviceProperties(&props, d);
      printf("    %d: %s with %d CPUs x %d threads running at %4.2f Ghz, %d MBytes of memory\n",
	  d, props.name, props.multiProcessorCount, props.warpSize, props.clockRate/1000000.0, (int) (props.totalGlobalMem/1024/1024));
    }
    if (cuda_dev<0 || cuda_dev>=n) Error("wrong CUDA device requested");
    printf(" - using device %d\n", cuda_dev);
    cudaSetDevice(cuda_dev);
  }
  else {
    cudaGetDeviceProperties(&props, 0);
    printf(" - found %s with %d CPUs x %d threads running at %4.2f Ghz, %d MBytes of memory\n",
	  props.name, props.multiProcessorCount, props.warpSize, props.clockRate/1000000.0, (int) (props.totalGlobalMem/1024/1024));
    if (cuda_dev!=0) Error("wrong CUDA device requested");
  }

}
#else

int inc1=1;
#endif

void HandlerSigUSR1(int s) {
  time_t now;
  time(&now); // TODO: ctime is not rentrant ! use ctime_r() instead if needed
  cout << " - catched signal USR1 at " << ctime(&now) << endl;
  signal_mach[0]->Info(false, (char*)" -   ");
  cout.flush();
  //for (uint i=0; i<1; i++) signal_mach[i]->Info(false, (char*)" -   ");
  signal(SIGUSR1, HandlerSigUSR1);
}

//***********************************************

#ifdef BLAS_CUDA
void Mach::do_alloc()
{  
  cuda_init();

  data_out = cuda_alloc(odim*bsize, "output data for a machine");
  data_in=NULL; //  should be set later by SetDataIn() 

  grad_in = cuda_alloc(idim*bsize, "input gradient for a machine");
  grad_out=NULL; // should be set later by SetGradOut()
}
#endif

//***********************************************

#ifndef BLAS_CUDA
void Mach::do_alloc()
{
  if (odim*bsize>0) {
    data_out=::new REAL[odim*bsize];
    if (!data_out) Error ("can't allocate memory for data_out");
  }
  else data_out=NULL;
  data_in=NULL; // (luint) this) should be set later by SetDataIn() 
  if (idim*bsize>0) {
    grad_in=::new REAL[idim*bsize];
    if (!grad_in) Error ("can't allocate memory for grad_in");
  }
  else grad_in=NULL;
  grad_out=NULL; // (luint) this) should be set later by SetGradOut()
}
#endif


Mach::Mach(const int p_idim, const int p_odim, const int p_bsize, const int p_nbfw, const int p_nbbw)
 : idim(p_idim), odim(p_odim), bsize(p_bsize), nb_forw(p_nbfw), nb_backw(p_nbbw)
{
  do_alloc();

    // setup SIGUSR1 handler
  //cout << " - setting up handler for signal USR1" << endl;
  if (signal_mach.empty()) signal(SIGUSR1, HandlerSigUSR1);
  signal_mach.push_back(this);
}

Mach::~Mach()
{
#ifdef BLAS_CUDA
  if (data_out) cublasFree(data_out);
  if (grad_in) cublasFree(grad_in);
#else
  if (data_out) delete [] data_out;
  if (grad_in) delete [] grad_in;
#endif
  signal_mach.pop_back();	 //TODO: we should search for correct machine and delete it
}

//-----------------------------------------------
// File output
//-----------------------------------------------

void Mach::WriteParams(ofstream &of) {
    // write machine specific params
  of.write((char*) &nb_forw, sizeof(int));
  of.write((char*) &nb_backw, sizeof(int));
}

void Mach::WriteData(ofstream &of) {
  const int i=0, s=sizeof(REAL);
  of.write((char*) &i, sizeof(int));
  of.write((char*) &s, sizeof(int));
}

void Mach::Write(ofstream &of)
{
  char header[file_header_size];
  for (int i=0; i<file_header_size; i++) header[i]=' ';
  sprintf(header,"%s %d",file_header_name, file_header_version);
  of.write(header,file_header_size);
  of.write((char*) &idim, sizeof(int));
  of.write((char*) &odim, sizeof(int));
  of.write((char*) &bsize, sizeof(int));
  int mtype=GetMType();
  of.write((char*) &mtype, sizeof(int));
  WriteParams(of);
  WriteData(of);
}

//-----------------------------------------------
// File input
//-----------------------------------------------


void Mach::ReadParams(ifstream &inpf, bool with_alloc)
{
  inpf.read((char*) &nb_forw, sizeof(int));
  inpf.read((char*) &nb_backw, sizeof(int));
}

void Mach::ReadData(ifstream &inpf, size_t s)
{
  // there is nothing to read
}

Mach *Mach::Read(ifstream &inpf )
{
  char header[file_header_size], h[file_header_size];
  int v;

  inpf.read(header,file_header_size);
  if (sscanf(header,"%s %d",h,&v) != 2) {
    fprintf(stderr,"format of machine file not recognised: %s", header);
    Error();
  }
  if (strcmp(h,file_header_name)) {
    fprintf(stderr, "unsupported file type (%s), expected '%s'\n", h, file_header_name);
    Error();
  }
  switch (file_header_version) {
    case file_header_version: break;
    default:
      fprintf(stderr,"unsupported version of machine file (%d)\n",v);
      Error();
  }

    // read idim, odim, bsize 
  int f_idim, f_odim, f_bsize;
  inpf.read((char*) &f_idim, sizeof(int));
  inpf.read((char*) &f_odim, sizeof(int));
  inpf.read((char*) &f_bsize, sizeof(int));

   // read and parse machine type
  int mtype;
  Mach *m;
  inpf.read((char*) &mtype, sizeof(int));
  switch (mtype) {
    case file_header_mtype_base: m = new Mach(f_idim,f_odim,f_bsize); break;
    case file_header_mtype_tab: m = new MachTab(NULL,f_idim,f_odim,f_bsize,0,0); break;
    case file_header_mtype_lin: m = new MachLin(f_idim,f_odim,f_bsize); break;
    case file_header_mtype_sig: m = new MachSig(f_idim,f_odim,f_bsize); break;
    case file_header_mtype_tanh: m = new MachTanh(f_idim,f_odim,f_bsize); break;
    case file_header_mtype_softmax: m = new MachSoftmax(f_idim,f_odim,f_bsize); break;
    case file_header_mtype_multi: m = new MachMulti(); break;
    case file_header_mtype_mseq: m = new MachSeq(); break;
    //case file_header_mtype_mstack: m = new MachStack; break;
    case file_header_mtype_mpar: m = new MachPar(); break;
    default:
      fprintf(stderr,"unknown machine type in file (%d)\n", mtype);
      Error();
  }

    // read rest of (machine specific) params
  m->ReadParams(inpf);

  int s;
  inpf.read((char*) &s,sizeof(int));  // number of elements
  inpf.read((char*) &v,sizeof(int));  // size in bytes of each element
  if (v != sizeof(REAL)) {
    fprintf(stderr, "binary data on file uses %d bytes while the current code is compiled for %lu bytes\n", v, sizeof(REAL));
    Error();
  }
  m->ReadData(inpf, s);
  // TODO: check EOF

  return m;
}

//-----------------------------------------------
// Tools
//-----------------------------------------------

void Mach::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << " - dimensions: in=" << idim << ", out=" << odim << endl;
    cout << " - number of parallel examples=" << bsize << endl;
    cout << " - number of passes: " << nb_forw << "/" << nb_backw << endl;
  }
  else {
    printf("%sMach %d-%d, bs=%d, passes=%d/%d", txt, idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");
  }
}

//-----------------------------------------------
// Training
//-----------------------------------------------

void Mach::Forw(int eff_bsize)
{
  if (idim!=odim)
    Error("Mach::Forw(): call to default Forw() function with different dimensions");
  if (eff_bsize<=0) eff_bsize=bsize;
  if (!data_in)
    Error("Mach::Forw(): input data is not set");

#ifdef PROFILE
  tm.start();
#endif

#ifdef BLAS_CUDA
  COPY(eff_bsize*idim,data_in,1,data_out,1); // this does work on host or GPU
#else
  int dim=eff_bsize*idim;
  COPY(&dim,data_in,&inc1,data_out,&inc1); // this does work on host or GPU
#endif
  nb_forw += eff_bsize;

#ifdef PROFILE
  tm.stop();
#endif
}

void Mach::Backw (const float lrate, const float wdecay, int eff_bsize)
{
  if (idim!=odim)
    Error("Mach::Backw(): call to default Train() function with different dimensions");
  if (!grad_out)
    Error("Mach::Backw(): output gradient is not set");

  if (eff_bsize<=0) eff_bsize=bsize;
#ifdef BLAS_CUDA
  COPY(eff_bsize*idim,grad_out,1,grad_in,1);
#else
  memcpy(grad_in,grad_out,eff_bsize*idim*sizeof(REAL));
#endif
  nb_backw += eff_bsize;
}

