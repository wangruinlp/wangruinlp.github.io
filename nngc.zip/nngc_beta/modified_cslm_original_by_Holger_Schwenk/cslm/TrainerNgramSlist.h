/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: TrainerNgramSlist.h,v 1.15 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _TrainerNgramSlist_h
#define _TrainerNgramSlist_h

#include <ostream>
#include "Tools.h"
#include "Mach.h"
#include "ErrFct.h"
#include "DataNgramBin.h"
#include "TrainerNgram.h"
#include "WordList.h"

#ifdef LM_KEN
#  include <string>
#  include "lm/model.hh"
#endif

#ifdef LM_SRI
#  include "BackoffLmSri.h"
#endif

//
// Class to train neural networks to predict n-gram probabilities
//  - we use a short list of words for which the NN predicts the proba
//  - the proba of the other words are obtained by a classical back-off LM
//  - the NN also predicts the proba mass of ALL the words not in the short slist
//    for this we use the last output neuron of the network


//
// helper class to store and compare one ngram LM request
// ugly C-style structure, but this seems to be more efficient

struct NgramReq {
  int ctxt_len;
  WordID *ctxt, wpred;
  int bs;
  REAL *res_ptr;
};

/*
public:
  NgramReq(WordID *wid, int order, float *adrP)
    : ctxt_len(order-1), ctxt(new WordID[ctxt_len]), wpred(wid[ctxt_len]), res_ptr(adrP)
    { // printf("constructor NgramReq addr=%p\n", this); 
       for (int i=0; i<ctxt_len; i++) ctxt[i]=wid[i]; }
  ~NgramReq() { delete [] ctxt; }

   friend bool operator<(const NgramReq &n1, const NgramReq &n2)
   { // printf("compare %p[%d] < %p[%d]\n", n1, n1->ctxt[0], n2, n2->ctxt[0]);
     for (int i=0; i< (n1.ctxt_len < n2.ctxt_len) ? n1.ctxt_len : n2.ctxt_len; i++) {
       if (n1.ctxt[i] < n2.ctxt[i]) return true;
       if (n1.ctxt[i] > n2.ctxt[i]) return false;
     }
     return true; // both are equal
   }
   
   friend bool operator==(const NgramReq &n1, const NgramReq &n2)
   {  //printf("operator %p < %p\n", this, &n2);
     for (int i=0; i<n1.ctxt_len; i++) {
       if (n1.ctxt[i] != n2.ctxt[i]) return false;
     }
     return true; // both are equal
   }

   friend int NgramReqComp(const void *v1, const void *v2);

   void display() {
     printf(" %d-word ctxt:", ctxt_len);
     for (int c=0; c<ctxt_len; c++) printf(" %d", ctxt[c]);
     printf(" -> %d, addr=%p\n", wpred, res_ptr);
   }
};
*/


class TrainerNgramSlist : public TrainerNgram
{
private:
  int		mode;		// similar to class DataNgramBin, used to decide which n-grams
				// are processed during validation,
				// TODO: we should get this info automatically from the DataFile
				// During training we always present all n-grams to the NN
				// -> it is possible to select the mode by the DataFile
    // copies of important fields
  int		nb_ex_slist;	// total number of examples processed in slist
  int		nb_ex_short;	// total number of examples with short n-grams
  char		*wlist_fname;
  char		*lm_fname;
// TODO: use WordID vector for targets in order to make less casts 
  WordID	*lm_buf_target;	// keep track of word indices not in short list (which are all done by same output)
  WordID	slist_len;	// length of slist (this is set to the size of the output layer MINUS ONE)
  BackoffLm	*blm;		// this must be a pointer so that polymorphism will work !
    // CSLM use different indices of the words than the provided word list
    // they are mapped so that the most frequent words have consecutive indices
    // This speeds up calculation and facilitates the decision which words are in the short list
  vector<WList>	wlist;
  vector<WordID> map_wl2cslm;	// map WordIDs from word list to CSLM internal
#ifdef DEBUG
  vector<char*>  words;		// give UTF8 word for a given CSLM internal index
#endif
  bool in_slist(WordID wid) {return wid < slist_len;};	// check if current word is in short list
  REAL DoTestDev(char*, bool);	// internal helper function
  void DoConstructorWork();	// internal helper function for the various constructors
    // data and functions for block processing
  int	max_req;		// max number of request cumulated before we perform them in a block
  int	nreq;			// current number of request cumulated before we perform them in a block
  NgramReq *req;		// array to allocate all requests
  int	nb_ngram;		// total number of n-grams requested
  int	nb_forw;		// stats on total number of forward passes
  void FreeReq();
protected:
  virtual void InfoPost();			// dump information after finishing a training epoch
  virtual void ForwAndCollect(int,int,int,bool);	// internal helper function
public:
  TrainerNgramSlist(Mach*, ErrFct*, char*, char*,	// mach, errfct, train, dev
	  char*, char*,				// word list, LM
          REAL =0.01, REAL =0, REAL =0,		// lrate_beg, lrate_mult, wdecay
	  int =10, int =0);			// max epochs, current epoch
  TrainerNgramSlist(Mach*, ErrFct*, Data&,	// for testing only: mach, errfct, binary data
	char*, char*);				// word list, LM
  TrainerNgramSlist(Mach*, char*, char*);	// for general proba calculation: mach, word list, LM
  virtual ~TrainerNgramSlist();			// TODO: free vector words
  virtual REAL Train();				// train for one epoch
  virtual REAL TestDev(char* pfname=NULL)	// test current network on dev data and save outputs into file
    { return DoTestDev(pfname, false); }
  virtual REAL TestDevRenorm(char* pfname=NULL)	// same, but renormalize all probabilities with back-off LM proba-mass (costly)
    { return DoTestDev(pfname, true); }
  virtual Vocab *GetVocab() {return (Vocab*) blm->GetVocab(); }
    // fast block evaluation functions
  virtual void BlockSetMax(int=65536);			// set size of requests to be delayed before actual calculation
  virtual int BlockGetFree()				// returns the number of requested that can still be delayed before
  { return (int) max_req-nreq; }			// we evaluate a whole block. This can be used to keep together a sequence
							// of request, i.e. individual n-grams of a whole sentence
  virtual void BlockEval(WordID *wid, int o, REAL*p); 	// request n-gram, result WILL be stored at address
  virtual void BlockFinish();				// finish all pending requests
  virtual void BlockStats();				// display some stats on Block mode
};

#endif
