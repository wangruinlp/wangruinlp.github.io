/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Mach.h,v 1.19 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _Machine_h
#define _Machine_h

#include <iostream>
#include <fstream>
#include "Tools.h"
#include "Blas.h"
#include "Timer.h"

// list of all known machine types,
// this is needed for the general file read function

#define file_header_name "HPerf"
#define file_header_version 1
#define file_header_size 16

#define file_header_mtype_base		0
#define file_header_mtype_tab		1
#define file_header_mtype_tabsh		2
#define file_header_mtype_lin		3
#define file_header_mtype_sig		4
#define file_header_mtype_tanh		5
#define file_header_mtype_softmax	6
#define file_header_mtype_stab		7
#define file_header_mtype_multi		16
#define file_header_mtype_mseq		17
#define file_header_mtype_msplit	18
#define file_header_mtype_mpar		19

class Mach
{
private:
  void do_alloc();	// perform allocation of dynamic data structures
protected:
  int  idim, odim;		// input and output dimension
  int  bsize;			// block size (nb of example used in parallel)
  int  nb_forw;			// nb of forward examples processed
  int  nb_backw;		// nb of backward examples processed
   // CUDA: the following four variables refer to device memory
  REAL *data_in;		// input data (pointer)
				// CUDA: we need to allocate device memory
  REAL *data_out;		// output data (allocated by machine)
  REAL *grad_in;		// input gradients (allocated by machine)
  REAL *grad_out;		// output gradients (pointer)
				// CUDA: we need to allocate device memory
#ifdef PROFILE
  Timer   tm;			// count real and user time
#endif
  // File I/O, the following functions can be overloaded by subclass
  // the main functions Read() and Write() should not be modified !
  virtual void ReadParams(ifstream&, bool=true); // read all params
  virtual void ReadData(ifstream&, size_t); // read binary data
  virtual void WriteParams(ofstream&); // write all params
  virtual void WriteData(ofstream&); // write binary data
public:
  Mach(const int=0, const int=0, const int=1, const int=0, const int=0);	
  virtual ~Mach();
    // Tools
  virtual int GetMType() {return file_header_mtype_base;};	// get type of machine
  virtual int GetIdim() {return idim;}
  int GetOdim() {return odim;}
  int GetBsize() {return bsize;}
  void SetBsize(int bs) {
    if (bs<1) Error("wrong value in SetBsize()"); else bsize=bs; }
  int GetNbForw() {return nb_forw;}
  int GetNbBackw() {return nb_backw;}
  virtual int GetNbParams() {return 0;}		// return the nbr of allocated parameters 
  virtual REAL* GetDataIn() {return data_in;}	// return pointer on input data for chaining
  virtual REAL* GetDataOut() {return data_out;}	// return pointer on output data for chaining
  virtual REAL* GetGradIn() {return grad_in;}	// return pointer on input gradient for chaining
  virtual REAL* GetGradOut() {return grad_out;} // return pointer on output gradient for chaining
  virtual void SetDataIn(REAL *data) {data_in=data;} // set pointer of input data
  virtual void SetGradOut(REAL *data) {grad_out=data;} // set pointer of output gradient 
  virtual void Info(bool=false, char *txt=(char*)" - ");// display (detailed) information on machine
    // FILE IO
  static Mach *Read(ifstream&);	// read class from a stream
  void Write(ofstream&); // write content of class to a stream
    // Training
  virtual void Forw(int=0);	// calculate outputs for current inputs
    // backprop gradients from output to input and update all weights
  virtual void Backw (const float lrate, const float wdecay, int =0);
};

#endif
