/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Toolsgz.cpp,v 1.4 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <stdexcept>
#include <stdlib.h>
#include "Toolsgz.h"

int Weights::Read(const char *fname) {
  ifstream inpf;
  
  inpf.open(fname);
  if (inpf.fail()) {
    perror ("ERROR"); exit(1);
  }

  float f;
  while (inpf >> f) val.push_back(f);  

  inpf.close();
  return val.size();
}

//
//
//

void gzifstream::open(char *fname)
{
  //check if file is readable
  std::filebuf* fb = new std::filebuf();
  _fail=(fb->open(fname, std::ios::in)==NULL);

  char *sptr=strrchr(fname,'.');
  if (sptr && strcmp(sptr,".gz")==0) {
    fb->close(); delete fb;
    gz_streambuf = new gzfilebuf(fname);
  } else {
    gz_streambuf = fb;
  }
  this->init(gz_streambuf);
}


void gzofstream::open(char *fname)
{
  //check if file is readable
  std::filebuf* fb = new std::filebuf();
  _fail=(fb->open(fname, std::ios::out)==NULL);
  //cerr << "fail: " << _fail <<endl;

  char *sptr=strrchr(fname,'.');
  if (sptr && strcmp(sptr,".gz")==0) {
    fb->close(); delete fb;
    gz_streambuf = new gzfilebuf(fname);
  } else {
    gz_streambuf = fb;
  }
  this->init(gz_streambuf);
}

//
//
//

inputfilestream::inputfilestream(const std::string &filePath)
: std::istream(0),
m_streambuf(0)
{
  //check if file is readable
  std::filebuf* fb = new std::filebuf();
  _good=(fb->open(filePath.c_str(), std::ios::in)!=NULL);
  
  if (filePath.size() > 3 &&
      filePath.substr(filePath.size() - 3, 3) == ".gz")
  {
    fb->close(); delete fb;
    m_streambuf = new gzfilebuf(filePath.c_str());  
  } else {
    m_streambuf = fb;
  }
  this->init(m_streambuf);
}

inputfilestream::~inputfilestream()
{
  delete m_streambuf; m_streambuf = 0;
}

void inputfilestream::close()
{
}

outputfilestream::outputfilestream(const std::string &filePath)
: std::ostream(0),
m_streambuf(0)
{
  //check if file is readable
  std::filebuf* fb = new std::filebuf();
  _good=(fb->open(filePath.c_str(), std::ios::out)!=NULL);  
  
  if (filePath.size() > 3 && filePath.substr(filePath.size() - 3, 3) == ".gz")
  {
    fb->close(); delete fb;
    m_streambuf = new gzfilebuf(filePath.c_str());  
  } else {
    m_streambuf = fb;
  }
  this->init(m_streambuf);
}

outputfilestream::~outputfilestream()
{
  delete m_streambuf; m_streambuf = 0;
}

void outputfilestream::close()
{
}

