/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataNgramBin.h,v 1.7 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _DataNgramBin_h
#define _DataNgramBin_h

#include <iostream>
#include <fstream>

#include "DataFile.h"

extern const char* DATA_FILE_NGRAMBIN;

// Syntax of a line in data description:
// DataNgramBin <file_name> <resampl_coeff> <order> [flags]
//  u: skip n-grams with <unk> at the right most position
//  U: skip n-grams with <unk> anywhere
//  b: skip n-grams with <s> elsewhere than at the left most position
//  e: skip n-grams with </s> elsewhere than at the right most position

class DataNgramBin : public DataFile
{
private:
  void do_constructor_work();
protected:
  int fd;		// UNIX style binary file
  int vocsize;		// vocab size (including <s>, </s> and <unk>)
  int order;		// order of the ngrams
  int mode;		// see above for possible flags
  WordID *wid;		// whole n-gram context
  WordID bos, eos, unk;	// word ids of special symbols
    // stats (in addition to nbex in mother class)
  int  nbl, nbw, nbs, nbu;// lines, words, sentences, unks
  int  nbi;		// ignored n-grams
public:
  DataNgramBin(ifstream &ifs);
  DataNgramBin(char*, float =1.0, int =4, int =3);
  virtual ~DataNgramBin();
  virtual int Info();
  virtual bool Next();
  virtual void Rewind();
  virtual WordID GetVocSize() {return vocsize;};
};

#endif
