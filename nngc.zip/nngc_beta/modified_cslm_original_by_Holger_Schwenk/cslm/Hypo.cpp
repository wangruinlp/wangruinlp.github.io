/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Hypo.cpp,v 1.6 2012/06/02 13:24:16 schwenk Exp $
 */


#include "Hypo.h"
#include <iostream>

Hypo::Hypo()
{
  //cerr << "Hypo: constructor called" << endl;
}

Hypo::~Hypo()
{
  //cerr << "Hypo: destructor called" << endl;
}

void Hypo::Write(outputfilestream &outf)
{
  outf << id << NBEST_DELIM2 << trg << NBEST_DELIM2;
  for (vector<float>::iterator i = f.begin(); i != f.end(); i++)
    outf << (*i) << " ";
  outf << NBEST_DELIM << " " << s << endl;

}

float Hypo::CalcGlobal(Weights &w)
{
  //cerr << " HYP: calc global" << endl;
  uint sz=w.val.size();
  if (sz<f.size()) {
    cerr << " - NOTE: padding weight vector with " << f.size()-sz << " zeros" << endl;
    w.val.resize(f.size());
    for (uint i=sz; i<w.val.size(); i++) w.val[i]=0;
  }

  s=0;
  for (uint i=0; i<f.size(); i++) {
    //cerr << "i=" << i << ", " << w.val[i] << ", " << f[i] << endl;
    s+=w.val[i]*f[i];
  }
  //cerr << "s=" << s << endl;
  return s;
}

// this is actually a "greater than" since we want to sort in descending order
bool Hypo::operator< (const Hypo &h2) const {
  return (this->s > h2.s);
}

