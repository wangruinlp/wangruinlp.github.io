/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachLin.h,v 1.19 2012/06/02 13:24:16 schwenk Exp $
 *
 * linear machine:  output = weights * input + biases
 */

#ifndef _MachLin_h
#define _MachLin_h

#include "Mach.h"

class MachLin : public Mach
{
protected:
   // CUDA: the following two variables refer to device memory
  REAL *b;		// biases
  REAL *w;		// weights, stored in BLAS format, e.g. COLUMN major !
  virtual void ReadData(ifstream&, size_t); // read binary data
  virtual void WriteData(ofstream&); // write binary data
public:
  MachLin(const int=0, const int=0, const int=1, const int=0, const int=0);	
  virtual ~MachLin();
  virtual int GetNbParams() {return idim*odim+odim;}		// return the nbr of allocated parameters 
  virtual int GetMType() {return file_header_mtype_lin;};	// get type of machine
  virtual void BiasConst(const REAL val);			// init biases with constant values
  virtual void BiasRandom(const REAL range);			// random init of biases in [-range, range]
  virtual void WeightsConst(const REAL val);			// init weights with constant values
  virtual void WeightsRandom(const REAL range);			// random init of weights in [-range, range]
  virtual void WeightsRandomFanI(const REAL range=sqrt(6.0));	// random init of weights in fct of fan-in
  virtual void WeightsRandomFanIO(const REAL range=sqrt(6.0));	// random init of weights in fct of fan-in and fan-out
  virtual void Info(bool=false, char *txt=(char*)"");		// display (detailed) information on machine
  virtual void Forw(int=0);	// calculate outputs for current inputs
    // backprop gradients from output to input and update all weights
  virtual void Backw (const float lrate, const float wdecay, int=0);
  virtual void Debug ();
};

#endif
