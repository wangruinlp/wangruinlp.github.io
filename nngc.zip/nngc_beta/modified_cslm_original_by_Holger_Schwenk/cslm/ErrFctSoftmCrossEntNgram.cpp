/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: ErrFctSoftmCrossEntNgram.cpp,v 1.14 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <unistd.h>
#include <time.h>

#include "Tools.h"
#include "ErrFctSoftmCrossEntNgram.h"
#include "Blas.h"


//**********************************************************************************
// E = log(sum_i d_i ln o_i)
//   = ln o_t     where t is the target index
//   output: dimension voc_size
//   target: dimension 1 with values [0,voc_size[
// We also take the log since this can't be done later if bsize>1

REAL ErrFctSoftmCrossEntNgram::CalcValue(int eff_bsize)
{

  if (eff_bsize<=0) eff_bsize=bsize;

#ifdef BLAS_CUDA
  return GpuErrFctSoftmCrossEntNgramCalcValue(eff_bsize, dim, output, target);
#else
  REAL *tptr=target;
  REAL *optr=output;
  double err=0.0;

  for (int b=0; b<eff_bsize; b++) {
    //printf("b=%d, tidx=%f, out=%f\n", b, *tptr, optr[(uint) *tptr]);
    err += log(optr[(uint) *tptr++]);
    //printf("err=%f\n",err);
    optr += dim;
  }
  return (REAL) err; // TODO: normalize ?
#endif
}


//**********************************************************************************
// E = log(sum_i d_i ln o_i)
//   = ln o_t     where t is the target index
//   output: dimension voc_size
//   target: dimension 1 with values [0,voc_size[
// We also take the log since this can't be done later if bsize>1

REAL ErrFctSoftmCrossEntNgram::CalcValueNth(int idx)
{
#ifdef BLAS_CUDA
  Error("CUDA:  ErrFctSoftmCrossEntNgram::CalcValueNth() not implemented");
  return 0.0;
#else
  REAL	*optr=output + idx+dim;
  REAL	*tptr=target + idx+dim;

  return log(optr[(uint) *tptr]);
#endif
}


// We include here the derivation of the softmax outputs since we have
//   dE/da_k = sum_i dE/do_i do_i/da_k
// Due to the sum, dE/do_i and do_i/da_k can't be calculated separately
// dE/do_i = d_i/o_i
// do_i/da_k = o_i (kronecker_ik - o_k)
//  -> dE/da_k = sum_i d_i/o_i * o_i (kronecker_ik - o_k)
//             = sum_i d_i (kronecker_ik - o_k)
//             = (kronecker_tk - o_k)       since d_i=0 for i!=t
REAL ErrFctSoftmCrossEntNgram::CalcGrad(int eff_bsize)
{
  if (eff_bsize<=0) eff_bsize=bsize;

#ifdef BLAS_CUDA
  return GpuErrFctSoftmCrossEntNgramCalcGrad(eff_bsize, dim, output, grad, target);
#else

  REAL *optr=output;
  REAL *gptr=grad;
  REAL *tptr=target;
  uint	tidx;
  REAL err=0.0;
  int n=eff_bsize*dim; REAL f1=-1.0;

  memcpy(grad,output,n*sizeof(REAL));
  SCAL(&n,&f1,grad,&inc1);
  for (int b=0; b<eff_bsize; b++) {
    tidx=(uint) *tptr++;
    gptr[tidx] += 1.0;
    err += log(optr[tidx]);
    gptr+=dim; optr+=dim;
  }

  return (REAL) err;
#endif
}


