/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataFile.cpp,v 1.9 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <stdlib.h>
extern double drand48();

#include "Tools.h"
#include "Data.h"
#include "DataFile.h"

DataFile::DataFile(ifstream &ifs)
 : idim(0), odim(0), nbex(0), resampl_coeff(1.0), fname(NULL),
   idx(-1), input(NULL), target_vect(NULL), target_id(0)
{
  char p_fname[DATA_LINE_LEN];
  
  ifs >> p_fname >> resampl_coeff;
  if (resampl_coeff<=0 || resampl_coeff>1)
    Error("resampl coefficient must be in (0,1]\n");
  fname=strdup(p_fname);

  // memory allocation of input and target_vect should be done in subclass
  // in function of the dimension and number of examples
}

DataFile::DataFile(char *p_fname, float p_rcoeff)
 : idim(0), odim(0), nbex(0), resampl_coeff(p_rcoeff), fname(strdup(p_fname)),
   idx(-1), input(NULL), target_vect(NULL), target_id(0)
{

  // memory allocation of input and target_vect should be done in subclass
  // in function of the dimension and number of examples
}

DataFile::~DataFile()
{
  if (fname) free(fname);
  // memory deallocation of input and target_vect should be done in subclass
 
}

/**************************
 *  
 **************************/

int DataFile::Info()
{
  int nbr=resampl_coeff*nbex;
  printf(" - %s  %6.4f * %9d = %9d\n", fname, resampl_coeff, nbex, nbr);
  return nbr;
}

/**************************
 *  
 **************************/

void DataFile::Rewind()
{
  Error("DataFile::Rewind() should be overriden");
}

//*************************
// read next data in File
// Return false if EOF

bool DataFile::Next()
{
  Error("DataFile::Next() should be overriden");
  return false;
}

//**************************
// generic resampling function using sequential file reads
// cycles sequentially through data until soemthing was found
// based on DataNext() which may be overriden by subclasses
// returns idx of current example

int DataFile::Resampl()
{
  bool ok=false;

  while (!ok) {
    if (!Next()) Rewind(); // TODO: deadlock if file empty
//cout << "Resampled: ";
//for (int i=0; i<idim; i++) cout << input[i] << " ";
    ok = (drand48() < resampl_coeff);
//cout << " ok=" << ok << endl;
  }
 
  return idx;
}

