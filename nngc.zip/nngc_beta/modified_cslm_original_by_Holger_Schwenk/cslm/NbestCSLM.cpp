/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: NbestCSLM.cpp,v 1.15 2012/06/02 13:24:16 schwenk Exp $
 */


#include "Ngram.h"	// from SRI, subclass of LM

#include "Tools.h"
#include "Hypo.h"
#include "NbestCSLM.h"
#include "ErrFctSoftmCrossEntNgram.h"

#undef DUMMY_MACHINE
#ifdef DUMMY_MACHINE
 #include "Mach.h"
 #include "MachTab.h"
 #include "MachTanh.h"
 #include "MachSoftmax.h"
 #include "MachSeq.h"
 #include "MachPar.h"
#endif

NbestCSLM::~NbestCSLM() {
  if (mach) delete mach;
  if (trainer) delete trainer;
  for (vector<HypSentProba*>::iterator i = delayed_hyps.begin(); i != delayed_hyps.end(); i++) {
    delete (*i);
  }
  delayed_hyps.clear();
}


bool NbestCSLM::Read(char *fname, char *wl_fname, char *lm_fname)
{
#ifdef DUMMY_MACHINE
  cout << " - rescoring with dummy CSLM " << endl;
  //int ctxt_size=4, idim=1000, pdim=256, hdim=128, slsize=1024, bsize=128;
  int ctxt_size=3, idim=1000, pdim=256, hdim=128, slsize=1, bsize=128;
  MachSeq *mseq = new MachSeq();
  MachPar *mp = new MachPar();
  MachTab *mt = new MachTab(idim,pdim,bsize);
  mt->TableRandom(0.1); mp->MachAdd(mt);
  REAL *tab_adr=mt->GetTabAdr();
  for (int i=1; i<ctxt_size; i++) {
    mt = new MachTab(tab_adr,idim,pdim,bsize);
    mp->MachAdd(mt);
  }
  mseq->MachAdd(mp);
  MachTanh *mh = new MachTanh(ctxt_size*pdim,hdim,bsize);
  mh->WeightsRandom(0.1); mh->BiasRandom(0.1);
  mseq->MachAdd(mh);
  MachSoftmax *mo = new MachSoftmax(hdim,slsize,bsize);
  mo->WeightsRandom(0.1); mo->BiasRandom(0.1);
  mseq->MachAdd(mo);
  mach=mseq;
#else
  ifstream ifs;
  ifs.open(fname,ios::binary);
  CHECK_FILE(ifs,fname);
  mach = Mach::Read(ifs);
  ifs.close();
#endif

  mach->Info();
  lm_order = mach->GetIdim()+1;
  
  trainer = new TrainerNgramSlist(mach, wl_fname, lm_fname);
  sri_vocab = trainer->GetVocab();
  cout << " - using SRILM vocabulary with " << sri_vocab->numWords() << " words\n";
 
  return true;
}

//
// Request the LM probs for all n-grams in one sentence
// The actual sentence log-proba will be calculated in FinishPending()
//
void NbestCSLM::RescoreHyp (Hypo &hyp, const int lm_pos)
{
  static TextStats tstats;
  static const int max_words=16384;
  static const int max_chars=max_words*16;
  static char str[max_chars];
  static VocabString vstr[max_words+1];

  strcpy(str,hyp.GetCstr()); // we need to copy since parseWords() modifies the string
  int nw = sri_vocab->parseWords(str, vstr, max_words + 1);
  if (nw == max_words+1) Error("too many words in one hypothesis\n");

  WordID wid[nw+3];
  int b=0;
    // start sentence with BOS ?
  if (mode & RESCORE_MODE_BOS) wid[b++]=sri_vocab->ssIndex();

  sri_vocab->getIndices(vstr, (VocabIndex*) (wid+b), nw + 1, sri_vocab->unkIndex());
#ifdef DEBUG
  for (int i=0;i<nw; i++) printf(" %s[%d]", vstr[i], wid[i+b]); cout<<endl;
#endif

    // end sentence with EOS ?
  nw += b;
  if (mode & RESCORE_MODE_EOS) wid[nw++]=sri_vocab->seIndex();


    // check whether we have enough space left to request all the n-grams from this hypo
    // (this needs to be done in one block since we will calculate the cumulated sentence proba)
  if (nw > trainer->BlockGetFree()) FinishPending();

    // allocate memory to store the delayed LM probabilities
  delayed_hyps.push_back(new HypSentProba(hyp, lm_pos, nw)); // (nw-1) would be actually enough

   // request n-grams that are shorter then CSLM order, starting with 2-, 3-, ... n-gram
  int n=2;
  while (n<lm_order && n<=nw) {
    trainer->BlockEval(wid, n, delayed_hyps.back()->GetAddrP()+n-2);
    n++;
  }
    // request all remaining full n-grams
  WordID *wptr=wid; 
  while (n<=nw) {  // we have n-1 full n-grams in a sentence with n-words
    trainer->BlockEval(wptr, lm_order, delayed_hyps.back()->GetAddrP()+n-2); // last address will be base+n-1
    n++, wptr++;
  }
  return;
}

void NbestCSLM::FinishPending()
{
  trainer->BlockFinish();

  for (vector<HypSentProba*>::iterator i = delayed_hyps.begin(); i != delayed_hyps.end(); i++) {
    (*i)->SetSentProba();
    delete (*i);
  }
  delayed_hyps.clear();
}

//
//
//
float NbestCSLM::GetValue ()
{
  Error("NbestCSLM::GetValue() not implemented\n");
  return 0;
}

void NbestCSLM::Stats()
{
  trainer->BlockStats();
}
