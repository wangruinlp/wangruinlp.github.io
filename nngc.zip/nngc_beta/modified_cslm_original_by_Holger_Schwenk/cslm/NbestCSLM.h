/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: NbestCSLM.h,v 1.12 2012/06/02 17:18:45 schwenk Exp $
 */


#ifndef _NBESTCSLM_H_
#define _NBESTCSLM_H_

using namespace std;

#include "NbestLM.h"
#include "Vocab.h" // from the SRI toolkit
#include "Mach.h" // from the CSLM toolkit
#include "TrainerNgramSlist.h" 
#include "ErrFct.h" 

class HypSentProba {
private:
  Hypo	&hyp;		// hypothesis for which we want to modify the sentence probability
  int   lm_pos;
  int	nw;		// number of words in this sentences
  REAL	*p;		// array to store the n-gram log probabilities
public:
  HypSentProba(Hypo &p_hyp, int p_pos, int p_nw) : hyp(p_hyp), lm_pos(p_pos), nw(p_nw), p(new REAL[nw]) {
  };
  ~HypSentProba() { delete [] p; }
  REAL *GetAddrP() {return p;}
  void SetSentProba()
  {
    REAL logP=0;
    for (int i=0; i<nw-1; i++) {
      logP+=p[i];
    }
    hyp.SetFeature(logP,lm_pos);
  }
};
  
  
class NbestCSLM : public NbestLM {
protected:
  Vocab *sri_vocab;
  Mach *mach;
    // storage to cumulate delayed LM probabilities for several hypotheses
  TrainerNgramSlist *trainer;
  vector<HypSentProba*> delayed_hyps;
public:
  NbestCSLM() : mach(NULL), trainer(NULL) {delayed_hyps.clear(); }
  virtual ~NbestCSLM();
  virtual float GetValue();
  virtual bool Read (char*, char*, char*);
  virtual void RescoreHyp (Hypo &hyp, const int lm_pos);   // recalc LM score on hypothesis, returns log10 probability
  virtual void FinishPending();
  virtual void Stats();
};

#endif
