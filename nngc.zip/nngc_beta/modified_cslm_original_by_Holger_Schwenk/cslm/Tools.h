/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Tools.h,v 1.20 2012/06/02 17:35:01 schwenk Exp $
 */

#ifndef _Tools_h
#define _Tools_h

#include <iostream>
#include <fstream>
#include <string.h>	// memcpy()
#include <stdlib.h>	// exit()
#include <math.h>	

typedef float REAL;			// precison of all the calculations
typedef int WordID;			// size of the binary word indices
#define NULL_WORD (-1)			// this is used to simulate an empty input which has no effect
					// on the forward and backward pass (since we have a fixed context length)

typedef unsigned int uint;
typedef long unsigned int luint;

static const int max_word_len=65534;	// should be more than enough when reading text lines ;-)
static const string cslm_version="V2.0";

//
// general purpose helper functions
//
#ifdef DEBUG
# define TRACE(txt) cout << txt;
#else
# define TRACE(txt)
#endif

void Error(void);
void Error(const char *txt);

#define CHECK_FILE(ifs,fname) if(!ifs) { perror(fname); Error(); }

//
// parsing of ASCII files
//
int ReadInt(ifstream&,const string&,int=0,int=2147483647); // TODO: MAXINT
float ReadFloat(ifstream&,const string&,float=0,float=3.4e38); // TODO: MAXFLOAT
string ReadText(ifstream&,const string&);

#endif
