/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: NBest.cpp,v 1.11 2012/06/02 13:24:16 schwenk Exp $
 */


#include "NBest.h"
#include "Tools.h"

#include <sstream>
#include <algorithm>


bool NBest::ParseLine(inputfilestream &inpf, const int n) {
  static string line; // used internally to buffer an input line
  static int prev_id=-1; // used to detect a change of the n-best ID
  int id;
  vector<float> f;
  vector<string> blocks;


  if (line.empty()) {
    getline(inpf,line);
    if (inpf.eof()) return false;
  }

    // split line into blocks
  //cerr << "PARSE line: " << line << endl;
  uint pos=0, epos;
  //while ((epos=line.find(NBEST_DELIM,pos))!=string::npos) {
  while ((epos=line.find(NBEST_DELIM,pos))<100000) {
    blocks.push_back(line.substr(pos,epos-pos));
    //cerr << " block from " << pos << " to " << epos << " : " <<  blocks.back() << endl;
    pos=epos+strlen(NBEST_DELIM);
  }
  blocks.push_back(line.substr(pos,line.size()));
  // cerr << " block: " << blocks.back() << endl;

  if (blocks.size()<4) {
    cerr << "ERROR: can't parse the following line (skipped)" << endl << line << endl;
    line.clear(); // force read of new line
    return true;
  }

    // parse ID
  id=Scan<int>(blocks[0]);
  if (prev_id>=0 && id!=prev_id) {prev_id=id; return false;} // new nbest list has started
  prev_id=id;
  //cerr << "same ID " << id << endl;

  if (n>0 && nbest.size() >= (uint) n) {
    //cerr << "skipped" << endl;
    line.clear();
    return true; // skip parsing of unused hypos
  }

    // parse feature function scores
  //cerr << "PARSE features: '" << blocks[2] << "' size: " << blocks[2].size() << endl;
  pos=blocks[2].find_first_not_of(' ');
  while (pos<blocks[2].size() && (epos=blocks[2].find(" ",pos))!=string::npos) {
    string feat=blocks[2].substr(pos,epos-pos);
    //cerr << " feat: '" << feat << "', pos: " << pos << ", " << epos << endl;
    if (feat.find(":",0)!=string::npos) {
      //cerr << "  name: " << feat << endl;
    }
    else { 
      f.push_back(Scan<float>(feat));
      //cerr << "  value: " << f.back() << endl;
    }
    pos=blocks[2].find_first_not_of(' ',epos+1);
  }
  //cerr << " FOUND " << f.size() << " features" << endl;

    // eventually parse segmentation
  if (blocks.size()>4) {
    static int info=0;
    if (!info) cerr << " - skipping segmentation information" << endl;
    info=true;
    //Error("parsing segmentation not yet supported");
  }

  nbest.push_back(Hypo(id, blocks[1], f, Scan<float>(blocks[3])));

  line.clear(); // force read of new line

  return true;
}


NBest::NBest(inputfilestream &inpf, const int n) {
  //cerr << "NBEST: constructor with file called" << endl;
  while (ParseLine(inpf,n));
  //cerr << "NBEST: found " << nbest.size() << " lines" << endl;
}


NBest::~NBest() {
  //cerr << "NBEST: destructor called" << endl;
  nbest.clear();
}

void NBest::Write(outputfilestream &outf, int n)
{
  if (n<1 || (uint) n>nbest.size()) n=nbest.size();
  for (int i=0; i<n; i++) nbest[i].Write(outf);
}


void NBest::CalcGlobal(Weights &w)
{
  //cerr << "NBEST: calc global of size " << nbest.size() << endl;
  for (vector<Hypo>::iterator i = nbest.begin(); i != nbest.end(); i++) {
    (*i).CalcGlobal(w);
  }
}


void NBest::Sort() {
  sort(nbest.begin(),nbest.end());
}


void NBest::AddID(const int o)
{
  for (vector<Hypo>::iterator i = nbest.begin(); i != nbest.end(); i++) {
    (*i).AddID(o);
  }
}

void NBest::RescoreLM(NbestLM &lm, const int lm_pos)
{
  for (vector<Hypo>::iterator i = nbest.begin(); i != nbest.end(); i++) {
    lm.RescoreHyp(*i,lm_pos);
  }
  lm.FinishPending();
}

