/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: Data.h,v 1.12 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _Data_h
#define _Data_h

#include <iostream>
#include <fstream>
#include <vector>
#include "Tools.h"
#include "DataFile.h"

// Names of information in files

extern const int   DATA_LINE_LEN;
extern const char* DATA_HEADER_TXT;
extern const int   DATA_HEADER_ID;
extern const char* DATA_PRELOAD;
extern const char* DATA_RESAMPL_MODE;
extern const char* DATA_RESAMPL_SEED;
extern const char* DATA_SHUFFLE_MODE;
extern const char* DATA_PATH_PREFIX;

/*
 * Strategy
 *  - there is one funtion Rewind() and Next() which should not be overriden
 *  - they perform all the processing with preloading, shuffling, etc
 *  - the class specific processing is done in First() and Advance()
 */


class Data
{
protected:
  char *fname;
  string path_prefix;	// prefix added to all file names
  int  idim, odim;	// dimensions
  int  nb_totl;		// number of examples
    // flags
  int preload;		// 
  int resampl_mode;	// 
  int resampl_seed;	// 
  int shuffle_mode;	// 
  int norm_mode;	// evtl. perform normalization; bits: 1=substract mean, 2=devide by var.
    // data files
  vector<DataFile*>	datafile;
    // actual data
  int  idx;		// index of current example [0,nb-1]
  REAL *mem_inp;	// all the input data in memory
  REAL *mem_trg;	// all the output data in memory
    // local tools, only used when preload is activated
  void Preload();	// preload all data
  void Shuffle();	// shuffle in memory
public:
  Data(char *fname);
  Data(DataFile&);	// simplified version with one Datafile only
  ~Data();
    // access function to local variables
  char *GetFname() {return fname;}
  int GetIdim() {return idim;}
  int GetOdim() {return odim;}
  int GetNb() {return nb_totl;}
  int GetIdx() {if (idx<0) Error("DataNext() must be called before GetIdx()"); return idx;};
    // the following two pointers are only valid after first DataNext() !
  REAL *input;		// pointer to current inputs
  REAL *target;		// pointer to current target
  //REAL *GetData() {return val;}
    // main functions to access data
  void Rewind();	// rewind to first example, performs resmplaing, shuffling etc if activated
  bool Next();		// advance to next example, return FALSE if at end
};

#endif
