/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: cslm_train.cpp,v 1.21 2012/06/03 22:20:45 schwenk Exp $
 *
 * This is a simple program to perform the training of continuous space LMs
 */

using namespace std;
#include <iostream>
#include <strings.h>
#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include "Tools.h"
#include "Mach.h"
#include "MachTab.h"
#include "MachTanh.h"
#include "MachSoftmax.h"
#include "MachSeq.h"
#include "MachPar.h"
#include "TrainerNgramSlist.h"
#include "ErrFctSoftmCrossEntNgram.h"

static struct option long_options[] =
  {
    {"mach",1,0,'m'},
    {"word-list",1,0,'w'},
    {"train-data",1,0,'t'},
    {"dev-data",1,0,'d'},
    {"lm",1,0,'l'},
    {"lrate-beg",1,0,'L'},
    {"lrate-mult",1,0,'M'},
    {"weight-decay",1,0,'W'},
    {"last-iteration",1,0,'I'},
    {"block-size",1,0,'B'},
#ifdef BLAS_CUDA
    {"cuda-device",1,0,'D'},
#endif
    {0, 0, 0, 0}
  };
int option_index;

void usage (bool do_exit=true)
{
   cout <<  endl
        << "cslm_train " << cslm_version << " - a tool to train continuous space language models" << endl
	<< "Copyright (C) 2012 Holger Schwenk, University of Le Mans, France" << endl << endl;

#if 0
	<< "This library is free software; you can redistribute it and/or" << endl
	<< "modify it under the terms of the GNU General Public" << endl
	<< "License as published by the Free Software Foundation; either" << endl
	<< "version 2.1 of the License, or (at your option) any later version." << endl << endl

	<< "This library is distributed in the hope that it will be useful," << endl
	<< "but WITHOUT ANY WARRANTY; without even the implied warranty of" << endl
	<< "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU" << endl
	<< "Lesser General Public License for more details." << endl << endl

	<< "You should have received a copy of the GNU General Public" << endl
	<< "License along with this library; if not, write to the Free Software" << endl
	<< "Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA" << endl << endl
	<< "***********************************************************************" << endl << endl
	<< "Built on " << __DATE__ << endl << endl;
#endif

  cout << "Usage:" << endl;
  cout << "--mach          -m  file name of the machine" << endl;
  cout << "--word-list     -w  word list of the vocabulary and counts (used to select the most frequent words)" << endl;
  cout << "--train-data    -t  training data" << endl;
  cout << "--dev-data      -d  development data (optional)" << endl;
  cout << "--lm            -l  file name of the machine (only necessary when using short lists)" << endl;
  cout << "--lrate-beg     -L  initial learning rate (default 5E-03)" << endl;
  cout << "--lrate-mult    -M  learning rate multiplier for exponential decrease (default 7E-08)" << endl;
  cout << "--weight-decay  -W  coefficient of weight decay (default 3E-05)" << endl;
  cout << "--curr-iter     -C  current iteration when continuing training of a neural network (default 0)" << endl;
  cout << "--last-iter     -I  last iteration of neural network (default 10)" << endl;
  cout << "--block-size    -B  block size for faster training (default 128)" << endl;
#ifdef BLAS_CUDA
  cout << "--cuda-device   -D  select CUDA device (default 0)" << endl;
#endif

  if (do_exit) exit(1);
}


int main (int argc, char *argv[])
{
    // parse parameters
  char *mach_fname=NULL, *train_fname=NULL, *dev_fname=NULL, *lm_fname=NULL, *wl_fname=NULL;
  int bsize=128, last_it=10, curr_it=0;
  REAL wdecay=3e-5;
  REAL lr_beg=5e-03, lr_mult=7e-08;
  Mach *mlp;

  char c;

  while ((c=getopt_long (argc, argv, "m:w:t:d:l:b:L:M:W:I:C:B:D:",
	   long_options, &option_index)) != -1) {
    switch (c) {
    case 'm':
      mach_fname = strdup(optarg);
      break;
    case 'w':
      wl_fname = strdup(optarg);
      break;
    case 'l':
      lm_fname = strdup(optarg);
      break;
    case 't':
      train_fname = strdup(optarg);
      break;
    case 'd':
      dev_fname = strdup(optarg);
      break;
    case 'L':
      lr_beg = strtod(optarg, NULL);
      break;
    case 'M':
      lr_mult = strtod(optarg, NULL);
      break;
    case 'W':
      wdecay = strtod(optarg, NULL);
      break;
    case 'I':
      last_it = strtol(optarg, NULL, 10);
      break;
    case 'C':
      curr_it = strtol(optarg, NULL, 10);
      break;
    case 'B':
      bsize = strtol(optarg, NULL, 10);
      break;
#ifdef BLAS_CUDA
    case 'D':
      cuda_dev = strtol(optarg, NULL, 10);
      break;
#endif
    default:
      usage();
    }
  }

    // verify mandatory arguments
  if (!mach_fname) {
    usage(false);
    Error("you need to specify a machine file");
  }
  if (!train_fname) {
    usage(false);
    Error("you need to specify training data");
  }
  if (!wl_fname) {
    usage(false);
    Error("you need to specify a word list");
  }

  char sfname[16384];
  strcpy(sfname, mach_fname);

    // Check if existing machine exists
  struct stat stat_struct;
  if (stat(mach_fname, &stat_struct)==0) {
      // read existing network
    ifstream ifs;
    ifs.open(mach_fname,ios::binary);
    CHECK_FILE(ifs,mach_fname);
    mlp = Mach::Read(ifs);
    ifs.close();
    cout << "Found existing machine with " << mlp->GetNbBackw()
         << " backward passes, continuing training at iteration " << curr_it+1 << endl;
  }
  else {
    MachSeq *mseq = new MachSeq();
    MachPar *mp = new MachPar();
    MachTanh *mh;
    int idim=0, pdim, hdim;

      // check number of entries in word list
    cout << "Checking word list " << wl_fname;
    ifstream dfs_wlst;
    dfs_wlst.open(wl_fname,ios::in);
    CHECK_FILE(dfs_wlst,wl_fname);
    const int max_line_len=65536; // normally we just have a word and the count
    char line[max_line_len];
    while (dfs_wlst.getline(line,max_line_len)) {
      char word[max_word_len];
      int  cnt;
      if (sscanf(line,"%s %d", word, &cnt) != 2) {
        sprintf(line, "There seems to be a format error in line %d of the word list\n", idim);
        Error(line);
      }
      idim++;
    }
    dfs_wlst.close();
    cout << ": found " << idim << " entries. Using this value +1 for the dimension of the input layers" << endl;
    idim++;  // SRI getIndex() retruns values 1..nvoc

      // parse machine specification
    if (strstr(sfname,".mach")==NULL)
      Error("parsing the machine specification: missing '.mach'");

    char *ptr=sfname, *cptr, *pptr, *hptr;
    cout << "Creating a new machine" << endl;
    if ((cptr=strstr(ptr,"-c"))==NULL)
      Error("parsing the machine specification: missing context size");
    if ((pptr=strstr(cptr+2,"-p"))==NULL)
      Error("parsing the machine specification: missing projection layer");
    *pptr=0;
    int ctxt_size=atoi(cptr+2);
    if (ctxt_size<1) Error("context size must be greater then zero");
    cout << " - using a context of " << ctxt_size << " words" << endl;
    
    if ((hptr=strstr(pptr+2,"-h"))==NULL)
      Error("parsing the machine specification: missing hidden layer");
    *hptr=0;
    pdim=atoi(pptr+2);
    cout << " - using a projection layer of size " << pdim << endl;

      // create projection layer
    MachTab *mt = new MachTab(idim,pdim,bsize);
    mt->TableRandom(0.1); mp->MachAdd(mt);
    REAL *tab_adr=mt->GetTabAdr();
    for (int i=1; i<ctxt_size; i++) {
      mt = new MachTab(tab_adr,idim,pdim,bsize);
      mp->MachAdd(mt);
    }
    mseq->MachAdd(mp);

      // check for multiple hidden layers
    pptr=hptr;
    pdim=ctxt_size*pdim;
    while ((hptr=strstr(pptr+2,"-h"))!=NULL) {
      *hptr=0;
      hdim=atoi(pptr+2);
      cout << " - using a hidden layer of size " << hdim << endl;
      mh = new MachTanh(pdim,hdim,bsize);
      mh->WeightsRandom(0.1); mh->BiasRandom(0.1);
      mseq->MachAdd(mh);
      pptr=hptr; pdim=hdim;
    }

    if ((hptr=strstr(pptr+2,"-s"))==NULL)
      Error("parsing the machine specification: missing output layer");
    *hptr=0;
    hdim=atoi(pptr+2);
    cout << " - using a hidden layer of size " << hdim << endl;

      // add final hidden layer
    mh = new MachTanh(pdim,hdim,bsize);
    mh->WeightsRandom(0.1); mh->BiasRandom(0.1);
    mseq->MachAdd(mh);
    pdim=hdim;

    if ((cptr=strstr(hptr+2,".mach"))==NULL)
      Error("parsing the machine specification: didn't find .mach after layer specification");
    *cptr=0;
    hdim=atoi(hptr+2);
    cout << " - using an output layer of size " << hdim << endl;

      // add output layer
    MachSoftmax *mo = new MachSoftmax(pdim,hdim,bsize);
    mo->WeightsRandom(0.1); mo->BiasRandom(0.1);
    mseq->MachAdd(mo);

    mlp=mseq;
  }

  mlp->Info();

  ErrFctSoftmCrossEntNgram errfct(*mlp);
  Trainer *trainer;
  if (lm_fname) 
    trainer = new TrainerNgramSlist(mlp, &errfct, train_fname, dev_fname, wl_fname, lm_fname, lr_beg, lr_mult, wdecay, last_it, curr_it);
  else
    trainer = new TrainerNgram(mlp, &errfct, train_fname, dev_fname, lr_beg, lr_mult, wdecay, last_it, curr_it);
  //cout << "Initial perplexity: " << trainer.TestDev() << endl;

  strcpy(sfname,mach_fname);
  char *p=strstr(sfname, ".mach");
  if (p) { *p=0; strcat(sfname,".best.mach"); }
  trainer->TrainAndTest(sfname);

    // save machine at the end
  cout << " - saving final machine into file '" << mach_fname << "'" << endl;
  ofstream fs;
  fs.open(mach_fname,ios::binary);
  CHECK_FILE(fs,mach_fname);
  mlp->Write(fs);
  fs.close();

  if (mach_fname) free(mach_fname);
  if (wl_fname) free(wl_fname);
  if (train_fname) free(train_fname);
  if (dev_fname) free(dev_fname);
  if (lm_fname) free(lm_fname);

  if (mlp) delete mlp;
  if (trainer) delete trainer;

  return 0;
}
