/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: nbest_cmd.cpp,v 1.13 2012/06/03 22:38:11 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <fstream>
#include <getopt.h>

#include "NBest.h"
#include "NbestLMSRI.h"
#include "NbestCSLM.h"

#define DUMMY_MACHINE
#ifdef DUMMY_MACHINE
 #include "Mach.h"
 #include "MachTab.h"
 #include "MachTanh.h"
 #include "MachSoftmax.h"
 #include "MachSeq.h"
 #include "MachPar.h"
#endif

static struct option long_options[] =
  {
    {"input-file",1,0,'i'},
    {"inn",1,0,'I'},
    {"output-file",1,0,'o'},
    {"outn",1,0,'O'},
    {"offs",1,0,'a'},
    {"lm",1,0,'l'},
    {"order",1,0,'L'},
    {"cslm",1,0,'c'},
    {"weights",1,0,'w'},
    {"recalc",0,0,'r'},
    {"sort",0,0,'s'},
    {"lexical",0,0,'h'},
    {0, 0, 0, 0}
  };
int option_index;

void usage (bool do_exit=true)
{
   cout <<  "NBest " << cslm_version << " - A tool to process Moses n-best lists" << endl
	<< "Copyright (C) 2012 Holger Schwenk, University of Le Mans, France" << endl << endl;

#if 0
	<< "This library is free software; you can redistribute it and/or" << endl
	<< "modify it under the terms of the GNU General Public" << endl
	<< "License as published by the Free Software Foundation; either" << endl
	<< "version 2.1 of the License, or (at your option) any later version." << endl << endl

	<< "This library is distributed in the hope that it will be useful," << endl
	<< "but WITHOUT ANY WARRANTY; without even the implied warranty of" << endl
	<< "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU" << endl
	<< "Lesser General Public License for more details." << endl << endl

	<< "You should have received a copy of the GNU General Public" << endl
	<< "License along with this library; if not, write to the Free Software" << endl
	<< "Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA" << endl << endl
	<< "***********************************************************************" << endl << endl
	<< "Built on " << __DATE__ << endl << endl;
#endif

  cout << "--input-file   -i  file name of the input n-best list" << endl;
  cout << "--inn          -I  number of hypothesis to read per n-best (default all)" << endl;
  cout << "--output-file  -o  file name of the output n-best list" << endl;
  cout << "--outn         -O  number of hypothesis to write per n-best (default all)" << endl;
  cout << "--offs         -a  add offset to n-best ID (useful for seperately generated n-bests)" << endl;
  cout << "--lm           -l  rescore with a SRILM" << endl;
  cout << "--order        -L  order of the SRILM (default 4)" << endl;
  cout << "--cslm         -c  rescore with a CSLM" << endl;
  cout << "--vocab        -v  word-list to use with the CSLM" << endl;
  cout << "--lm-pos       -p  position of LM score (0 means to append it)" << endl;
  cout << "--recalc       -r  recalc global scores" << endl;
  cout << "--weights      -w  coefficients of the feature functions" << endl;
  cout << "--sort         -s  sort n-best list according to the global scores" << endl;
  cout << "--lexical      -d  report number of lexically different hypothesis" << endl;

  if (do_exit) exit(1);
}

int main (int argc, char *argv[]) {
 
    // parse parameters
  char *in_fname=NULL, *out_fname=NULL, *w_fname=NULL, *lm_fname=NULL, *cslm_fname=NULL, *wl_fname=NULL;
  int in_n=0, out_n=0, offs=0, lm_pos=0, lm_order=4;
  bool do_lm=false, do_cslm=false, do_calc=false, do_sort=false, do_lexical=false;
  char c;

  while ((c=getopt_long (argc, argv, "i:I:o:O:a:l:L:p:c:v:w:rsd",
	   long_options, &option_index)) != -1) {
    switch (c) {
    case 'i':
      in_fname = strdup(optarg);
      break;
    case 'I':
      in_n = strtol(optarg, NULL, 10);
      break;
    case 'o':
      out_fname = strdup(optarg);
      break;
    case 'O':
      out_n = strtol(optarg, NULL, 10);
      break;
    case 'a':
      offs = strtol(optarg, NULL, 10);
      break;
    case 'l':
      lm_fname = strdup(optarg);
      do_lm=true;
      break;
    case 'L':
      lm_order = strtol(optarg, NULL, 10);
      do_lm=true;
      break;
    case 'p':
      lm_pos = strtol(optarg, NULL, 10);
      break;
    case 'c':
      cslm_fname = strdup(optarg);
      do_cslm=true;
      break;
    case 'v':
      wl_fname = strdup(optarg);
      break;
    case 'w':
      w_fname = strdup(optarg);
      break;
    case 'r':
      do_calc = true;
      break;
    case 's':
      do_sort = true;
      break;
    case 'h':
      do_lexical = true;
      break;
    default:
      usage();
    }
  }

  if (! in_fname || !out_fname) {
    usage(false);
    Error("\ninput-file and output files are required");
  }

    // read input
  cout <<  "NBest " << cslm_version << " - A tool to process Moses n-best lists" << endl
       << "Copyright (C) 2012 Holger Schwenk, University of Le Mans, France" << endl << endl;
  cout << " - reading input from file '" << in_fname << "'";
  if (in_n>0) cout << " (limited to the first " << in_n << " hypothesis)";
  cout << endl;
  inputfilestream inpf(in_fname);

    // open output
  cout << " - writing output to file '" << out_fname << "'";
  if (out_n>0) cout << " (limited to the first " << out_n << " hypothesis)";
  cout << endl;
  outputfilestream outf(out_fname);

    // shall we add an offset to the ID ?
  if (offs>0) 
    cout << " - adding offset of " << offs << " to the n-best ids" << endl;
 
    // shall we rescore with an LM ?
  NbestLMSRI lm;
  if (do_lm && !do_cslm) {
    cout << " - rescoring with a " << lm_order << "-gram LM " << lm_fname;
    if (lm_pos>0) cout << ", scores at position " << lm_pos;
             else cout << ", scores are appended";
    cout << endl;
    lm.Read(lm_fname, lm_order);
  }
 
    // shall we rescore with an CSLM ?
  NbestCSLM cslm;
  if (do_cslm) {
    if (!wl_fname)
      Error("You need to specify a word-list when rescoring with a CSLM\n");
    if (!lm_fname)
      Error("You need to specify a back-off LM when rescoring with a CSLM\n");
    cout << " - rescoring with CSLM " << cslm_fname;
    if (lm_pos>0) cout << ", scores at position " << lm_pos;
             else cout << ", scores are appended";
    cout << endl;
    cslm.Read(cslm_fname, wl_fname, lm_fname);
  }

    // eventually read weights
  Weights w;
  if (w_fname) {
    cout << " - reading weights from file '" << w_fname << "'";
    int n=w.Read(w_fname);
    cout << " (found " << n << " values)" << endl;
  }

  if (do_calc) cout << " - recalculating global scores" << endl;

    // shall we sort ?
  if (do_sort) cout << " - sorting global scores" << endl;

   // main loop
  time_t t_beg, t_end;
  time(&t_beg);
  int nb_sent=0, nb_nbest=0;
  while (!inpf.eof()) {
    NBest nbest(inpf, in_n);

    if (nbest.NbNBest()>0) {
      if (offs!=0) nbest.AddID(offs);
      if (do_calc) nbest.CalcGlobal(w);
      if (do_sort) nbest.Sort();
      if (do_lm && !do_cslm) nbest.RescoreLM(lm,lm_pos);
      if (do_cslm) nbest.RescoreLM(cslm,lm_pos);
      nbest.Write(outf, out_n);

      nb_sent++;
      nb_nbest+=nbest.NbNBest();
    }
  }
  inpf.close();
  outf.close();
  time(&t_end);
  time_t dur=t_end-t_beg;

    // display final statistics
  cout << " - processed " << nb_nbest << " n-best hypotheses in " << nb_sent << " sentences"
       << " (average " << (float) nb_nbest/nb_sent << ")" << endl;
  if (do_cslm) cslm.Stats();
  cout << " - total time: " << dur/60 << "m" << dur%60 << "s" << endl;

  if (in_fname) free(in_fname);
  if (out_fname) free(out_fname);
  if (w_fname) free(w_fname);
  if (lm_fname) free(lm_fname);
  if (cslm_fname) free(cslm_fname);
  if (wl_fname) free(wl_fname);
  
  return 0;
}
