/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataNgramBin.cpp,v 1.20 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

// system headers
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "Tools.h"
#include "Data.h"
#include "DataNgramBin.h"

const char* DATA_FILE_NGRAMBIN="DataNgramBin";
const int DATA_NGRAM_IGN_SHORT=1;		// ignore uncomplete n-grams 
					// of this options is not set, wholes will be filled with NULL_WORD
					// in order to simulate shorter n-grams
const int DATA_NGRAM_IGN_UNK=2;		// ignore n-grams with <UNK> at last position
const int DATA_NGRAM_IGN_UNKall=4;	// ignore n-grams that contain <UNK> anywhere
const int DATA_NGRAM_IGN_EOS=8;		// TODO: not implemented
const int DATA_NGRAM_IGN_ALL=15;


//*******************

void DataNgramBin::do_constructor_work()
{
    // parse header binary Ngram file
  fd=open(fname, O_RDONLY);
  if (fd<0) {
    perror(fname); Error();
  }
  read(fd, &nbl, sizeof(int));
  read(fd, &nbex, sizeof(int));
  read(fd, &vocsize, sizeof(int));
  int s;
  read(fd, &s, sizeof(int));
  if (s != sizeof(WordID)) {
    fprintf(stderr,"binary n-gram data uses %d bytes per index, but this code is compiled for %d byte indices\n", s, (int) sizeof(WordID));
    Error();
  }
  read(fd, &bos, sizeof(WordID));
  read(fd, &eos, sizeof(WordID));
  read(fd, &unk, sizeof(WordID));
  printf(" - %s binary ngram file with %d words in %d lines, order=%d, mode=%d (bos=%d, eos=%d, unk=%d)\n", fname, nbex, nbl, order, mode, bos, eos, unk);

  idim=order-1;
  odim=1;
 
  if (idim>0) {
    input = new REAL[idim];
    wid = new WordID[order];
    for (int i=0; i<order; i++) wid[i]=bos;
  }
  target_vect = new REAL[odim];

    // counting nbex to get true number of examples
  cout << "    counting ..."; cout.flush();
  time_t t_beg, t_end;
  time(&t_beg);

  int n=0;
  nbs=nbw=nbu=nbi=0;
  while (DataNgramBin::Next()) n++;

  time(&t_end);
  time_t dur=t_end-t_beg;
  printf(" %d %d-grams (%lum%lus, %d unk, %d ignored)\n", n, order, dur/60, dur%60, nbu, nbi);

  if (n>nbex+nbl)
    Error("Number of counted examples is larger than the information in file header !?");
  nbex=n;  // 
}

//*******************

DataNgramBin::DataNgramBin(ifstream &ifs) : DataFile::DataFile(ifs),
  order(0), mode(0), nbw(0), nbs(0), nbu(0), nbi(0)
{
    // DataNgramBin <file_name> <resampl_coeff> <order> [flags]
    // parse addtl params
  ifs >> order >> mode;
  if (order<2 || order>9)
    Error("order must be in [2,9]\n");
  if (mode<0 || mode>DATA_NGRAM_IGN_ALL)
    Error("wrong value of DataNgramBin mode\n");

  do_constructor_work();
}

//*******************

DataNgramBin::DataNgramBin(char *p_fname, float p_rcoeff, int p_order, int p_mode)
  : DataFile::DataFile(p_fname, p_rcoeff),
  order(p_order), mode(p_mode), nbw(0), nbs(0), nbu(0), nbi(0)
{

  do_constructor_work();
    // skip counting for efficieny reasons
  nbw=nbex+nbl; 	// this should be an upper bound on the number of n-grams
}

//*******************

DataNgramBin::~DataNgramBin()
{

  close(fd);
  if (idim>0) {
    delete [] wid;
    delete [] input;
  }
  delete [] target_vect;
}


//*******************

bool DataNgramBin::Next()
{
  bool ok=false;
  int i;

   // we may need to skip some n-grams in function of the flags
  while (!ok) {

      // read from file into, return if EOF
    WordID w;
    if (read(fd, &w, sizeof(w)) != sizeof(w)) return false;
//printf("read: %d\n",w);
  
      // shift previous order
    for (i=1; i<order; i++) wid[i-1]=wid[i];
    wid[order-1]=w;
//printf(" wid: %d %d %d\n",wid[0],wid[1],wid[2]);

     // update statistics
    if (w == bos) ; /* nothing to count */
    else if (w == eos) nbs++;
    else if (w == unk) nbu++;
    else nbw++;

     // check if n-gram is valid according to the selected mode

    if (w == bos) {
        // new BOS, initialize the whole order to NULL_WORD
        // and terminate with BOS (it will be shifted away) 
      for (i=0; i<order-1; i++) wid[i] =  NULL_WORD;
      wid[i]=bos;
//printf("skip [new bos]\n");
      continue;
    }

    if (mode & DATA_NGRAM_IGN_UNK) {
        // ignore n-grams with <UNK> at last position
      if (w == unk) {
        nbi++;
//printf("skip [predict unk]\n");
        continue;
      }
    }

    if (mode & DATA_NGRAM_IGN_UNKall) {
        // ignore n-grams that contain <UNK> anywhere
      for (i=0; i<order-1; i++) {
        if (wid[i] == unk) {
          nbi++;
//printf("skip [any unk]\n");
          break;
        }
      }
      if (i < order-1) continue;
    }

    if (mode & DATA_NGRAM_IGN_SHORT) {
        // ignore n-grams that contain NULL_WORD elsewhere than at 1st position
      for (i=0; i<order; i++)
        if (wid[i] == NULL_WORD) {
          nbi++;
//printf("skip [bos]\n");
          break;
      }
      if (i < order) continue;
    }

      /* standard mode */
    ok=true;
  } // of while (!ok)

//printf("keep: %d %d %d -> %d\n",wid[0],wid[1],wid[2],wid[3]);
  for (i=0; i<order-1; i++) input[i] = (REAL) wid[i]; 	// careful: we cast to float which may give
  target_vect[0] = (int) wid[i];				// rounding problems of the integers
  target_id = (int) wid[i];

  idx++;
  return true;
}

/********************
 *
 ********************/


int DataNgramBin::Info()
{
  return DataFile::Info();
  //int nbr=resampl_coeff*nbex;
  //printf(" - %s  %6.4f * %9d = %9d [ngram order=%d, mode=%d, unk=%d, bos=%d, eos=%d]\n", fname, resampl_coeff, nbex, nbr, order, mode, unk, bos, eos);
  //return nbr;
}

void DataNgramBin::Rewind()
{
  lseek(fd, sizeof(nbl)+sizeof(nbex)+sizeof(vocsize)+sizeof(int)+3*sizeof(WordID), SEEK_SET);
  idx=-1;
}
  
