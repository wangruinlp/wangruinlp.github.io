/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachSoftmax.cpp,v 1.27 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <math.h>
//extern double drand48();

#include "Tools.h"
#include "MachSoftmax.h"
#include "Blas.h"
#ifdef BLAS_CUDA
# include "Gpu.cuh"
#endif


MachSoftmax::MachSoftmax(const int p_idim, const int p_odim, const int p_bsize, const int p_nbfw, const int p_nbbw)
 : MachLin(p_idim, p_odim, p_bsize, p_nbfw, p_nbbw)
{
#if defined(BLAS_CUDA) && defined(BLAS_CUDA_NPPS_SUM)
  int nbytes=0;
  nppsSumGetBufferSize_32f(odim, &nbytes);
  gpu_sum_buf = nppsMalloc_8u(nbytes);
#endif
}

MachSoftmax::~MachSoftmax()
{
#if defined(BLAS_CUDA) && defined(BLAS_CUDA_NPPS_SUM)
  if (gpu_sum_buf) nppsFree(gpu_sum_buf);
#endif
}

//-----------------------------------------------
// Tools
//-----------------------------------------------

void MachSoftmax::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << "Information on softmax machine" << endl;
    MachLin::Info(detailed);
  }
  else {
    printf("%sMachSoftmax %d-%d, bs=%d, passes=%d/%d", txt,idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
    tmn.disp(" + norm: ");
#endif
    printf("\n");
  }
}

//-----------------------------------------------
// Training
//-----------------------------------------------

void MachSoftmax::Forw(int eff_bsize)
{

  if (eff_bsize<=0) eff_bsize=bsize;
  MachLin::Forw(eff_bsize);

#ifdef PROFILE
  tmn.start();
#endif

    // softmax normalization
#ifdef BLAS_CUDA
  GpuMachSoftmaxForw(bsize,odim,data_out);
#else
  REAL *optr, sum;
  int b=eff_bsize*odim;
     // apply exp() on all outputs
  VEXP(&b,data_out);
  for (b=0,optr=data_out; b<eff_bsize; b++,optr+=odim) {
    sum=1.0/ASUM(&odim,optr,&inc1);  // exp(x) is always positive -> we can use the sum_i (ABS(x_i))
    SCAL(&odim,&sum,optr,&inc1);
  }
#endif

#ifdef PROFILE
  tmn.stop();
#endif


}

void MachSoftmax::Backw(const float lrate, const float wdecay, int eff_bsize)
{
    // derivate softmax activation function
    //   do_i / da_k = o_i (kronecker_ik - o_k)
    // we suppose that do_i/da_k vanishes in the error function !!
    //             = o_i (1 - o_i)

   // this can't be done here since the result depends
   // on the error function (we must derivate each output w/r
   // to ALL other outputs. This can't be stored in one vector)
   //   dE/da_i = sum_k dE/do_k do_k/da_i
   // On the other hand, many terms vanish with usual error functions

  MachLin::Backw(lrate, wdecay, eff_bsize);
}

