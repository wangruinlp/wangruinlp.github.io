/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachSoftmax.h,v 1.12 2012/06/02 13:24:16 schwenk Exp $
 *
 * softmax machine:  a_i = exp(a_i) / sum_k a_k
 * with a_k is the kth output of a linear machine
 */

#ifndef _MachSoftmax_h
#define _MachSoftmax_h

#include "MachLin.h"

#undef BLAS_CUDA_NPPS_SUM	// thsi should be faster, but I can't get it working

class MachSoftmax : public MachLin
{
private:
#ifdef PROFILE
  Timer tmn;				// cumulated time used for softmax normalization
#endif
#if defined(BLAS_CUDA) && defined(BLAS_CUDA_NPPS_SUM)
  Npp8u *gpu_sum_buf;			// temporary buffer for fast sum with nppsSum_32f()
#endif
public:
  MachSoftmax(const int=0, const int=0, const int=1, const int=0, const int=0);	
  virtual ~MachSoftmax();
  virtual int GetMType() {return file_header_mtype_softmax;};	// get type of machine
  virtual void Info(bool=false, char *txt=(char*)"");	// display (detailed) information on machine
  virtual void Forw(int=0);	// calculate outputs for current inputs
    // backprop gradients from output to input and update all weights
  virtual void Backw (const float lrate, const float wdecay, int=0);
};

#endif
