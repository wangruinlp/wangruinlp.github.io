/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataAsciiClass.cpp,v 1.2 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>

#include "Tools.h"
#include "Data.h"
#include "DataAsciiClass.h"

const char* DATA_FILE_ASCIICLASS="DataAsciiClass";

DataAsciiClass::DataAsciiClass(ifstream &ifs) : DataAscii::DataAscii(ifs)
{

  ifs >> tgt0 >> tgt1;
  printf("   targets %5.2f/%5.2f\n", tgt0, tgt1);
}


/**************************
 *  
 **************************/

bool DataAsciiClass::Next()
{
  char line[DATA_LINE_LEN];
  dfs.getline(line, DATA_LINE_LEN);
  if (dfs.eof()) return false;
          else idx++;

    // parse input data
  char *lptr=line;
//cout << "\nLINE: " << line << endl;
  for (int i=0; i<idim; i++) {
//cout << "parse:" <<lptr<<"; ";
    while (*lptr==' ' || *lptr=='\t') lptr++;
    if (!*lptr) {
      sprintf(line, "incomplete input in ASCII datafile, field %d", i);
      Error(line);
    }
    if (sscanf(lptr, "%f", input+i)!=1) Error("parsing source in ASCII datafile");
//cout << "got i[" <<i << "] " << input[i] << endl;
    while (*lptr!=' ' && *lptr!='\t' && *lptr!=0) lptr++;
  }

  if (odim<=0) return true;

    // parse target data
  while (*lptr==' ' || *lptr=='\t') lptr++;
  if (!*lptr) Error("unable to parse target id in ASCII datafile");
  if (sscanf(lptr, "%d", &target_id)!=1) Error("parsing target in ASCII datafile");
  for (int t=0; t<odim; t++) target_vect[t]=tgt0;
  target_vect[target_id]=tgt1;

  return true;
}

