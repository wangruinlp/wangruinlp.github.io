/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: DataAscii.h,v 1.5 2012/06/02 13:24:16 schwenk Exp $
 */

#ifndef _DataAscii_h
#define _DataAscii_h

#include <iostream>
#include <fstream>

#include "DataFile.h"

extern const char* DATA_FILE_ASCII;

class DataAscii : public DataFile
{
protected:
  ifstream dfs;
public:
  DataAscii(ifstream &ifs);
  virtual ~DataAscii();
  virtual void Rewind();
  virtual bool Next();
};

#endif
