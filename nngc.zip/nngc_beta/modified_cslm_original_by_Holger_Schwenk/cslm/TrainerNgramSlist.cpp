/*
* This file is part of the continuous space language model toolkit for large
* vocabulary speech recognition and statistical machine translation.
*
* Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
*
* The CSLM toolkit is free software; you can redistribute it and/or modify it
* under the terms of the GNU General Public License version 3 as
* published by the Free Software Foundation
*
* This library is distributed /in the hope that it will be useful, but WITHOUT
* ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
* FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
* for more details.
*
* You should have received a copy of the GNU General Public License
* along with this library; if not, write to the Free Software Foundation,
* Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*
* $Id: TrainerNgramSlist.cpp,v 1.44 2012/06/03 22:14:44 schwenk Exp $
*/

using namespace std;
#include <iostream>
#include <algorithm>
#include <unistd.h>
#include <time.h>

#include "Tools.h"
#include "Mach.h"
#include "TrainerNgramSlist.h"

#undef CSLM_DOES_SHORT_NGRAMS

bool wlist_comp(const struct WList &p, const struct WList &q) {
	return p.n > q.n;
}

void TrainerNgramSlist::DoConstructorWork() {
	// read word list
	cout << " - reading word list from file " << wlist_fname;
	cout.flush();
	ifstream dfs_wlst;
	dfs_wlst.open(wlist_fname,ios::in);
	CHECK_FILE(dfs_wlst,wlist_fname);
	while (!dfs_wlst.eof()) {
		static char buf[max_word_len];
		WList wlist_el;
		//dfs_wlst.getline(buf,DATA_LINE_LEN);
		//sscanf(buf, "%s %d", wlist_el.word, &wlist_el.n);
		dfs_wlst >> buf >> wlist_el.n;
		wlist_el.word=strdup(buf);
		wlist_el.id = wlist.size();
		// cout << "read " << wlist_el.word << ", n=" << wlist_el.n << endl;
		wlist.push_back(wlist_el);
	}
	dfs_wlst.close();

	WordID voc_size = wlist.size();
	cout << ", got " << voc_size << " words" << endl;
	vector<WList>::iterator i;

	// sort word list w/r to word frequency
	sort(wlist.begin(), wlist.end(), wlist_comp); 
	WordID sum_sl=0, sum=0;
	for (i=wlist.begin(); i!=wlist.begin()+slist_len; i++) sum += (*i).n;
	for (sum_sl=sum; i!=wlist.end(); i++) sum += (*i).n;
	printf (" - setting up short list of %d words, coverage of %5.2f%%\n", slist_len, 100.0*sum_sl/sum);


	//cout << "Words in slist:" << endl;
	//for (i=wlist.begin(); i!=wlist.begin()+slist_len; i++)
	//printf (" %s cnt=%d idx=%d\n", (*i).word, (*i).n, (*i).id);



	//cout << "Words not in slist:" << endl;
	//for (i=wlist.begin()+slist_len; i!=wlist.end(); i++)
	//printf (" %s cnt=%d idx=%d\n", (*i).word, (*i).n, (*i).id);


	// set up mapping from wlist indices to CSLM indices
	map_wl2cslm.reserve(voc_size);
	map_wl2cslm.resize(voc_size);
	for (i=wlist.begin(); i!=wlist.end(); i++) map_wl2cslm[(*i).id] = i-wlist.begin();

	//printf("this time this is to show it run\n");
	vector<WordID>::iterator j;
	//cout << "map_wl2cslm:" << endl;
	//for (j=map_wl2cslm.begin(); j<map_wl2cslm.end(); j++)
	//printf (" %d", (*j));

#ifdef DEBUG2
	// just needed for debugging
	words.reserve(voc_size);
	words.resize(voc_size);
	for (i=wlist.begin(); i!=wlist.end(); i++) words[(*i).id] = strdup((*i).word);
#endif
	printf("this is to show it run\n");
	// load back-off LM and set up vocab mapping
	// the maximum order of the back-off LM is the context size of CSLM + 1
#ifdef LM_SRI // TODO: should be generic
	printf("this is to show it sun\n");
	printf("%d\n",idim);
	blm = new BackoffLmSri(lm_fname,idim+1,wlist);
#endif

	BlockSetMax();  // allocate req

}

//
//
//

TrainerNgramSlist::TrainerNgramSlist (Mach *pmach, ErrFct *perrfct,
									  char *train_fname, char *dev_fname,
									  char *p_wlist_fname, char *p_lm_fname,
									  REAL p_lr_beg, REAL p_lr_mult, REAL p_wd,
									  int p_maxep, int p_ep)
									  : TrainerNgram(pmach,perrfct,train_fname,dev_fname,p_lr_beg,p_lr_mult,p_wd,p_maxep,p_ep),
									  nb_ex_slist(0), nb_ex_short(0), wlist_fname(strdup(p_wlist_fname)),
									  lm_fname(strdup(p_lm_fname)), lm_buf_target(new WordID[odim*bsize]),
									  slist_len(mach->GetOdim()-1), blm(NULL), max_req(0), nreq(0), req(NULL), nb_ngram(0), nb_forw(0)
{
	cout << "Setting up training with short list" << endl;
	DoConstructorWork();
}

//
//
//

TrainerNgramSlist::TrainerNgramSlist (Mach *pmach, ErrFct *perrfct,
									  Data &data, char *p_wlist_fname, char *p_lm_fname)
									  : TrainerNgram(pmach,perrfct,data),
									  nb_ex_slist(0), nb_ex_short(0), wlist_fname(strdup(p_wlist_fname)),
									  lm_fname(strdup(p_lm_fname)), lm_buf_target(new WordID[odim*bsize]),
									  slist_len(mach->GetOdim()-1), blm(NULL), max_req(0), nreq(0), req(NULL), nb_ngram(0), nb_forw(0)
{
	cout << "Setting up testing with short list" << endl;
	DoConstructorWork();
}

TrainerNgramSlist::TrainerNgramSlist (Mach *pmach, char *p_wlist_fname, char *p_lm_fname)
	: TrainerNgram(pmach,NULL,NULL),
	nb_ex_slist(0), nb_ex_short(0), wlist_fname(strdup(p_wlist_fname)),
	lm_fname(strdup(p_lm_fname)), lm_buf_target(new WordID[odim*bsize]),
	slist_len(mach->GetOdim()-1), blm(NULL), max_req(0), nreq(0), req(NULL), nb_ngram(0), nb_forw(0)
{
	cout << "Setting up CSLM with short list" << endl;
	DoConstructorWork();
}

void TrainerNgramSlist::FreeReq()
{
	if (req) {
		for (int i=0; i<nreq; i++) free(req[i].ctxt);
	}
	nreq=0;
}
//**************************************************************************************

TrainerNgramSlist::~TrainerNgramSlist ()
{ 

	if (wlist_fname) free(wlist_fname);
	if (lm_fname) free(lm_fname);
	delete [] lm_buf_target;

	if (blm) delete blm;

	map_wl2cslm.clear();

	for (vector<WList>::iterator i=wlist.begin(); i!=wlist.end(); i++) free((*i).word);
	wlist.clear();

#ifdef DEBUG2
	words.clear();
	// TODO: for (i=wlist.begin(); i!=wlist.end(); i++) words[(*i).id] = strdup((*i).word);
#endif

	FreeReq();
	if (req) delete req;
}


//**************************************************************************************
// special version for GPU cards that load all examples on the card 
// and than runs a whole epoch without explicit data transfer

#ifdef BLAS_CUDA_NEW
REAL TrainerNgramSlist::Train()
{
	if (!data_train) return -1;
#ifdef DEBUG
	printf("*****************\n");
	printf("TrainerNgramSlist::Train() on GPU:\n");
	printf(" -  data_in: %p \n", (void*) buf_input);
	printf(" -   target: %p \n", (void*) buf_target);
	printf(" -  tgt WID: %p \n", (void*) buf_target_wid);
	printf(" - grad_out: %p \n", (void*) errfct->GetGrad());
#endif

	Timer ttrain;		// total training time
	ttrain.start();

	int n, i;
	nb_ex=nb_ex_slist=0;

	mach->SetDataIn(gpu_input);		// we copy from buf_input to gpu_input
	errfct->SetTarget(gpu_target);	// we copy from buf_target to gpu_target
	errfct->SetOutput(mach->GetDataOut());
	mach->SetGradOut(errfct->GetGrad());
	data_train->Rewind();

	// reserve memory on the GPU for all examples
	int mem_ex=data_train->GetNb();
	printf(" - allocating memory for %d examples on GPU (%.1f MBytes)\n",mem_ex,mem_ex*(idim+1)*sizeof(REAL)/1024.0/1024.0);
	REAL *gpu_input_all = cuda_alloc(mem_ex*idim, "all training data");
	REAL *gpu_target_all = cuda_alloc(mem_ex*1, "all targets");

	bool data_available;
	REAL *gpu_iptr=gpu_input_all, *gpu_tptr=gpu_target_all;
	do {
		// get a bunch of data and map all the words
		n=0;
		data_available = true;
		while (n < mach->GetBsize() && data_available) {
			data_available = data_train->Next();
			if (!data_available) break;
			buf_target_wid[n] = map_wl2cslm[(WordID) data_train->target[0]];	// map target word IDs
			buf_target[n] = (REAL) buf_target_wid[n];
			if (in_slist(buf_target_wid[n]))
				nb_ex_slist++;
			else {
				buf_target[n] = (REAL) slist_len;	// words that are not in slist are ALL done by the last output neuron
				buf_target_wid[n] = slist_len;
			}

			if (buf_target_wid[n]<0 || buf_target_wid[n]>=odim) {
				fprintf(stderr,"TrainerNgramSlist::Train(): target out of bounds (%d) must be in [0,%d[\n",buf_target_wid[n],odim);
				Error();
			}

			for (i=0; i<idim; i++) {
				WordID inp=(WordID) data_train->input[i];
				if (inp == NULL_WORD)
					Error("TrainerNgramSlist::Train(): found null word\n");
				if (inp<0 || inp>=(int)map_wl2cslm.size()) {
					fprintf(stderr,"TrainerNgramSlist::Train(): input out of bounds (%d), must be in [0,%d[\n", inp, (int) map_wl2cslm.size());
					Error();
				}
				buf_input[n*idim + i] = (REAL) map_wl2cslm[inp];	// map context words IDs
			}
			n++;
		}

		if (nb_ex+n > mem_ex) {
			fprintf(stderr, "trying to load %d examples, but memory was reserved for %d examples only\n", nb_ex, mem_ex);
			Error("");
		}

		if (n>0) {
			cudaMemcpy(gpu_iptr, buf_input , n*idim*sizeof(REAL), cudaMemcpyHostToDevice);
			cudaMemcpy(gpu_tptr, buf_target , n*1*sizeof(REAL), cudaMemcpyHostToDevice);
			gpu_iptr += n*idim;
			gpu_tptr += n*1;
		}

		nb_ex += n;
	} while (data_available);

	printf(" - training on %d examples on GPU\n", nb_ex);

#ifdef PROFILE
	Timer tgrad;		// profiling: time to calculate gradients
#endif

	gpu_iptr = gpu_input_all;
	gpu_tptr = gpu_target_all;
	errfct->InitGradCumul();
	n=0;
	while (n<nb_ex) {
		int b = nb_ex-n;
		if (b>bsize) b=bsize;
		mach->SetDataIn(gpu_iptr);
		errfct->SetTarget(gpu_tptr);

		mach->Forw(b); 
		tgrad.start();
		errfct->CalcGradCumul(b);
		tgrad.stop();
		mach->Backw(lrate, wdecay, b); 

		n += b;
		gpu_iptr += b*idim;
		gpu_tptr += b*1;
	} 

	cublasFree (gpu_input_all); 
	cublasFree (gpu_target_all); 

	ttrain.stop();
	ttrain.disp(" - training time: ");
#ifdef PROFILE
	tgrad.disp(", grad: ");
#endif
	printf("\n");

	REAL log_sum = errfct->GetGradCumul();
	if (nb_ex>0) return exp(-log_sum / (REAL) nb_ex);  // return perplexity

	return -1;
}
#endif

//**************************************************************************************

#if 1
REAL TrainerNgramSlist::Train()
{
	if (!data_train) return -1;
#ifdef DEBUG
	printf("*****************\n");
	printf("TrainerNgramSlist::Train():\n");
	printf(" -  data_in: %p \n", (void*) buf_input);
	printf(" -   target: %p \n", (void*) buf_target);
	printf(" -  tgt WID: %p \n", (void*) buf_target_wid);
	printf(" - grad_out: %p \n", (void*) errfct->GetGrad());
#endif
	data_train->Rewind();
	Timer ttrain;		// total training time
	ttrain.start();
#ifdef PROFILE
	Timer tgrad;		// profiling: time to calculate gradients
#endif

	REAL log_sum=0;
	int i;
	nb_ex=nb_ex_slist=0;

#ifdef BLAS_CUDA
	mach->SetDataIn(gpu_input);		// we copy from buf_input to gpu_input
	errfct->SetTarget(gpu_target);	// we copy from buf_target to gpu_target
#else
	mach->SetDataIn(buf_input);
	errfct->SetTarget(buf_target);
#endif
	errfct->SetOutput(mach->GetDataOut());
	mach->SetGradOut(errfct->GetGrad());

	bool data_available;
	do {
		// get a bunch of data and map all the words
		int n=0;
		data_available = true;
		while (n < mach->GetBsize() && data_available) {
			data_available = data_train->Next();
			if (!data_available) break;
			buf_target_wid[n] = map_wl2cslm[(WordID) data_train->target[0]];	// map target word IDs
			buf_target[n] = (REAL) buf_target_wid[n];
			if (in_slist(buf_target_wid[n]))
				nb_ex_slist++;
			else {
				buf_target[n] = (REAL) slist_len;	// words that are not in slist are ALL done by the last output neuron
				buf_target_wid[n] = slist_len;
			}

			if (buf_target_wid[n]<0 || buf_target_wid[n]>=odim) {
				fprintf(stderr,"TrainerNgramSlist::Train(): target out of bounds (%d) must be in [0,%d[\n",buf_target_wid[n],odim);
				Error();
			}

			for (i=0; i<idim; i++) {
				WordID inp=(WordID) data_train->input[i];
				if (inp == NULL_WORD)
					Error("TrainerNgramSlist::Train(): found null word\n");
				if (inp<0 || inp>=(int)map_wl2cslm.size()) {
					fprintf(stderr,"TrainerNgramSlist::Train(): input out of bounds (%d), must be in [0,%d[\n", inp, (int) map_wl2cslm.size());
					Error();
				}
				buf_input[n*idim + i] = (REAL) map_wl2cslm[inp];	// map context words IDs
			}
#ifdef DEBUG
			printf("Data n=%d\n",n);
			printf("Input: "); for (i=0; i<idim; i++) printf(" %d", (int) data_train->input[i]); printf(" -> %d\n", (int) data_train->target[0]);
			printf("Mapped:"); for (i=0; i<idim; i++) printf(" %d", (int) buf_input[n*idim+i]); printf(" -> %d\n", (int) buf_target[n]);
#endif
			n++;
		}

		if (n>0) {
#ifdef BLAS_CUDA
			cudaMemcpy(gpu_input, buf_input , n*idim*sizeof(REAL), cudaMemcpyHostToDevice);
			cudaMemcpy(gpu_target, buf_target , n*1*sizeof(REAL), cudaMemcpyHostToDevice);
#endif
			mach->Forw(n); 
#ifdef PROFILE
			tgrad.start();
#endif
			log_sum += errfct->CalcGrad(n);
			SetLrate();
#ifdef PROFILE
			tgrad.stop();
#endif
			mach->Backw(lrate, wdecay, n); 
		}

		nb_ex += n;
		//if (nb_ex % 10000 == 0) printf("%d ex\n", nb_ex);
	} while (data_available);

	ttrain.stop();
	ttrain.disp(" - training time: ");
#ifdef PROFILE
	tgrad.disp(", grad: ");
#endif
	printf("\n");

	if (nb_ex>0) return exp(-log_sum / (REAL) nb_ex);  // return perplexity

	return -1;
}
#endif

//**************************************************************************************
// 

REAL TrainerNgramSlist::DoTestDev(char *fname, bool renorm)
{
	if (!data_dev) return -1;
	int mn=1;
	ofstream fs;
	if (fname) {
		cout << " - dumping log probability stream to file '" << fname << "'" << endl;
		fs.open(fname,ios::out);
		CHECK_FILE(fs,fname);
	}

	int nb_ex=nb_ex_slist=nb_ex_short=0;
	REAL logP, log_sum=0;
	REAL logP_file;
	REAL log_sum_cslm=0;	// only CSLM, i.e. considering all words out of slist as one prediction
	int lm_order=blm->GetOrder();

#ifdef BLAS_CUDA
	mach->SetDataIn(gpu_input);		// we copy from buf_input to gpu_input
	errfct->SetTarget(gpu_target);	// we copy from buf_target to gpu_target
#else
	mach->SetDataIn(buf_input);
	errfct->SetTarget(buf_target);
#endif
	errfct->SetOutput(mach->GetDataOut());

	bool data_available;
	data_dev->Rewind();
	do {
		// get a bunch of data
		int n=0, i;
		data_available = true;
		while (n < mach->GetBsize() && data_available)
		{
			data_available = data_dev->Next();
			//mn++;
			//printf("mn is %d",mn);
			if (!data_available) break;
			for (i=0; i<idim; i++) {
				WordID inp=(WordID) data_dev->input[i];
				if (inp==NULL_WORD) buf_input[n*idim + i] = NULL_WORD;
				else {
					if (inp<0 || inp>=(int)map_wl2cslm.size()) {
						fprintf(stderr,"TrainerNgramSlist::DoTestDev(): input out of bounds (%d), must be in [0,%d[\n", inp, (int) map_wl2cslm.size());
						Error();
					}
					buf_input[n*idim + i] = (REAL) map_wl2cslm[inp];	// map context words IDs
				}
			}

			buf_target_wid[n] = map_wl2cslm[(WordID) data_dev->target[0]];	// map target word IDsSRI LM
			lm_buf_target[n] = buf_target_wid[n];	// keep unmapped target word ID for back-off LM
			buf_target[n] = (REAL) buf_target_wid[n];
			// TODO: we actually don't need a forward pass for words in the short lists or short n-grams
			//       this could be used to save some time (5-10%)
			if (!in_slist(buf_target_wid[n])) {
				buf_target_wid[n] = slist_len;		// words that are not in slist are ALL done by the last output neuron
				buf_target[n] = (REAL) slist_len;
			}

			if (buf_target_wid[n] < 0 || buf_target_wid[n]>=odim) {
				fprintf(stderr,"TrainerNgramSlist::DoTestDev(): target out of bounds (%d) must be in [0,%d[\n",buf_target_wid[n],odim);
				Error();
			}

			//printf("Data n=%d\n",n);
			/*
			printf("  input: "); 
			for (i=0; i<idim; i++) {
			int temp = (int) data_dev->input[i];
			//printf("%s",(*(wlist.begin()+temp)).word);
			printf(" %6d", temp); 
			int temp3 = (int) data_dev->target[0];
			printf(" -> %6d\n", temp3);

			}
			printf("  mapped:"); for (i=0; i<idim; i++) {
			int temp2 = (int) buf_input[n*idim+i];
			printf(" %s", (*(wlist.begin()+temp2)).word); 
			printf(" %6d", temp2);
			printf(" -> %6d\n", (int) buf_target[n]);
			}
			*/

			n++;
		}

		// process the bunch by the neural network
		if (n>0) {
#ifdef BLAS_CUDA
			cudaMemcpy(gpu_input, buf_input , n*idim*sizeof(REAL), cudaMemcpyHostToDevice);
			cudaMemcpy(gpu_target, buf_target , n*1*sizeof(REAL), cudaMemcpyHostToDevice);
#endif
			mach->Forw(n); 
			log_sum_cslm += errfct->CalcValue(n);
		}

		// get probas from CSLM or back-off LM
#ifdef BLAS_CUDA
		cudaMemcpy(host_output, mach->GetDataOut(), n*odim*sizeof(REAL), cudaMemcpyDeviceToHost);
		REAL *optr=host_output;
#else
		REAL *optr=mach->GetDataOut();
#endif
		REAL *ptr_input = buf_input;
		printf("odim is: %d \n",odim);
		printf("idim is: %d \n",idim);
		for (int ni=0; ni<n; ni++) {

#ifdef DEBUG
			printf("n=%d: predict", ni);
			for (int ii=0; ii<idim; ii++) printf(" %d", (WordID) ptr_input[ii]);
			printf(" -> %d   ", lm_buf_target[ni]);
#endif 
			// if the current n-gram has a NULL_WORD in the first place -> find the shortest n-gram order and request it
			// DataNext() will take care to propose the next longer n-gram
#ifndef CSLM_DOES_SHORT_NGRAMS
			if ((WordID) ptr_input[0] == NULL_WORD) {
				int p;
				for (p=idim-2; p>=0 && (ptr_input[p]!=NULL_WORD); p--);
				//logP = blm->BoffLnPid(ptr_input+idim+1-lm_order, lm_buf_target[ni], idim-p+1);
				logP = blm->BoffLnPid(ptr_input+idim+1-lm_order, lm_buf_target[ni], idim-p);
				nb_ex_short++;
			}
			else
#endif
			{

				printf("mn is %d \n",mn);
				
				if (buf_target_wid[ni] == slist_len) {
				// request proba from back-off LM for words not in slist
				// the order of the back-off LM may be smaller than the one of the CSLM
				// -> this is resolved internally by the back-off class (the last words are used)
				logP = blm->BoffLnPid(ptr_input+idim+1-lm_order, lm_buf_target[ni],lm_order);
				logP_file = logP / log(10);
				//printf(" ptr_input+idim+1-lm_order-> %f\n", *(ptr_input+idim+1-lm_order));
				printf("��һ���ǣ� %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word); 
				//printf("�ڶ����ǣ� %s\n", (*(wlist.begin()+*(ptr_input+idim+2-lm_order))).word);
				//*s = (*(wlist.begin()+*(ptr_input+idim+1-lm_order+1))).word;
				//printf()
				//printf("ǰһ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order+1))).word);
				//printf("ǰһ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order+2))).word);
				//printf("ǰһ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order+3))).word);
				//printf(" lm_order-> %6d\n", lm_order);
				//printf(" lm_buf_target[ni]-> %6d\n", lm_buf_target[ni]);
				//printf(" lm_buf_target[ni]-> %6d\n", lm_buf_target[ni]);
				printf("���һ����: %s\n", (*(wlist.begin()+(int) lm_buf_target[ni])).word); 
				//printf("Ŀ����:%d %s\n",(int) buf_target_wid[ni], (*(wlist.begin()+(int) buf_target_wid[ni])).word); 
				//printf("Ŀ���һ����: %d %s\n", ((int) buf_target_wid[ni]+1), (*(wlist.begin()+(int) buf_target_wid[ni]+1)).word); 
				//printf("Ŀ���һ��������: %f\n", blm->BoffLnPid(ptr_input+idim+1-lm_order, lm_buf_target[ni]+1,lm_order)); 
				printf("The n-grams: %s %s\n",(*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word,(*(wlist.begin()+(int) lm_buf_target[ni])).word); 
				printf("n-gram output=%f\n", logP_file);
				//printf("NN slist output=%e\n", optr[buf_target_wid[ni]]);
				fs << logP / log(10) << "\t" << (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word << " "<< (*(wlist.begin()+lm_buf_target[ni])).word << endl;
				mn++;
				}
			
				else{
					if (renorm) {
						//printf("is it right: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word);
						//if (strcmp((*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word,"<s>") != 0 && strcmp((*(wlist.begin()+(int) lm_buf_target[ni])).word,"</s>") != 0){
							//if (1){
							// renormalize CSLM proba with back-off LM proba mass on the fly (this is very costly)
							REAL pmass=0.0;
							for (WordID w=0; w<slist_len; w++) pmass+=blm->BoffPid(ptr_input+idim+1-lm_order, w, lm_order);
							printf("      BLM pmass=%f\n", pmass);
							logP = log(optr[buf_target_wid[ni]] / (1.0-optr[slist_len]) * pmass);
							//logP_file = logP / log(10);
							//printf(" ptr_input+idim+1-lm_order-> %f\n", *(ptr_input+idim+1-lm_order));
							//int y =0;
							//printf("ǰһ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word); 
							printf("2-gram�� %s %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word,(*(wlist.begin()+(int) buf_target_wid[ni])).word);
							//printf("ǰһ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order+1))).word);
							printf("ǰһ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word);
							printf("��һ����: %s\n", (*(wlist.begin()+*(ptr_input+idim+2-lm_order))).word);
							//printf(" lm_order-> %6d\n", lm_order);
							//printf(" lm_buf_target[ni]-> %6d\n", lm_buf_target[ni]);
							//printf(" lm_buf_target[ni]-> %6d\n", lm_buf_target[ni]);
							printf("��һ����: %d %s\n", (int) lm_buf_target[ni], (*(wlist.begin()+(int) lm_buf_target[ni])).word); 
							//printf("������: %f",logP);
							//printf("Ŀ����:%d: %s %s %s %f \n", ((int) buf_target_wid[ni]),(*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word,(*(wlist.begin()+*(ptr_input+idim+2-lm_order))).word,(*(wlist.begin()+(int) buf_target_wid[ni])).word, log(optr[buf_target_wid[ni]] / (1.0-optr[slist_len]) * pmass)); 
							//for (WordID tempword=0; tempword<slist_len; tempword++){
							fs << logP / log(10) << "\t" << (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word << " "<< (*(wlist.begin()+lm_buf_target[ni])).word << endl;
							//printf("ȫ����: %d: %s %s %s %f \n", tempword,(*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word,(*(wlist.begin()+*(ptr_input+idim+2-lm_order))).word,(*(wlist.begin()+tempword)).word,log(optr[tempword] / (1.0-optr[slist_len]) * pmass));
							//}
							//printf("The n-grams: %s %s \n",(*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word,(*(wlist.begin()+(int) lm_buf_target[ni])).word,(*(wlist.begin()+(int) lm_buf_target[ni])).word); 
							//printf("n-gram slist output=%f\n", logP_file);
							printf("CSLM Reform output=%f\n", logP / log(10));
							mn++;
						//}
						//else{
						//	mn++;
						//}
					}
					else {
						logP = log(optr[buf_target_wid[ni]]); // no error check on indices necessary here
						printf("CSLM output=%f\n", logP_file);
						logP_file = logP / log(10);
						mn++;
					}
					//REAL logP2 = blm->BoffLnPid(ptr_input+idim+1-lm_order, lm_buf_target[ni],lm_order);
					//printf("       CSLM: logP=%e,  ngra,=%e \n", logP, logP2);
					nb_ex_slist++;
				}
			}

			//if (fname) {
			//fs << logP_file << "\t" << (*(wlist.begin()+*(ptr_input+idim+1-lm_order))).word  << " " << (*(wlist.begin()+(int) lm_buf_target[ni])).word << endl;
			//}
			log_sum += logP;
			ptr_input += idim;  // next example in bunch at input
			optr += odim;  // next example in bunch at output
			//printf("ptr_input is: %f \n",*ptr_input);
			//printf("optr is: %f \n",*optr);
			//printf("odim is: %d \n",odim);
		}

		nb_ex += n;
		printf("n is: %d \n",n);
		printf("nb_ex is: %d \n",nb_ex);
	} while (data_available);

	printf(" - %d %d-gram requests, %d=%.2f%% short n-grams, %d=%.2f%% by back-off LM, %d=%5.2f%% predicted by CSLM\n",
		nb_ex, idim+1,
		nb_ex_short, 100.0*nb_ex_short/nb_ex,
		nb_ex-nb_ex_short-nb_ex_slist, 100.0*(nb_ex-nb_ex_short-nb_ex_slist)/nb_ex,
		nb_ex_slist, 100.0*nb_ex_slist/nb_ex);


	REAL px = (nb_ex>0) ? exp(-log_sum / (REAL) nb_ex) : -1;
	printf("   cslm px=%.2f, ln_sum=%.2f, overall px=%.2f\n",
		(nb_ex_slist>0) ? exp(-log_sum_cslm / (REAL) nb_ex) : -1, log_sum, px);

	if (fname) fs.close();

	return px;
}


//**************************************************************************************
// information after finishing an epoch

void TrainerNgramSlist::InfoPost ()
{
	printf(" - epoch finished, %d examples seen in short-list (%5.2f%% of a total of %d), average CSLM perplexity: %.2f\n",
		nb_ex_slist, 100.0*nb_ex_slist/nb_ex, nb_ex, err_train);
}

//**************************************************************************************
// request one n-gram probability, usually the call will be delayed
// and processed later 

void TrainerNgramSlist::BlockEval(WordID *wid, int o, REAL*p)
{
	int cl=o-1, i;
	if (cl != idim) {
#ifdef CSLM_DOES_SHORT_NGRAMS
		cl=o-1; // use full n-gram anyway
		req[nreq].ctxt_len = cl;
		req[nreq].ctxt = new WordID[cl];
		for (i=0; i<idim-cl; i++) req[nreq].ctxt[i]=map_wl2cslm[1];  // TODO: how to get the real BOS ??
		for (int j=0; i<idim; i++, j++) req[nreq].ctxt[i]=wid[j];
		req[nreq].wpred = wid[cl];
		req[nreq].res_ptr = p;
		if (++nreq >= max_req) BlockFinish();
#else
		//fprintf(stderr,"BlockEval() dim %d differs from CSLM %d\n", cl, idim); Error("");
		nb_ex_short++;
		*p = blm->BoffLnStd(wid, wid[cl], o);
#endif
		return;
	}

	req[nreq].ctxt_len = cl;
	req[nreq].ctxt = new WordID[cl];
	for (i=0; i<cl; i++) req[nreq].ctxt[i]=wid[i];
	req[nreq].wpred = wid[cl];
	req[nreq].res_ptr = p;
	if (++nreq >= max_req) BlockFinish();
}

//**************************************************************************************
// 

int NgramReqComp(const void *v1, const void *v2)
{ NgramReq* n1=(NgramReq*) v1, *n2=(NgramReq*) v2;
for (int i=0; i<n1->ctxt_len; i++) {
	if (n1->ctxt[i] < n2->ctxt[i]) return -1;
	if (n1->ctxt[i] > n2->ctxt[i]) return 1;
}
return 0; // both are equal
}

//**************************************************************************************
// process all delayed n-gram requests

void TrainerNgramSlist::BlockFinish()
{
	if (nreq == 0) return;

	nb_ngram+=nreq;

#ifdef DEBUG
	for (int i=0; i<nreq; i++) {
		printf("buf %d: ", i); for (int c=0; c<req[i].ctxt_len; c++) printf(" %d", req[i].ctxt[c]);
		printf(" -> %d\n", req[i].wpred);
	}
#endif
	//sort(req.begin(),req.end());  // use operator < of Ngramreq
	qsort(req, nreq, sizeof(NgramReq), NgramReqComp);
#ifdef DEBUG
	for (int i=0; i<nreq; i++) {
		printf("buf %d: ", i); for (int c=0; c<req[i].ctxt_len; c++) printf(" %d", req[i].ctxt[c]);
		printf(" -> %d\n", req[i].wpred);
	}
#endif

	int n,i;

	// process first n-gram input of CSLM
	req[0].bs=0;
	for (i=0;i<idim; i++)
		buf_input[i] = (REAL) map_wl2cslm[req[0].ctxt[i]];	// map context words IDs

	// add new n-gram inputs to CSLM if context changes
	// perform forward pass if bunch is full
	// ususally we need to do several forward bunches

	int req_beg=0;	// start of current CSLM block in large request array
	int bs=0;  		// current block index in forward bunch
	for (n=1; n<nreq; n++) {
		if (NgramReqComp(req+n-1, req+n) != 0) { 
			bs++;
			if (bs >= bsize) {
				ForwAndCollect(req_beg,n-1,bs,false);
				bs=0; req_beg=n;
			}

			req[n].bs=bs;
			for (i=0;i<idim; i++)
				buf_input[bs*idim+i] = (REAL) map_wl2cslm[req[n].ctxt[i]];	// map context words IDs
		}
		else
			req[n].bs=bs;
	}
	ForwAndCollect(req_beg,nreq-1,bs+1,false);
	FreeReq();
}


//**************************************************************************************
// collect all delayed probability requests

void TrainerNgramSlist::ForwAndCollect(int req_beg, int req_end, int bs, bool renorm)
{
	if (bs<=0) return;

	nb_forw++;
#ifdef CUDA
	Error("TrainerNgramSlist::ForwAndCollect() not yet tested on GPU");
#else
	mach->SetDataIn(buf_input);
	mach->Forw(bs); //TODO
#endif

	// collect the outputs and store them at the provided addresses
	WordID mapped_bos = map_wl2cslm[1]; // TODO: who can we get the current BOS value from the data ??? 
	int lm_order=blm->GetOrder();

#ifdef BLAS_CUDA
	cudaMemcpy(host_output, mach->GetDataOut(), bs*odim*sizeof(REAL), cudaMemcpyDeviceToHost);
#endif

	for (int n=req_beg; n<=req_end; n++) {
		REAL logP=0;
		WordID tgt = req[n].wpred;
		WordID mapped_tgt = map_wl2cslm[tgt];
		int b=req[n].bs;


#ifdef BLAS_CUDA
		REAL *optr=host_output + b*odim;
#else
		REAL *optr=mach->GetDataOut() + b*odim;
#endif
		REAL *ptr_input = buf_input + b*idim;

		// if the current n-gram has a BOS elsewhere than in the first place -> find the shortest n-gram order and request it
		// DataNext() will take care to propose the next longer n-gram
		// TODO: check what happens if there more BOS and EOS are in the rest of the n-gram 

#ifndef CSLM_DOES_SHORT_NGRAMS
		if ((idim>1) && ((WordID) ptr_input[1] == mapped_bos)) {
			int p;
			Error("TrainerNgramSlist::ForwAndCollect(): <s> in the middle of an n-gram");
			for (p=idim-1; p>=1 && (ptr_input[p]!=mapped_bos); p--);
			logP = blm->BoffLnPid(ptr_input+idim+1-lm_order, tgt, idim-p+1);
			//printf(" short %d-gram LM: logP=%e\n", idim-p+1, logP);
		}
		else
#endif
		{

			if (!in_slist(mapped_tgt)) {
				// request proba from back-off LM for words not in slist
				// the order of the back-off LM may be smaller than the one of the CSLM
				// -> this is resolved internally by the back-off class (the last words are used)
				logP = blm->BoffLnPid(ptr_input+idim+1-lm_order, mapped_tgt, lm_order); // TODO target mapped forth an back
			}
			else {
				// get proba from CSLM
				if (renorm) {
					// renormalize CSLM proba with back-off LM proba mass on the fly (this is very costly)
					REAL pmass=0.0;
					for (WordID w=0; w<slist_len; w++) pmass+=blm->BoffPid(ptr_input+idim+1-lm_order, w, lm_order);
					//printf("      BLM pmass=%e\n", pmass);
					logP = log(optr[mapped_tgt] / (1.0-optr[slist_len]) * pmass);
				}
				else {
					logP = log(optr[mapped_tgt]); // no error check on indices necessary here
				}
				nb_ex_slist++;
			}
		}

		// store LM proba
		*(req[n].res_ptr) = logP;
	} // for (ni=...)

}

//**************************************************************************************
// 
void TrainerNgramSlist::BlockSetMax(int p_max) {
	if (req) {
		FreeReq();
		delete req;
	}
	max_req=p_max;
	req = new NgramReq[max_req];
	nreq=0;
}


//**************************************************************************************
// information after finishing an epoch

void TrainerNgramSlist::BlockStats() {
	printf(" - %d %d-gram requests, %d=%.2f%% short n-grams, %d=%5.2f%% predicted by CSLM, %d forward passes (avrg of %d probas)\n",
		nb_ngram, idim+1, nb_ex_short, 100.0*nb_ex_short/nb_ngram, nb_ex_slist, 100.0*nb_ex_slist/nb_ngram, nb_forw, nb_ngram/nb_forw);
}
