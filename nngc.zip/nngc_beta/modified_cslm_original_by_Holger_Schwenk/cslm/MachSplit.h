/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachSplit.h,v 1.12 2012/06/02 13:24:16 schwenk Exp $
 *
 * Split one input into several output layers:
 *   - all the indiv machines must have the same input dimension and bsize
 *   - the output dimension can vary
 *   - the output of the split machine concatenates the outputs of the individual machines
 *
 * Memory allocation:
 *  - output data:  allocated by the split machine (values are copied from indiv. machines)
 *  - input data:   all indiv machines share the same pointer on the input
 *  		    (not allocated by the split machine)
 *  - input gradient: cumaltes gradients of indiv. machibes
 *  		    allocated by the split machine
 */

#ifndef _MachSplit_h
#define _MachSplit_h

using namespace std;
#include <vector>

#include "MachMulti.h"

class MachSplit : public MachMulti
{
protected:
  virtual void ReadData(ifstream&, size_t); // read binary data
public:
  MachSplit();	// create initial sequence with no machine
  virtual ~MachSplit();
  virtual int GetMType() {return file_header_mtype_msplit;};	// get type of machine
    // redfine connecting functions
  virtual void SetDataIn(REAL*);	// set pointer of input data
  virtual void SetGradOut(REAL*);	// set pointer of output gradient 
    // add and remove machines
  virtual void MachAdd(Mach*); // add new machine after the existing ones
  virtual Mach *MachDel();
    // standard functions
  virtual void Info(bool=false, char *txt=(char*)"");	// display (detailed) information on machine
  virtual void Forw(int=0);	// calculate outputs for current inputs
  virtual void Backw(const float lrate, const float wdecay, int=0);	// calculate gradients at input for current gradients at output
};

#endif
