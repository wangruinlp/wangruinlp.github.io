/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachTanh.cpp,v 1.24 2012/06/02 13:24:16 schwenk Exp $
 */

using namespace std;
#include <iostream>
#include <math.h>
//extern double drand48();

#include "Tools.h"
#include "MachTanh.h"
#include "Blas.h"

MachTanh::MachTanh(const int p_idim, const int p_odim, const int p_bsize, const int p_nbfw, const int p_nbbw)
 : MachLin(p_idim, p_odim, p_bsize, p_nbfw, p_nbbw)
{
#ifdef BLAS_CUDA
  tmp_tanh = cuda_alloc(odim*bsize, "temporay memory for tanh machine");
#endif
}

MachTanh::~MachTanh()
{
#ifdef BLAS_CUDA
  if (tmp_tanh) cublasFree(data_out);
#endif
}


//-----------------------------------------------
// Tools
//-----------------------------------------------

void MachTanh::Info(bool detailed, char *txt)
{
  if (detailed) {
    cout << "Information on tanh machine" << endl;
    MachLin::Info(detailed,txt);
  }
  else {
    printf("%sMachTanh %d-%d, bs=%d, passes=%d/%d", txt, idim, odim, bsize, nb_forw, nb_backw);
#ifdef PROFILE
    tm.disp(", ");
#endif
    printf("\n");
  }
}

//-----------------------------------------------
// Training
//-----------------------------------------------

void MachTanh::Forw(int eff_bsize)
{

  if (eff_bsize<=0) eff_bsize=bsize;
  MachLin::Forw(eff_bsize);

#ifdef PROFILE
  tm.start();
#endif

    // apply tanh() on output
  int s=eff_bsize*odim;
#ifdef BLAS_CUDA
    // tanh = sinh/cosh = (exp x - exp -x) / (exp x + exp -x) = (exp(2*x) - 1) / (exp(2*x) + 1)
  nppsMulC_32f_I(2.0,data_out,s);		// 2*x
  nppsExp_32f_I(data_out,s);			// exp(2*x)
  nppsAddC_32f(data_out,1.0,tmp_tanh,s);	// tmp=exp(2*x)+1
  nppsSubC_32f_I(1.0,data_out,s);		// exp(2*x)-1
  nppsDiv_32f_I(tmp_tanh,data_out,s);		// (exp(2*x)-1) / (exp(2*x)+1)
#else
  VTANH(&s,data_out);
#endif

#ifdef PROFILE
  tm.stop();
#endif
}

void MachTanh::Backw(const float lrate, const float wdecay, int eff_bsize)
{
    // derivate tanh activation function
    // multiply grad_hidden by derivatives of hidden layer activities (tanh)
    // grad_out = grad_out .* f'(data_out)
    //          = grad_out .* ( 1 - data_out^2 )

  if (eff_bsize<=0) eff_bsize=bsize;
  if (!grad_out)
    Error("MachTanh::Backw(): output gradient is not set");

#ifdef PROFILE
  tm.start();
#endif

  int d=odim*eff_bsize;
  VSQR(&d,data_out);
#ifdef BLAS_CUDA
# ifdef DEBUG
  { REAL buf[d];
    cublasGetVector(d,sizeof(REAL),data_out,1,buf,1);
    cublasGetVector(d,sizeof(REAL),grad_out,1,buf,1);
  }
# endif
  nppsSubCRev_32f_I(1.0,data_out,d);
  nppsMul_32f_I(data_out,grad_out,d);
# ifdef DEBUG
  { REAL buf[d];
    cublasGetVector(d,sizeof(REAL),grad_out,1,buf,1);
  }
# endif
#else
  REAL *aptr = data_out;
  REAL *gptr = grad_out;
  for (int i=0; i<d; i++) *gptr++ *= (1.0 - *aptr++);	// TODO: can we use more MKL ?
#endif

#ifdef PROFILE
  tm.stop();
#endif

  MachLin::Backw(lrate, wdecay, eff_bsize);
}

