/*
 * This file is part of the continuous space language model toolkit for large
 * vocabulary speech recognition and statistical machine translation.
 *
 * Copyright 2012, Holger Schwenk, LIUM, University of Le Mans, France
 *
 * The CSLM toolkit is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * $Id: MachSig.h,v 1.8 2012/06/02 13:24:16 schwenk Exp $
 *
 * sigmoidal machine:  output = tanh(weights * input + biases)
 */

#ifndef _MachSig_h
#define _MachSig_h

#include "MachLin.h"

class MachSig : public MachLin
{
public:
  MachSig(const int=0, const int=0, const int=1, const int=0, const int=0);	
  virtual ~MachSig();
  virtual int GetMType() {return file_header_mtype_sig;};	// get type of machine
  virtual void Info(bool=false, char *txt= (char*)"");	// display (detailed) information on machine
  virtual void Forw(int=0);	// calculate outputs for current inputs
    // backprop gradients from output to input and update all weights
  virtual void Backw (const float lrate, const float wdecay, int=0);
};

#endif
