

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class arpa_splt {
	public static void main(String[] args) throws IOException {
		System.out.println("This is to split the apar file, please input the arpa file:");
		System.out.println("0: arpa-file");
		System.out.println(args[0]);
		File file_i = new File(args[0]);
		File file_o_1grams = new File(args[0] + ".1grams.txt");
		File file_o_2grams = new File(args[0] + ".2grams.txt");
		File file_o_3grams = new File(args[0] + ".3grams.txt");
		File file_o_4grams = new File(args[0] + ".4grams.txt");
		File file_o_5grams = new File(args[0] + ".5grams.txt");
		BufferedReader reader = null;
		BufferedWriter writer1 = null;
		BufferedWriter writer2 = null;
		BufferedWriter writer3 = null;
		BufferedWriter writer4 = null;
		BufferedWriter writer5 = null;
		String tempString = null;
		try {
			reader = new BufferedReader(new FileReader(file_i));
			writer1 = new BufferedWriter(new FileWriter(file_o_1grams));
			writer2 = new BufferedWriter(new FileWriter(file_o_2grams));
			writer3 = new BufferedWriter(new FileWriter(file_o_3grams));
			writer4 = new BufferedWriter(new FileWriter(file_o_4grams));
			writer5 = new BufferedWriter(new FileWriter(file_o_5grams));
			while ((tempString = reader.readLine()) != null) {
				String s = tempString;
				if (s.equalsIgnoreCase("\\1-grams:")) {
					writer1.write(s);
					writer1.write("\n");

					while (((tempString = reader.readLine()) != null)
							&& (!tempString.equalsIgnoreCase("\\2-grams:"))) {
						writer1.write(tempString);
						writer1.write("\n");
					}
					writer1.close();
					writer2.write("\\2-grams:");
					writer2.write("\n");
					System.out.println("1-gram finished");

					while ((tempString = reader.readLine()) != null
							&& (!tempString.equalsIgnoreCase("\\3-grams:"))) {
						writer2.write(tempString);
						writer2.write("\n");
					}
					writer2.close();
					writer3.write("\\3-grams:");
					writer3.write("\n");
					System.out.println("2-gram finished");

					while ((tempString = reader.readLine()) != null
							&& (!tempString.equalsIgnoreCase("\\4-grams:"))) {
						writer3.write(tempString);
						writer3.write("\n");
					}
					writer3.close();
					writer4.write("\\4-grams:");
					writer4.write("\n");
					System.out.println("3-gram finished");

					while ((tempString = reader.readLine()) != null
							&& (!tempString.equalsIgnoreCase("\\5-grams:"))) {
						writer4.write(tempString);
						writer4.write("\n");
					}
					writer4.close();
					writer5.write("\\5-grams:");
					writer5.write("\n");
					System.out.println("4-gram finished");

					while ((tempString = reader.readLine()) != null) {
						writer5.write(tempString);
						writer5.write("\n");
					}
					writer5.close();
					System.out.println("5-gram finished");
					break;
				} else {
					writer1.write(s);
					writer1.write("\n");
				}
			}

			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}
}
