import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class extract_s_unk {

	public static void main(String[] args) throws IOException {
		System.out.println("This is to split n-gram into the one containing <s> and the one without <s>; the <unk> are deleted. 0:n-gram file; 1:n-grams-with <s>/<unk>; 2-n-grams-without <s>/<unk>");
		System.out.println(args[0]);
		System.out.println(args[1]);
		System.out.println(args[2]);
		File file_i = new File(args[0]);
		File file_o1 = new File(args[1]);
		File file_o2 = new File(args[2]);
		BufferedReader reader = null;
		BufferedWriter writer1 = null;
		BufferedWriter writer2 = null;
		String tempString = null;
		String start = "<s>";
		String unk = "<unk>";
		try {
			reader = new BufferedReader(new FileReader(file_i));
			writer1 = new BufferedWriter(new FileWriter(file_o1));
			writer2 = new BufferedWriter(new FileWriter(file_o2));
			int i = 1;
			while ((tempString = reader.readLine()) != null) {
				int s = tempString.indexOf(start);
				int en = tempString.indexOf(unk);
				if (en == -1) {
					if (s != -1) {
						writer1.write(tempString);
						writer1.write("\n");
					} else {
						writer2.write(tempString);
						writer2.write("\n");
					}
				} else {
				}

			}
			writer1.close();
			writer2.close();
			System.out.println("All  finished");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e1) {
				}
			}
		}
	}
}